data "aws_caller_identity" "actual" {}

# Llave de cliente (CMK) para todo lo Restringido-PII. Equivale a BIA_ENC_KEYS del compose local,
# pero con rotacion automatica, politica propia y auditoria en CloudTrail.
resource "aws_kms_key" "datos" {
  description             = "CMK de datos Restringido-PII (${var.prefijo}-${var.entorno})"
  enable_key_rotation     = true
  deletion_window_in_days = 30
  policy                  = data.aws_iam_policy_document.kms.json
}

resource "aws_kms_alias" "datos" {
  name          = "alias/${var.prefijo}-${var.entorno}-datos"
  target_key_id = aws_kms_key.datos.key_id
}

data "aws_iam_policy_document" "kms" {
  # 1) La cuenta conserva el control via IAM (sin esto la llave podria quedar huerfana).
  statement {
    sid       = "HabilitarIAMDeLaCuenta"
    effect    = "Allow"
    actions   = ["kms:*"]
    resources = ["*"]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${data.aws_caller_identity.actual.account_id}:root"]
    }
    condition {
      test     = "StringEquals"
      variable = "kms:CallerAccount"
      values   = [data.aws_caller_identity.actual.account_id]
    }
  }

  # 2) Separacion de funciones: quien administra la llave NO puede usarla para descifrar.
  statement {
    sid    = "AdministradoresSinUso"
    effect = "Allow"
    actions = [
      "kms:Create*", "kms:Describe*", "kms:Enable*", "kms:List*", "kms:Put*", "kms:Update*",
      "kms:Revoke*", "kms:Disable*", "kms:Get*", "kms:ScheduleKeyDeletion", "kms:CancelKeyDeletion",
      "kms:TagResource", "kms:UntagResource",
    ]
    resources = ["*"]
    principals {
      type        = "AWS"
      identifiers = var.administradores_kms
    }
  }

  # 3) Solo el rol de ingesta cifra y descifra (la app cifra a nivel de campo antes de escribir).
  statement {
    sid       = "UsoIngesta"
    effect    = "Allow"
    actions   = ["kms:Encrypt", "kms:Decrypt", "kms:GenerateDataKey*", "kms:ReEncrypt*", "kms:DescribeKey"]
    resources = ["*"]
    principals {
      type        = "AWS"
      identifiers = [aws_iam_role.ingesta.arn]
    }
  }

  # 4) Auditor y analista solo DESCIFRAN, y solo a traves de S3 (no pueden llamar a KMS directamente).
  #    Que objetos pueden leer lo decide IAM/S3 (analista: analitica/*; auditor: bitacora).
  statement {
    sid       = "DescifrarSoloViaS3"
    effect    = "Allow"
    actions   = ["kms:Decrypt", "kms:DescribeKey"]
    resources = ["*"]
    principals {
      type        = "AWS"
      identifiers = [aws_iam_role.auditor.arn, aws_iam_role.analista.arn]
    }
    condition {
      test     = "StringEquals"
      variable = "kms:ViaService"
      values   = ["s3.${var.region}.amazonaws.com"]
    }
  }
}
