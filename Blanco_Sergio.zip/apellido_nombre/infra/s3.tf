locals {
  sufijo = "${var.prefijo}-${var.entorno}-${data.aws_caller_identity.actual.account_id}"
}

# ------------------------------------------------------------------ datos crudos / curados
resource "aws_s3_bucket" "datos" {
  bucket = "${local.sufijo}-datos"
}

resource "aws_s3_bucket_versioning" "datos" {
  bucket = aws_s3_bucket.datos.id
  versioning_configuration {
    status = "Enabled" # recuperar de borrados o sobrescrituras (archivos de consumo corregidos)
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "datos" {
  bucket = aws_s3_bucket.datos.id
  rule {
    bucket_key_enabled = true
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.datos.arn
    }
  }
}

resource "aws_s3_bucket_public_access_block" "datos" {
  bucket                  = aws_s3_bucket.datos.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_ownership_controls" "datos" {
  bucket = aws_s3_bucket.datos.id
  rule {
    object_ownership = "BucketOwnerEnforced" # sin ACLs
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "datos" {
  bucket = aws_s3_bucket.datos.id
  rule {
    id     = "versiones-antiguas"
    status = "Enabled"
    filter {}
    noncurrent_version_expiration {
      noncurrent_days = var.retencion_versiones_dias
    }
    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }
}

data "aws_iam_policy_document" "datos_bucket" {
  statement {
    sid       = "SoloTLS"
    effect    = "Deny"
    actions   = ["s3:*"]
    resources = [aws_s3_bucket.datos.arn, "${aws_s3_bucket.datos.arn}/*"]
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }
}

resource "aws_s3_bucket_policy" "datos" {
  bucket = aws_s3_bucket.datos.id
  policy = data.aws_iam_policy_document.datos_bucket.json

  depends_on = [aws_s3_bucket_public_access_block.datos]
}

# ------------------------------------------------------------------ bitacora de auditoria (append-only real)
resource "aws_s3_bucket" "auditoria" {
  bucket              = "${local.sufijo}-auditoria"
  object_lock_enabled = true # WORM: ni el administrador puede borrar dentro del periodo de retencion
}

resource "aws_s3_bucket_versioning" "auditoria" {
  bucket = aws_s3_bucket.auditoria.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_object_lock_configuration" "auditoria" {
  bucket = aws_s3_bucket.auditoria.id
  rule {
    default_retention {
      mode = "COMPLIANCE"
      days = var.retencion_auditoria_dias
    }
  }

  depends_on = [aws_s3_bucket_versioning.auditoria]
}

resource "aws_s3_bucket_server_side_encryption_configuration" "auditoria" {
  bucket = aws_s3_bucket.auditoria.id
  rule {
    bucket_key_enabled = true
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.datos.arn
    }
  }
}

resource "aws_s3_bucket_public_access_block" "auditoria" {
  bucket                  = aws_s3_bucket.auditoria.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_ownership_controls" "auditoria" {
  bucket = aws_s3_bucket.auditoria.id
  rule {
    object_ownership = "BucketOwnerEnforced"
  }
}

