# infra/ (Parte F) — NO se despliega

Describe como correria la plataforma en AWS. Equivalencias con el modelo local:

| Local (docker compose / Postgres) | AWS (este Terraform) |
|---|---|
| `BIA_ENC_KEYS` (AES-256-GCM en la app) | CMK de KMS con rotacion anual, politica con separacion de funciones |
| Roles `ingesta` / `analista` / `auditor` | Roles IAM asumibles, uno por funcion, con politicas minimas y `Deny` explicitos |
| `audit.pipeline_runs` append-only (trigger + REVOKE) | Bucket de auditoria con Object Lock en modo COMPLIANCE |
| Volumen de Postgres | (fuera de alcance: RDS/Aurora con `storage_encrypted` y la misma CMK) |

Notas: el log de acceso de S3 y CloudTrail (data events) quedan como siguiente paso (S3 access logs no admiten un destino cifrado con KMS). Estado de validacion: escrito sin acceso a `terraform` ni al registro de HashiCorp, asi que
`terraform validate` **no se ejecuto en esta sesion**. Para comprobarlo:

    cd infra && terraform init -backend=false && terraform validate

Variables obligatorias: `administradores_kms`, `principales_ingesta`.
