# Equivalentes en AWS de los roles de Postgres del punto C4. Cada uno se asume (no hay usuarios con llaves
# de acceso de larga duracion) y solo recibe lo estrictamente necesario.

data "aws_iam_policy_document" "asumir_ingesta" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = var.principales_ingesta
    }
  }
}

data "aws_iam_policy_document" "asumir_analista" {
  count = length(var.principales_analista) > 0 ? 1 : 0
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = var.principales_analista
    }
    condition {
      test     = "Bool"
      variable = "aws:MultiFactorAuthPresent"
      values   = ["true"]
    }
  }
}

data "aws_iam_policy_document" "asumir_auditor" {
  count = length(var.principales_auditor) > 0 ? 1 : 0
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = var.principales_auditor
    }
    condition {
      test     = "Bool"
      variable = "aws:MultiFactorAuthPresent"
      values   = ["true"]
    }
  }
}

# ---------------------------------------------------------------- ingesta (escribe; no lee PII en claro)
resource "aws_iam_role" "ingesta" {
  name                 = "${var.prefijo}-${var.entorno}-ingesta"
  assume_role_policy   = data.aws_iam_policy_document.asumir_ingesta.json
  max_session_duration = 3600
}

data "aws_iam_policy_document" "ingesta" {
  statement {
    sid       = "LeerCrudos"
    actions   = ["s3:GetObject", "s3:GetObjectVersion"]
    resources = ["${aws_s3_bucket.datos.arn}/crudo/*"]
  }
  statement {
    sid       = "EscribirCurados"
    actions   = ["s3:PutObject"]
    resources = ["${aws_s3_bucket.datos.arn}/curado/*", "${aws_s3_bucket.datos.arn}/cuarentena/*"]
  }
  statement {
    sid       = "ListarSoloSusPrefijos"
    actions   = ["s3:ListBucket"]
    resources = [aws_s3_bucket.datos.arn]
    condition {
      test     = "StringLike"
      variable = "s3:prefix"
      values   = ["crudo/*", "curado/*", "cuarentena/*"]
    }
  }
  statement {
    sid       = "EscribirBitacoraSinLeerla"
    actions   = ["s3:PutObject"] # sin GetObject ni DeleteObject: append-only
    resources = ["${aws_s3_bucket.auditoria.arn}/pipeline/*"]
  }
  statement {
    sid       = "CifrarDescifrarCampos"
    actions   = ["kms:Encrypt", "kms:Decrypt", "kms:GenerateDataKey"]
    resources = [aws_kms_key.datos.arn]
  }
}

resource "aws_iam_policy" "ingesta" {
  name   = "${var.prefijo}-${var.entorno}-ingesta"
  policy = data.aws_iam_policy_document.ingesta.json
}

resource "aws_iam_role_policy_attachment" "ingesta" {
  role       = aws_iam_role.ingesta.name
  policy_arn = aws_iam_policy.ingesta.arn
}

# ---------------------------------------------------------------- analista (solo lo curado y agregado; sin PII, sin KMS)
resource "aws_iam_role" "analista" {
  name                 = "${var.prefijo}-${var.entorno}-analista"
  assume_role_policy   = length(var.principales_analista) > 0 ? data.aws_iam_policy_document.asumir_analista[0].json : data.aws_iam_policy_document.nadie.json
  max_session_duration = 3600
}

data "aws_iam_policy_document" "analista" {
  statement {
    sid       = "LeerSoloAnalitica"
    actions   = ["s3:GetObject"]
    resources = ["${aws_s3_bucket.datos.arn}/analitica/*"]
  }
  statement {
    sid       = "ListarAnalitica"
    actions   = ["s3:ListBucket"]
    resources = [aws_s3_bucket.datos.arn]
    condition {
      test     = "StringLike"
      variable = "s3:prefix"
      values   = ["analitica/*"]
    }
  }
  statement {
    sid       = "DescifrarSoloViaS3"
    actions   = ["kms:Decrypt"]
    resources = [aws_kms_key.datos.arn]
    condition {
      test     = "StringEquals"
      variable = "kms:ViaService"
      values   = ["s3.${var.region}.amazonaws.com"]
    }
  }
  statement {
    sid       = "NegarEscrituraYCifrado"
    effect    = "Deny"
    actions   = ["s3:PutObject", "s3:DeleteObject", "s3:DeleteObjectVersion", "kms:Encrypt", "kms:GenerateDataKey*"]
    resources = ["*"]
  }
}

resource "aws_iam_policy" "analista" {
  name   = "${var.prefijo}-${var.entorno}-analista"
  policy = data.aws_iam_policy_document.analista.json
}

resource "aws_iam_role_policy_attachment" "analista" {
  role       = aws_iam_role.analista.name
  policy_arn = aws_iam_policy.analista.arn
}

# ---------------------------------------------------------------- auditor (solo lee la bitacora)
resource "aws_iam_role" "auditor" {
  name                 = "${var.prefijo}-${var.entorno}-auditor"
  assume_role_policy   = length(var.principales_auditor) > 0 ? data.aws_iam_policy_document.asumir_auditor[0].json : data.aws_iam_policy_document.nadie.json
  max_session_duration = 3600
}

data "aws_iam_policy_document" "auditor" {
  statement {
    sid       = "LeerBitacora"
    actions   = ["s3:GetObject", "s3:GetObjectVersion"]
    resources = ["${aws_s3_bucket.auditoria.arn}/*"]
  }
  statement {
    sid       = "ListarBitacora"
    actions   = ["s3:ListBucket", "s3:GetBucketObjectLockConfiguration"]
    resources = [aws_s3_bucket.auditoria.arn]
  }
  statement {
    sid       = "DescifrarSoloViaS3"
    actions   = ["kms:Decrypt"]
    resources = [aws_kms_key.datos.arn]
    condition {
      test     = "StringEquals"
      variable = "kms:ViaService"
      values   = ["s3.${var.region}.amazonaws.com"]
    }
  }
  statement {
    sid       = "NegarDatosYEscritura"
    effect    = "Deny"
    actions   = ["s3:PutObject", "s3:DeleteObject", "s3:DeleteObjectVersion"]
    resources = ["*"]
  }
  statement {
    sid       = "NegarBucketDeDatos"
    effect    = "Deny"
    actions   = ["s3:*"]
    resources = [aws_s3_bucket.datos.arn, "${aws_s3_bucket.datos.arn}/*"]
  }
}

resource "aws_iam_policy" "auditor" {
  name   = "${var.prefijo}-${var.entorno}-auditor"
  policy = data.aws_iam_policy_document.auditor.json
}

resource "aws_iam_role_policy_attachment" "auditor" {
  role       = aws_iam_role.auditor.name
  policy_arn = aws_iam_policy.auditor.arn
}

# Rol "sin nadie": si no se declaran principales, el rol existe pero nadie puede asumirlo (fail-closed).
data "aws_iam_policy_document" "nadie" {
  statement {
    effect    = "Deny"
    actions   = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = ["*"]
    }
  }
}
