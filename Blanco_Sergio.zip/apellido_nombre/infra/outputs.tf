output "bucket_datos" {
  value = aws_s3_bucket.datos.id
}

output "bucket_auditoria" {
  value = aws_s3_bucket.auditoria.id
}

output "kms_key_arn" {
  value = aws_kms_key.datos.arn
}

output "roles" {
  value = {
    ingesta  = aws_iam_role.ingesta.arn
    analista = aws_iam_role.analista.arn
    auditor  = aws_iam_role.auditor.arn
  }
}
