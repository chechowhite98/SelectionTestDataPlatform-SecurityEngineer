terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.region

  default_tags {
    tags = {
      proyecto        = "bia-data-platform"
      entorno         = var.entorno
      clasificacion   = "restringido-pii"
      gestionado_por  = "terraform"
    }
  }
}
