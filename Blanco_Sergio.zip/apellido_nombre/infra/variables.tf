variable "region" {
  description = "Region de AWS."
  type        = string
  default     = "us-east-1"
}

variable "entorno" {
  description = "Nombre del entorno (dev, stg, prod)."
  type        = string
  default     = "dev"
}

variable "prefijo" {
  description = "Prefijo de nombres. El nombre del bucket debe ser globalmente unico."
  type        = string
  default     = "bia-data"
}

variable "administradores_kms" {
  description = "ARNs de los roles/usuarios que ADMINISTRAN la llave KMS (rotar, deshabilitar). No pueden usarla para cifrar/descifrar."
  type        = list(string)
}

variable "principales_ingesta" {
  description = "ARNs que pueden ASUMIR el rol de ingesta (p.ej. el rol de ejecucion del job de ECS/Batch)."
  type        = list(string)
}

variable "principales_analista" {
  description = "ARNs que pueden asumir el rol de analista."
  type        = list(string)
  default     = []
}

variable "principales_auditor" {
  description = "ARNs que pueden asumir el rol de auditor."
  type        = list(string)
  default     = []
}

variable "retencion_auditoria_dias" {
  description = "Dias que se conserva la bitacora de auditoria con bloqueo (Object Lock)."
  type        = number
  default     = 365
}

variable "retencion_versiones_dias" {
  description = "Dias que se conservan versiones no vigentes de los datos crudos."
  type        = number
  default     = 90
}
