#!/usr/bin/env bash
# =============================================================================
# Aplica sql/0*.sql en orden. Dos usos:
#   1) Automatico: montado en /docker-entrypoint-initdb.d/, corre UNA vez al
#      crear el volumen de Postgres.
#   2) Manual (reaplicacion manual (`make up` lo hace)): docker exec ... bash /docker-entrypoint-initdb.d/00_run_sql.sh
#      Los SQL son idempotentes, repetirlo es seguro.
#
# Las contrasenas llegan por variables de entorno (no por argumentos), asi no
# aparecen en `ps`. Los SQL las leen con \getenv.
# =============================================================================
set -Eeuo pipefail

: "${INGESTA_PASSWORD:?falta INGESTA_PASSWORD}"
: "${ANALISTA_PASSWORD:?falta ANALISTA_PASSWORD}"
: "${AUDITOR_PASSWORD:?falta AUDITOR_PASSWORD}"

SQL_DIR="${SQL_DIR:-/sql}"
DB="${POSTGRES_DB:?falta POSTGRES_DB}"
SUPER="${POSTGRES_USER:?falta POSTGRES_USER}"

shopt -s nullglob
archivos=("$SQL_DIR"/0*.sql)
(( ${#archivos[@]} > 0 )) || { echo "[initdb] no hay SQL en $SQL_DIR" >&2; exit 1; }

for f in "${archivos[@]}"; do
  echo "[initdb] aplicando $(basename "$f")"
  psql --no-psqlrc --quiet -v ON_ERROR_STOP=1 \
       --username "$SUPER" --dbname "$DB" --file "$f"
done
echo "[initdb] modelo, roles y grants aplicados"
