# SECURITY

## 1. Auditoría del scaffolding heredado (lo que encontré y qué hice)

| Hallazgo | Archivo | Acción |
|---|---|---|
| Superusuario `postgres/postgres` usado por la aplicación | `docker-compose.yml`, `pipeline.yaml` | La app conecta como `ingesta` (menor privilegio); superusuario solo para inicializar/verificar, con contraseña de `.env`. |
| Contraseña de base de datos hardcodeada en texto plano | `pipeline.yaml` | Archivo **eliminado**; no existe en el árbol ni en el historial git de la entrega. Debe considerarse comprometida y rotarse donde se haya usado. |
| «Cifrado» `algoritmo: none` con una llave maestra base64 de juguete | `pipeline.yaml` | Reemplazado por AES-256-GCM real con llaves generadas al azar fuera del repo. |
| MinIO con credenciales por defecto, imagen `latest`, consola 9001 expuesta; nadie lo usa | `docker-compose.yml` | Servicio eliminado (menos superficie). |
| Puertos publicados en 0.0.0.0, imágenes `:latest`, sin healthchecks | `docker-compose.yml` | Puertos a 127.0.0.1, tags mayores fijos, `healthcheck`, `no-new-privileges`, `scram-sha-256`. |
| Webhook de Slack en claro | `pipeline.yaml` | Eliminado con el archivo; no se usa. |
| Dependencias de 2018–2020 (PyYAML 5.3.1 con CVE-2020-14343, requests 2.19.1, urllib3 1.24.1, Jinja2 2.11.2) y `pandas` sin uso | `requirements.txt` | Retiradas las no usadas; resto actualizado y fijado. |

## 2. Dependencias (C7)
`pip-audit` sobre `requirements.txt` actual: **sin vulnerabilidades conocidas** (`tools/pip_audit_evidencia.txt`,
reproducible con `make audit`). Las versiones heredadas tenían decenas de avisos (urllib3, Jinja2, PyYAML). Solo se usa
`yaml.safe_load`. Límite honesto: no hay `--require-hashes` ni auditoría de dependencias transitivas con árbol completo.

## 3. Controles (resumen; detalle en `THREAT_MODEL.md`)
- **Clasificación viva** (`data_classification.yaml`, verificada en cada corrida; aborta si hay columna sin clasificar).
- **PII en texto libre**: detector de correos, celulares y cédulas (incluida la forma `154.274`) con sesgo hacia enmascarar.
- **Cifrado en reposo**: AES-256-GCM por campo, AAD ligado a tabla/columna/fila, blind index HMAC para joins por NIT.
- **Menor privilegio**: roles `ingesta` / `analista` / `auditor`, `REVOKE … FROM PUBLIC`, vistas `security_barrier`.
- **Auditoría append-only** con trigger inmune al superusuario normal (`ENABLE ALWAYS`).
- **Sin secretos en el repo**: `.env` (no versionado), `${VAR:?}` en compose, la app lee solo del entorno.

## 4. Gestión de llaves
`BIA_ENC_KEYS="1:<b64>[,2:<b64>]"` — la primera versión cifra, todas descifran; rotar = agregar versión nueva.
`BIA_INDEX_KEY` es independiente. **Perder las llaves = PII irrecuperable y NIT irreconciliables**: respaldarlas fuera del equipo.

## 5. Límites conocidos (honestos)
1. El proceso `ingesta` posee las llaves de cifrado; su compromiso expone PII. Mitigación futura: KMS/envelope con descifrado en un servicio aparte.
2. Un superusuario de Postgres puede deshabilitar el trigger de auditoría; el sumidero inmutable real es el bucket Object Lock de `infra/`.
3. Redpanda local sin TLS/autenticación.
4. `terraform validate` no se ejecutó en el entorno de desarrollo (sin acceso al registro); la sintaxis se verificó con un parser HCL2.
5. `docker compose up` no se pudo ejecutar en el entorno de desarrollo (sin daemon); la inicialización SQL se probó con `psql` contra Postgres 16.
