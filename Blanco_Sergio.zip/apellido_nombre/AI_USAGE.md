# AI_USAGE

> Este documento lo redactó el asistente de IA con el que trabajé, a partir de lo que realmente ocurrió en la sesión.
> Revísalo y ajusta lo que no coincida con tu experiencia antes de entregar: es tu documento.

## 1. Herramientas y para qué
Claude (Anthropic) en modo agente, con shell y archivos: lectura de los datos, diseño del modelo SQL, lector de consumos, reglas de calidad,
cifrado, orquestador, streaming, pruebas, Terraform y documentación. Yo dirigí el orden de trabajo, aporté los datos y las decisiones de alcance.
Para validar: PostgreSQL 16 local, `pytest`, `pip-audit`, una implementación independiente en pandas para contrastar las cifras de calidad.

## 2. Prompts que movieron la aguja (textuales)
1. «Me puedes ayudar con un reto de Data Platform & Security?» + pegué el enunciado completo y el scaffolding. Con eso el asistente auditó el PoC heredado antes de escribir nada.
2. «Veamos primero los datos» — antes de construir, caracterizar los 10 archivos (encodings, separadores, unidades, zona horaria, duplicados, nombres de columna). Esa lectura determinó el lector por contenido.
3. «Sigamos con maestros y cifrao» — llevó al diseño de cifrado por campo + blind index.
(La mayor parte de la conversación fueron instrucciones cortas de avance como «Continuar»; no hubo un prompt mágico.)

## 3. Qué generó la IA que cambié y por qué
- El primer borrador de `sql/02_core.sql` generaba la columna `mes` con `to_char`: Postgres lo rechazó (*generation expression is not immutable*). Se reescribió con `extract` + `lpad`.
- La primera prueba de roles del analista «pasaba» aunque yo había roto un permiso: había dos capas de bloqueo (USAGE del esquema y SELECT de la tabla) y el test solo abría una. Se extendió el test hasta que la mutación lo hizo fallar.
- Una aserción débil de la prueba de «cliente actualizado» (`in (0, 1)`) se reescribió para comprobar exactamente qué cliente cambia.
- Hacks cosméticos (`hasattr`, `if False`) que dejó el asistente se eliminaron.

## 4. Un error de la IA que hubo que corregir (concreto)
**`src/bia/pii.py`, línea 27 (`CEDULA`).** El detector de cédulas que escribió el asistente no enmascaraba cédulas con **un solo punto y 6 dígitos** (`154.274`):
solo reconocía `\d{1,3}(\.\d{3}){2,3}` o 6–10 dígitos seguidos. Lo encontró una prueba aleatoria que inyecta cédulas en texto libre en distintos formatos: **43 de 500 se
filtraban sin enmascarar**, es decir PII en claro en `observaciones_enmascaradas`, que es exactamente la eliminatoria 1. Corrección: agregar la alternativa `\d{3}\.\d{3}` (sin tocar cifras de dinero como `13.200` o `1.234`, que se probaron como no-PII).
Un segundo error parecido, esta vez en las **pruebas**: `tests/conftest.py`, línea 70, la regex de versión de `psql` capturaba el «1» de `24.04.1)` en vez de «16», así que 22 pruebas de integración se **saltaban en silencio** y la suite parecía verde. Se corrigió la regex y se aprendió a mirar los *skipped*.
