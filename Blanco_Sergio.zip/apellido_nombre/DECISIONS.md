# DECISIONS (ADR breves)

Cada decisión: contexto → decisión → consecuencia. Las cifras citadas se reprodujeron con una implementación independiente en pandas.

**D1. Modelo.** Esquemas `core` (hechos/dimensiones), `quarantine`, `ops`, `audit`, `analytics`. Hecho de consumo horario con PK `(frontera_id, ts_utc)`; `ts_local` y `mes` son columnas generadas (hora de Bogotá, UTC-5 fijo; `extract+lpad` porque `to_char` no es inmutable).
*Por qué:* la PK natural hace el upsert idempotente sin tabla de claves; el analista solo ve vistas. *Costo:* 114 740 filas en una tabla sin particionar; suficiente aquí, se particionaría por mes a escala.

**D2. Idempotencia.** Upsert con `ON CONFLICT … DO UPDATE WHERE (version_lectura, archivo_origen, fila_origen) > (actual)` y `archivo_origen COLLATE "C"`; libro `ops.archivo_cargado` (nombre + SHA-256) para saltar archivos ya cargados; una sola transacción de carga. Las métricas cuentan solo filas realmente insertadas o cambiadas (2.ª corrida = 0).
*Prueba:* dos corridas dan bytes idénticos en 7 tablas y en los CSV/JSON.

**D3. Formatos distintos.** Se detectan **por contenido** (encoding, delimitador, sinónimos de columna, unidad Wh/kWh/MWh/GWh, zona horaria declarada), no por nombre de archivo. Un archivo corrupto o truncado se rechaza **entero** y la corrida termina `PARCIAL` (exit 0; exit 2 con `--estricto`), sin alterar lo cargado.
*Por qué:* cargar medio archivo produce meses con huecos silenciosos, peor que un rechazo ruidoso.

**D4. Calidad: deduplicar primero, validar después (B3→B4).** Un duplicado conflictivo se resuelve con `(versión, archivo, fila)`; si el ganador es inválido queda `estado='INVALIDA'` (consumo NULL) y el perdedor válido **no resucita**.
*Por qué:* una corrección posterior que anula una lectura es información; si resucitara el valor viejo se reintroduciría el dato que alguien corrigió. *Costo/pregunta abierta:* si el evaluador espera lo contrario, cambia `calidad.py` en un punto; está enviado como duda en el README.

**D5. Huecos (B5) contra la grilla del mes calendario**, no contra el rango observado. Una frontera que callaba el primer día se refleja como horas sin lectura.

**D6. Cifrado a nivel de aplicación (AES-256-GCM) y no `pgcrypto`.** Con pgcrypto la llave y el texto en claro pasan por el servidor (logs de consultas, `pg_stat_statements`). Aquí Postgres nunca ve el claro. Formato `versión(1)‖nonce(12)‖cifrado‖tag(16)` con dominio `core.pii_cifrado` que exige longitud mínima. AAD `tabla.columna|id` para que un blob no se pueda mover a otra celda.

**D7. Joins por NIT sin exponerlo:** blind index HMAC-SHA256 con llave **separada**, sobre el NIT normalizado a dígitos. `huella_contenido` (HMAC del claro) hace idempotente el upsert aunque cada cifrado use un nonce distinto.

**D8. Roles y grants.** Un rol dueño `NOLOGIN` (`bia_owner`); `ingesta` sin DELETE/TRUNCATE; vistas `security_barrier` que corren como dueño; `REVOKE … FROM PUBLIC`. Auditoría con trigger `ENABLE ALWAYS` además del REVOKE.
*Por qué ambos:* REVOKE detiene a los roles normales; el trigger detiene incluso a un superusuario descuidado.

**D9. Auditoría por conexión aparte y *fail-closed*.** Si no se puede auditar, no se carga. Así un rollback de la carga no se lleva el registro de que se intentó.

**D10. Logs y errores sin PII.** Todo campo pasa por el detector; de las excepciones solo se registra clase y `pgcode`. UUIDs de corrida con re-sorteo para que ningún segmento numérico parezca cédula.

**D11. Clasificación viva (C1).** `data_classification.yaml` lo lee el pipeline y compara contra `pg_attribute`; aborta con columnas sin clasificar. `pg_catalog` y no `information_schema` porque este último oculta lo que el rol no puede leer.

**D12. Streaming (D).** Lógica pura (`Detector`) separada de Kafka; dedupe por `evento_id`; la cola del día se evalúa al cerrar; el consumidor termina por «al día + 6 s ociosos» o tope de 200 s; si el tópico está vacío, `make stream` lo publica (el evaluador no dice quién produce). Lee desde el inicio sin grupo: cada corrida da lo mismo.
*Alternativa descartada:* Faust/Flink: desproporcionado para 3 795 eventos y tres reglas.

**D13. Infra local.** Se quitó MinIO (nadie lo usa) y se dejó solo Postgres + Redpanda, ligados a 127.0.0.1.

**D14. Lo que NO hice y por qué**: particionado, `dbt`/orquestador (un `make run` basta para 4 archivos), TLS local, hashes en `requirements.txt`. Todo está listado en el README.
