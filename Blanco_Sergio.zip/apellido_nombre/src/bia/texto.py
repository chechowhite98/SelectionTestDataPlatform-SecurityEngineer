"""Utilidades de texto compartidas por los lectores de archivos."""
from __future__ import annotations

import re
import unicodedata


def decodificar(datos: bytes) -> tuple[str, str]:
    """Bytes -> (texto, encoding usado).

    utf-8 (con o sin BOM) -> cp1252 -> latin-1. Los archivos de Bia no son
    homogeneos (los consumos son ASCII, el maestro de clientes es ISO-8859-1), asi
    que el encoding se detecta archivo por archivo. latin-1 nunca falla.
    """
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return datos.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return datos.decode("latin-1"), "latin-1"


def normalizar_nombre(nombre: str) -> str:
    """'  Razón Social ' -> 'razon_social' (sin tildes, BOM ni signos)."""
    s = unicodedata.normalize("NFKD", nombre.replace("\ufeff", ""))
    s = s.encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "_", s.strip().lower()).strip("_")
