"""Reglas de negocio exactas del enunciado (Parte B) y constantes compartidas.

Todo lo que el evaluador compara contra un resultado esperado vive aqui, en
un solo lugar, para poder defenderlo y cambiarlo sin cazar numeros magicos.
"""
from __future__ import annotations

import re
from calendar import monthrange
from datetime import datetime, timedelta, timezone
from decimal import Decimal

# B1 · America/Bogota es UTC-5 FIJO (sin horario de verano). Se usa un offset
# fijo y no la base tzdata: es exacto para Colombia y no depende del sistema.
UTC = timezone.utc
TZ_BOGOTA = timezone(timedelta(hours=-5), "America/Bogota")

# B2 · el resultado final siempre esta en kWh. Factor para llevar cada unidad a kWh.
FACTOR_A_KWH = {
    "wh": Decimal("0.001"),
    "kwh": Decimal(1),
    "mwh": Decimal(1000),
    "gwh": Decimal(1000000),
}
UNIDAD_CANONICA = {"wh": "Wh", "kwh": "kWh", "mwh": "MWh", "gwh": "GWh"}

# B4 · limite fisico: ESTRICTAMENTE mayor es outlier (1.000.000 exacto es valido).
UMBRAL_OUTLIER_KWH = Decimal(1000000)

FRONTERA_RE = re.compile(r"^CO[0-9]{10}$")

# Un archivo estructuralmente sano puede traer alguna fila mala (va a cuarentena);
# si mas de este porcentaje es invalido, el archivo entero se considera corrupto.
MAX_RATIO_FILAS_RECHAZADAS = 0.05

# Motivos de rechazo (codigos estables: van a cuarentena, a metricas y al runbook)
# -- a nivel de ARCHIVO
M_ARCHIVO_VACIO = "ARCHIVO_VACIO"
M_CONTENIDO_BINARIO = "CONTENIDO_BINARIO"
M_ENCABEZADO_NO_RECONOCIDO = "ENCABEZADO_NO_RECONOCIDO"
M_CSV_MALFORMADO = "CSV_MALFORMADO"
M_ARCHIVO_TRUNCADO = "ARCHIVO_TRUNCADO"
M_DEMASIADAS_FILAS_INVALIDAS = "DEMASIADAS_FILAS_INVALIDAS"
M_SIN_FILAS_VALIDAS = "SIN_FILAS_VALIDAS"
# -- a nivel de FILA
M_NUM_CAMPOS = "NUM_CAMPOS_INVALIDO"
M_FRONTERA_INVALIDA = "FRONTERA_INVALIDA"
M_FRONTERA_DESCONOCIDA = "FRONTERA_DESCONOCIDA"
M_TIMESTAMP_INVALIDO = "TIMESTAMP_INVALIDO"
M_TIMESTAMP_NO_HORARIO = "TIMESTAMP_NO_HORARIO"
M_VALOR_NO_NUMERICO = "VALOR_NO_NUMERICO"
M_UNIDAD_DESCONOCIDA = "UNIDAD_DESCONOCIDA"
M_VERSION_INVALIDA = "VERSION_INVALIDA"
M_MES_FUERA_DEL_ARCHIVO = "MES_FUERA_DEL_ARCHIVO"

# Estados de una lectura ganadora (B4) y motivos de invalidez
VALIDA = "VALIDA"
INVALIDA = "INVALIDA"
NULO, NEGATIVO, OUTLIER = "NULO", "NEGATIVO", "OUTLIER"


def mes_local(ts_utc: datetime) -> str:
    """'YYYY-MM' en hora local de Colombia (B1)."""
    return ts_utc.astimezone(TZ_BOGOTA).strftime("%Y-%m")


def horas_del_mes(mes: str) -> int:
    """Horas del mes calendario. Sin horario de verano: dias * 24."""
    anio, m = (int(x) for x in mes.split("-"))
    return monthrange(anio, m)[1] * 24
