"""Deteccion y enmascarado de PII en texto libre (C2).

El campo `observaciones` de clientes.csv trae correos, celulares y cedulas que
alguien escribio ahi sin deber. Se detectan, se reemplazan por una etiqueta y se
reporta cuantos clientes estan afectados. El texto ORIGINAL no se guarda en ninguna
parte (minimizacion de datos): solo el texto ya enmascarado y los tipos hallados.

Sesgo deliberado: ante la duda, ENMASCARAR. Un numero de 6 a 10 digitos suelto se
trata como cedula aunque fuera un numero de contrato. Un falso positivo cuesta una
etiqueta de mas; un falso negativo cuesta una fuga de datos personales.

Limites conocidos (para el threat model): no detecta correos ofuscados ("juan arroba
x punto com"), numeros escritos con letras ni nombres propios. Un detector de
entidades (NER) cubriria nombres, pero queda fuera del alcance de esta prueba.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
# Celular colombiano: 3XX XXX XXXX, con o sin +57 y con separadores opcionales.
CELULAR = re.compile(r"(?<!\d)(?:\+?57[\s-]?)?3\d{2}[\s.-]?\d{3}[\s.-]?\d{4}(?!\d)")
# Cedula: con puntos de miles (12.345.678 / 1.234.567.890), 6-10 digitos seguidos, o la
# forma de 6 digitos con un solo punto (154.274; las cedulas antiguas). Esta ultima se
# limita a 3+3 digitos a proposito: 13.200 o 1.234 (decimales) no se tocan.
CEDULA = re.compile(r"(?<!\d)(?:\d{1,3}(?:\.\d{3}){2,3}|\d{6,10}|\d{3}\.\d{3})(?!\d)")

ETIQUETAS = {"email": "[EMAIL]", "celular": "[CELULAR]", "cedula": "[CEDULA]"}
# Orden importa: primero el correo (puede contener digitos), luego celular, luego cedula.
_PATRONES = (("email", EMAIL), ("celular", CELULAR), ("cedula", CEDULA))


@dataclass(frozen=True)
class Enmascarado:
    texto: str | None
    tipos: tuple[str, ...]      # tipos de PII encontrados, p.ej. ('email', 'celular')

    @property
    def tenia_pii(self) -> bool:
        return bool(self.tipos)


def enmascarar(texto: str | None) -> Enmascarado:
    """Devuelve el texto con la PII reemplazada y los tipos que se encontraron."""
    if texto is None or texto.strip() == "":
        return Enmascarado(None, ())
    tipos: list[str] = []
    resultado = texto
    for tipo, patron in _PATRONES:
        resultado, n = patron.subn(ETIQUETAS[tipo], resultado)
        if n:
            tipos.append(tipo)
    return Enmascarado(resultado, tuple(tipos))


def contiene_pii(texto: str | None) -> bool:
    """True si el texto aun parece contener PII (sirve de verificacion posterior)."""
    return bool(texto) and any(p.search(texto) for _, p in _PATRONES)
