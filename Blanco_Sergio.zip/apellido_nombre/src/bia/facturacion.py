"""Lectura de facturacion (JSON anidado) y regla B6.

B6: una factura cuya frontera no existe en el maestro NO se carga: va a cuarentena y
se reporta. Como la factura trae NIT y email del cliente, el contenido completo se
guarda en la cuarentena CIFRADO, nunca en claro.

Minimizacion (Ley 1581, principio de finalidad): del JSON solo se conserva lo que la
analitica necesita. El email de facturacion no se persiste; del NIT solo el indice
ciego (para detectar una factura emitida a un NIT distinto al del maestro).

Los numeros se leen como Decimal (parse_float): 497.23 sigue siendo 497.23 y no el
float binario mas cercano.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

from . import rechazo as Z
from .cripto import Cifrador, normalizar_nit
from .rechazo import Rechazo
from .texto import decodificar

_ID_VALIDO = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_PERIODO = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")


@dataclass(frozen=True)
class FacturaFila:
    factura_id: str
    frontera_id: str
    periodo: str
    cliente_nit_hash: bytes
    consumo_facturado_kwh: Decimal | None
    tarifa_cop_kwh: Decimal | None
    valor_total_cop: Decimal | None
    metodo_pago_tipo: str | None
    cuenta_enmascarada: str | None
    componentes: tuple[tuple[str, Decimal | None], ...]
    archivo: str = ""
    fila_origen: int = 0          # posicion dentro de la lista 'facturas' (base 1)


@dataclass
class ResultadoFacturacion:
    facturas: list[FacturaFila] = field(default_factory=list)
    rechazos: list[Rechazo] = field(default_factory=list)
    facturas_leidas: int = 0
    fronteras_huerfanas: int = 0               # B6: facturas con frontera inexistente
    archivos: list[tuple[str, str, str]] = field(default_factory=list)   # (nombre, sha256, estado)


def descubrir(directorio: Path) -> list[Path]:
    return sorted((p for p in Path(directorio).iterdir()
                   if p.is_file() and not p.name.startswith(".") and p.suffix.lower() == ".json"),
                  key=lambda p: p.name)


def _decimal(valor, campo: str) -> Decimal | None:
    if valor is None:
        return None
    if isinstance(valor, bool) or not isinstance(valor, (Decimal, int)):
        raise ValueError(campo)
    return Decimal(valor)


def _cadena(valor, campo: str, obligatoria: bool = False) -> str | None:
    if valor is None or valor == "":
        if obligatoria:
            raise ValueError(campo)
        return None
    if not isinstance(valor, str):
        raise ValueError(campo)
    return valor


def _parsear_factura(f: dict, periodo: str, nombre: str, n: int, cif: Cifrador) -> FacturaFila:
    """Valida una factura. ValueError(campo) si algo no cuadra (el campo, nunca el valor)."""
    if not isinstance(f.get("cliente"), dict) or not isinstance(f.get("componentes"), list):
        raise ValueError("estructura")
    nit = normalizar_nit(_cadena(f["cliente"].get("nit"), "cliente.nit", True))
    if nit is None:
        raise ValueError("cliente.nit")
    pago = f.get("metodo_pago") if isinstance(f.get("metodo_pago"), dict) else {}
    componentes = []
    for c in f["componentes"]:
        if not isinstance(c, dict):
            raise ValueError("componentes")
        componentes.append((_cadena(c.get("concepto"), "componentes.concepto", True),
                            _decimal(c.get("valor_cop_kwh"), "componentes.valor_cop_kwh")))
    if len({c for c, _ in componentes}) != len(componentes):
        raise ValueError("componentes.concepto repetido")
    return FacturaFila(
        factura_id=f["factura_id"], frontera_id=f["frontera_id"], periodo=periodo,
        cliente_nit_hash=cif.indice_ciego(nit),
        consumo_facturado_kwh=_decimal(f.get("consumo_facturado_kwh"), "consumo_facturado_kwh"),
        tarifa_cop_kwh=_decimal(f.get("tarifa_cop_kwh"), "tarifa_cop_kwh"),
        valor_total_cop=_decimal(f.get("valor_total_cop"), "valor_total_cop"),
        metodo_pago_tipo=_cadena(pago.get("tipo"), "metodo_pago.tipo"),
        cuenta_enmascarada=_cadena(pago.get("cuenta_enmascarada"), "metodo_pago.cuenta_enmascarada"),
        componentes=tuple(componentes), archivo=nombre, fila_origen=n)


def leer_facturacion(directorio: Path, fronteras_validas: set[str], cif: Cifrador) -> ResultadoFacturacion:
    res = ResultadoFacturacion()
    candidatas: list[tuple[FacturaFila, dict]] = []     # (factura, original) en orden de archivo

    def rechazar(nombre, n, motivo, original=None, clave=None, detalle=None):
        payload = None
        if original is not None:
            payload = cif.cifrar(json.dumps(original, ensure_ascii=False, default=str),
                                 f"quarantine.rechazo.payload|facturacion|{nombre}|{n}")
        res.rechazos.append(Rechazo("facturacion", nombre, n, motivo, clave, detalle, payload))

    for ruta in descubrir(directorio):
        datos = ruta.read_bytes()
        sha = hashlib.sha256(datos).hexdigest()
        try:
            texto, _ = decodificar(datos)
            raiz = json.loads(texto, parse_float=Decimal)
            periodo = raiz["periodo"]
            lista = raiz["facturas"]
            if not (isinstance(raiz, dict) and isinstance(periodo, str) and _PERIODO.match(periodo)
                    and isinstance(lista, list)):
                raise ValueError("estructura")
        except (ValueError, KeyError, TypeError, RecursionError):
            res.archivos.append((ruta.name, sha, "RECHAZADO"))
            rechazar(ruta.name, 0, Z.M_ARCHIVO_INVALIDO)
            continue
        res.archivos.append((ruta.name, sha, "OK"))

        for n, f in enumerate(lista, start=1):
            res.facturas_leidas += 1
            if not isinstance(f, dict) or not isinstance(f.get("factura_id"), str) \
                    or not _ID_VALIDO.match(f["factura_id"]) or not isinstance(f.get("frontera_id"), str):
                rechazar(ruta.name, n, Z.M_FACTURA_INVALIDA, f if isinstance(f, dict) else {"_": str(f)[:200]})
                continue
            if f["frontera_id"] not in fronteras_validas:               # B6
                res.fronteras_huerfanas += 1
                rechazar(ruta.name, n, Z.M_FRONTERA_HUERFANA, f, clave=f["factura_id"])
                continue
            try:
                candidatas.append((_parsear_factura(f, periodo, ruta.name, n, cif), f))
            except ValueError as e:
                rechazar(ruta.name, n, Z.M_FACTURA_INVALIDA, f, clave=f["factura_id"], detalle=str(e))

    # Duplicados: misma factura_id, o dos facturas para la misma (frontera, periodo).
    # Gana la ultima en orden de archivo; las anteriores quedan en cuarentena.
    ganadoras: dict[tuple, tuple[FacturaFila, dict]] = {}
    for fac, original in candidatas:
        for clave in (("id", fac.factura_id), ("fp", fac.frontera_id, fac.periodo)):
            previa = ganadoras.get(clave)
            if previa is not None and previa[0] is not fac:
                p = previa[0]
                rechazar(p.archivo, p.fila_origen, Z.M_FACTURA_DUPLICADA, previa[1], clave=p.factura_id)
                for k in [k for k, v in ganadoras.items() if v[0] is p]:
                    del ganadoras[k]
            ganadoras[clave] = (fac, original)
    vistas: dict[int, FacturaFila] = {id(v[0]): v[0] for v in ganadoras.values()}
    res.facturas = sorted(vistas.values(), key=lambda x: (x.periodo, x.factura_id))
    return res
