"""python -m bia run [--estricto]

Codigos de salida:
  0  OK, o PARCIAL (algun archivo se rechazo entero pero el resto se proceso bien)
  1  ERROR (configuracion, base inaccesible, maestro ilegible, fallo de carga)
  2  PARCIAL con --estricto (o BIA_FALLAR_SI_PARCIAL=1)
"""
from __future__ import annotations

import argparse
import dataclasses
import sys

from .config import ConfigError, cargar_config
from .pipeline import ejecutar


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="bia", description="Pipeline de datos de Bia Energy")
    sub = parser.add_subparsers(dest="comando", required=True)
    run = sub.add_parser("run", help="ejecuta el pipeline batch completo")
    run.add_argument("--estricto", action="store_true",
                     help="sale con codigo 2 si algun archivo se rechazo entero")
    st = sub.add_parser("stream", help="consume mediciones.raw y escribe out/alertas.json")
    st.add_argument("--archivo", help="lee un ndjson en vez de Kafka (pruebas / sin broker)")
    args = parser.parse_args(argv)

    if args.comando == "stream":                     # no necesita base de datos ni llaves
        from pathlib import Path
        from .streaming import ejecutar as ejecutar_stream
        return ejecutar_stream(archivo=Path(args.archivo) if args.archivo else None)

    try:
        cfg = cargar_config()
    except ConfigError as e:
        print(f"Configuracion invalida: {e}", file=sys.stderr)    # nombra la variable, nunca el valor
        return 1
    if args.estricto:
        cfg = dataclasses.replace(cfg, fallar_si_parcial=True)
    return ejecutar(cfg)


if __name__ == "__main__":
    sys.exit(main())
