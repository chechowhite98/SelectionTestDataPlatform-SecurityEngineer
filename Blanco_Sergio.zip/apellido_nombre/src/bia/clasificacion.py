"""C1: la clasificacion de datos como artefacto VIVO (data_classification.yaml).

El pipeline la consulta al arrancar (Corrida._clasificacion). Si el modelo y el YAML se desalinean,
no se carga nada: una columna nueva sin clasificar es una fuga potencial, asi que se falla cerrado.
Cubre dos tipos de desalineacion:
  * columna real sin clasificar / clasificada pero inexistente
  * politica rota: Restringido-PII sin proteccion, o PII expuesta en el esquema analytics
"""
from __future__ import annotations

from pathlib import Path

import yaml

NIVELES = ("Publico", "Interno", "Confidencial", "Restringido-PII")
PROTECCIONES = ("ninguna", "cifrado_aes256gcm", "hmac_sha256", "enmascarado", "derivado")
ESQUEMAS = ("core", "quarantine", "ops", "audit", "analytics")
RUTA_DEFECTO = Path(__file__).resolve().parent.parent.parent / "data_classification.yaml"


class ClasificacionInvalida(Exception):
    """El mensaje nombra tablas/columnas, nunca datos: es seguro para los logs."""


def cargar(ruta: Path | None = None) -> dict[str, dict[str, dict]]:
    ruta = Path(ruta or RUTA_DEFECTO)
    if not ruta.is_file():
        raise ClasificacionInvalida(f"falta {ruta.name}")
    try:
        doc = yaml.safe_load(ruta.read_text(encoding="utf-8"))
    except yaml.YAMLError:
        raise ClasificacionInvalida(f"{ruta.name} no es YAML valido") from None
    tablas = (doc or {}).get("tablas")
    if not isinstance(tablas, dict) or not tablas:
        raise ClasificacionInvalida(f"{ruta.name}: falta la seccion 'tablas'")
    return tablas


def problemas_de_politica(tablas: dict) -> list[str]:
    malos = []
    for tabla, columnas in tablas.items():
        for col, meta in (columnas or {}).items():
            nivel, prot = (meta or {}).get("clasificacion"), (meta or {}).get("proteccion")
            if nivel not in NIVELES:
                malos.append(f"{tabla}.{col}: clasificacion invalida")
            if prot not in PROTECCIONES:
                malos.append(f"{tabla}.{col}: proteccion invalida")
            if nivel == "Restringido-PII" and prot in (None, "ninguna"):
                malos.append(f"{tabla}.{col}: Restringido-PII sin proteccion")
            if nivel == "Restringido-PII" and tabla.startswith("analytics."):
                malos.append(f"{tabla}.{col}: PII expuesta en analytics")
    return malos


def columnas_reales(cur) -> set[str]:
    """'esquema.tabla.columna'. Usa pg_catalog (no information_schema, que oculta lo que el rol no puede leer)."""
    cur.execute("""
        SELECT n.nspname || '.' || c.relname || '.' || a.attname
          FROM pg_attribute a
          JOIN pg_class c ON c.oid = a.attrelid AND c.relkind IN ('r','v','p')
          JOIN pg_namespace n ON n.oid = c.relnamespace
         WHERE n.nspname = ANY(%s) AND a.attnum > 0 AND NOT a.attisdropped""", (list(ESQUEMAS),))
    return {r[0] for r in cur.fetchall()}


def verificar(tablas: dict, reales: set[str]) -> None:
    declaradas = {f"{t}.{c}" for t, cols in tablas.items() for c in (cols or {})}
    sin_clasificar = sorted(reales - declaradas)
    sobrantes = sorted(declaradas - reales)
    malos = problemas_de_politica(tablas)
    if sin_clasificar or sobrantes or malos:
        partes = []
        if sin_clasificar:
            partes.append("sin clasificar: " + ", ".join(sin_clasificar))
        if sobrantes:
            partes.append("clasificadas pero inexistentes: " + ", ".join(sobrantes))
        if malos:
            partes.append("politica: " + "; ".join(malos))
        raise ClasificacionInvalida(" | ".join(partes))


def columnas_pii(tablas: dict) -> set[str]:
    return {f"{t}.{c}" for t, cols in tablas.items() for c, m in cols.items() if m["clasificacion"] == "Restringido-PII"}
