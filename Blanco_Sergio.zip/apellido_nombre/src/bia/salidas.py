"""Archivos de salida en out/ con el formato EXACTO del enunciado (seccion 5).

  out/consumo_mensual.csv   frontera_id,mes,consumo_kwh,horas_con_dato
  out/dq_report.json        12 llaves, todas obligatorias, en este orden
  out/metrics.json          (ver metricas.py)

Escritura atomica: se escribe a un temporal y se renombra. Un lector (el evaluador,
un proceso que mire out/ mientras corre) o ve el archivo anterior completo o el nuevo
completo; nunca uno a medias. Y si el proceso muere a mitad, no queda basura valida.
"""
from __future__ import annotations

import json
import os
import tempfile
from decimal import Decimal
from pathlib import Path

DQ_CLAVES = (
    "filas_leidas",
    "duplicados_exactos",
    "duplicados_conflictivos",
    "registros_negativos",
    "registros_nulos",
    "registros_outlier",
    "registros_mwh_convertidos",
    "correcciones_tardias_aplicadas",
    "horas_sin_lectura_valida_total",
    "horas_sin_lectura_valida_por_frontera",
    "fronteras_huerfanas_facturacion",
    "clientes_con_pii_en_texto_libre",
)

ENCABEZADO_CONSUMO = "frontera_id,mes,consumo_kwh,horas_con_dato"


def _escribir_atomico(ruta: Path, contenido: str) -> None:
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=ruta.parent, prefix=f".{ruta.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(contenido)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, ruta)                     # atomico en el mismo sistema de archivos
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def escribir_json(ruta: Path, objeto) -> None:
    _escribir_atomico(ruta, json.dumps(objeto, indent=2, ensure_ascii=False) + "\n")


# ------------------------------------------------------------------ dq_report.json
def construir_dq_report(dq_consumos: dict, fronteras_huerfanas_facturacion: int,
                        clientes_con_pii: int) -> dict:
    """Todas las llaves obligatorias, solo ellas, y en el orden del enunciado."""
    completo = dict(dq_consumos)
    completo["fronteras_huerfanas_facturacion"] = fronteras_huerfanas_facturacion
    completo["clientes_con_pii_en_texto_libre"] = clientes_con_pii
    faltan = [k for k in DQ_CLAVES if k not in completo]
    if faltan:
        raise ValueError(f"dq_report incompleto, faltan: {faltan}")
    reporte = {k: completo[k] for k in DQ_CLAVES}
    reporte["horas_sin_lectura_valida_por_frontera"] = dict(
        sorted(reporte["horas_sin_lectura_valida_por_frontera"].items()))
    return reporte


# -------------------------------------------------------------- consumo_mensual.csv
def consultar_consumo_mensual(cur) -> list[tuple[str, str, Decimal, int]]:
    """Desde la BASE (la fuente de verdad persistida), una fila por frontera-mes con al
    menos una lectura valida. Es la misma definicion que analytics.v_consumo_mensual."""
    cur.execute("""
        SELECT frontera_id, mes, round(sum(consumo_kwh), 3), count(*)::int
        FROM core.fact_consumo_horario
        WHERE estado = 'VALIDA'
        GROUP BY frontera_id, mes
        ORDER BY frontera_id, mes""")
    return [(f, m, Decimal(v), int(h)) for f, m, v, h in cur.fetchall()]


def escribir_consumo_mensual(ruta: Path, filas) -> int:
    lineas = [ENCABEZADO_CONSUMO]
    for frontera, mes, consumo, horas in filas:
        lineas.append(f"{frontera},{mes},{Decimal(consumo):.3f},{horas}")   # siempre 3 decimales
    _escribir_atomico(ruta, "\n".join(lineas) + "\n")
    return len(filas)
