"""Escritura a Postgres: maestros, facturas, consumos, cuarentena y libro de archivos.

TODAS las sentencias llevan parametros (%s) y los datos viajan por separado del SQL:
una razon social como  Robert'); DROP TABLE core.fact_consumo_horario;--  es un
simple texto que se guarda tal cual, no una instruccion (B7, eliminatoria 3).

Idempotencia: cada upsert actualiza SOLO si el contenido cambio, y devuelve cuantas
filas se insertaron o modificaron DE VERDAD (RETURNING sobre un ON CONFLICT con WHERE
solo devuelve las filas que cambiaron). Asi la segunda corrida informa 0 y esa cifra
es, ademas de una metrica, la prueba de que no se reescribio nada.

  * clientes: se compara la HUELLA del contenido (el cifrado es aleatorio: comparar
    cifrados diria 'distinto' siempre y reescribiria toda la tabla).
  * consumos: gana la tupla (version, archivo, fila) mayor (B3), con orden de
    archivo por codigo de caracter (la columna es COLLATE "C"): independiente del
    orden de carga y de la locale del servidor.

Todas las funciones reciben un cursor: la transaccion la controla quien las llama.
"""
from __future__ import annotations

import uuid
from collections.abc import Sequence
from dataclasses import dataclass

from psycopg2.extras import execute_values

from .calidad import Ganadora
from .facturacion import FacturaFila
from .maestros import ClienteFila, FronteraFila
from .rechazo import Rechazo

_PAGINA = 2000
_PAGINA_CONSUMOS = 5000


def _ejecutar(cur, sql: str, filas: Sequence, template: str | None = None, pagina: int = _PAGINA) -> int:
    """execute_values + RETURNING: cuenta solo las filas realmente insertadas/modificadas."""
    if not filas:
        return 0
    devueltas = execute_values(cur, sql, filas, template=template, page_size=pagina, fetch=True)
    return len(devueltas)


def upsert_clientes(cur, clientes: Sequence[ClienteFila]) -> int:
    return _ejecutar(cur, """
        INSERT INTO core.dim_cliente AS c
          (cliente_id, razon_social, nit_hash, nit_cifrado, email_contacto_cifrado,
           celular_contacto_cifrado, direccion_cifrada, representante_legal_cifrado,
           observaciones_enmascaradas, observaciones_pii_tipos, ciudad, departamento,
           clave_version, huella_contenido)
        VALUES %s
        ON CONFLICT (cliente_id) DO UPDATE SET
          razon_social = EXCLUDED.razon_social, nit_hash = EXCLUDED.nit_hash,
          nit_cifrado = EXCLUDED.nit_cifrado,
          email_contacto_cifrado = EXCLUDED.email_contacto_cifrado,
          celular_contacto_cifrado = EXCLUDED.celular_contacto_cifrado,
          direccion_cifrada = EXCLUDED.direccion_cifrada,
          representante_legal_cifrado = EXCLUDED.representante_legal_cifrado,
          observaciones_enmascaradas = EXCLUDED.observaciones_enmascaradas,
          observaciones_pii_tipos = EXCLUDED.observaciones_pii_tipos,
          ciudad = EXCLUDED.ciudad, departamento = EXCLUDED.departamento,
          clave_version = EXCLUDED.clave_version, huella_contenido = EXCLUDED.huella_contenido
        WHERE c.huella_contenido <> EXCLUDED.huella_contenido
        RETURNING 1
        """,
        [(x.cliente_id, x.razon_social, x.nit_hash, x.nit_cifrado, x.email_contacto_cifrado,
          x.celular_contacto_cifrado, x.direccion_cifrada, x.representante_legal_cifrado,
          x.observaciones_enmascaradas, list(x.observaciones_pii_tipos), x.ciudad,
          x.departamento, x.clave_version, x.huella_contenido) for x in clientes],
        template="(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::text[],%s,%s,%s,%s)")


def upsert_fronteras(cur, fronteras: Sequence[FronteraFila]) -> int:
    return _ejecutar(cur, """
        INSERT INTO core.dim_frontera AS f
          (frontera_id, codigo_sic, cliente_id, mercado, operador_red, nivel_tension,
           fecha_registro, estado, min_kwh, max_kwh)
        VALUES %s
        ON CONFLICT (frontera_id) DO UPDATE SET
          codigo_sic = EXCLUDED.codigo_sic, cliente_id = EXCLUDED.cliente_id,
          mercado = EXCLUDED.mercado, operador_red = EXCLUDED.operador_red,
          nivel_tension = EXCLUDED.nivel_tension, fecha_registro = EXCLUDED.fecha_registro,
          estado = EXCLUDED.estado, min_kwh = EXCLUDED.min_kwh, max_kwh = EXCLUDED.max_kwh
        WHERE (f.codigo_sic, f.cliente_id, f.mercado, f.operador_red, f.nivel_tension,
               f.fecha_registro, f.estado, f.min_kwh, f.max_kwh)
              IS DISTINCT FROM
              (EXCLUDED.codigo_sic, EXCLUDED.cliente_id, EXCLUDED.mercado, EXCLUDED.operador_red,
               EXCLUDED.nivel_tension, EXCLUDED.fecha_registro, EXCLUDED.estado,
               EXCLUDED.min_kwh, EXCLUDED.max_kwh)
        RETURNING 1
        """,
        [(x.frontera_id, x.codigo_sic, x.cliente_id, x.mercado, x.operador_red, x.nivel_tension,
          x.fecha_registro, x.estado, x.min_kwh, x.max_kwh) for x in fronteras])


def upsert_facturas(cur, facturas: Sequence[FacturaFila]) -> tuple[int, int]:
    """-> (facturas, componentes) realmente insertados o modificados."""
    n_fact = _ejecutar(cur, """
        INSERT INTO core.fact_factura AS f
          (factura_id, frontera_id, periodo, cliente_nit_hash, consumo_facturado_kwh,
           tarifa_cop_kwh, valor_total_cop, metodo_pago_tipo, cuenta_enmascarada, archivo_origen)
        VALUES %s
        ON CONFLICT (factura_id) DO UPDATE SET
          frontera_id = EXCLUDED.frontera_id, periodo = EXCLUDED.periodo,
          cliente_nit_hash = EXCLUDED.cliente_nit_hash,
          consumo_facturado_kwh = EXCLUDED.consumo_facturado_kwh,
          tarifa_cop_kwh = EXCLUDED.tarifa_cop_kwh, valor_total_cop = EXCLUDED.valor_total_cop,
          metodo_pago_tipo = EXCLUDED.metodo_pago_tipo,
          cuenta_enmascarada = EXCLUDED.cuenta_enmascarada, archivo_origen = EXCLUDED.archivo_origen
        WHERE (f.frontera_id, f.periodo, f.cliente_nit_hash, f.consumo_facturado_kwh,
               f.tarifa_cop_kwh, f.valor_total_cop, f.metodo_pago_tipo, f.cuenta_enmascarada)
              IS DISTINCT FROM
              (EXCLUDED.frontera_id, EXCLUDED.periodo, EXCLUDED.cliente_nit_hash,
               EXCLUDED.consumo_facturado_kwh, EXCLUDED.tarifa_cop_kwh, EXCLUDED.valor_total_cop,
               EXCLUDED.metodo_pago_tipo, EXCLUDED.cuenta_enmascarada)
        RETURNING 1
        """,
        [(x.factura_id, x.frontera_id, x.periodo, x.cliente_nit_hash, x.consumo_facturado_kwh,
          x.tarifa_cop_kwh, x.valor_total_cop, x.metodo_pago_tipo, x.cuenta_enmascarada, x.archivo)
         for x in facturas])
    n_comp = _ejecutar(cur, """
        INSERT INTO core.fact_factura_componente AS c (factura_id, concepto, valor_cop_kwh)
        VALUES %s
        ON CONFLICT (factura_id, concepto) DO UPDATE SET valor_cop_kwh = EXCLUDED.valor_cop_kwh
        WHERE c.valor_cop_kwh IS DISTINCT FROM EXCLUDED.valor_cop_kwh
        RETURNING 1
        """,
        [(x.factura_id, concepto, valor) for x in facturas for concepto, valor in x.componentes])
    return n_fact, n_comp


def upsert_consumos(cur, ganadoras: Sequence[Ganadora]) -> int:
    """Carga las lecturas ganadoras. El WHERE hace que solo se reemplace una fila existente
    si la nueva GANA (B3): reprocesar o cargar fuera de orden converge al mismo estado."""
    return _ejecutar(cur, """
        INSERT INTO core.fact_consumo_horario AS f
          (frontera_id, ts_utc, consumo_kwh, estado, motivo_invalidez, version_lectura,
           calidad_lectura, unidad_origen, archivo_origen, fila_origen)
        VALUES %s
        ON CONFLICT (frontera_id, ts_utc) DO UPDATE SET
          consumo_kwh = EXCLUDED.consumo_kwh, estado = EXCLUDED.estado,
          motivo_invalidez = EXCLUDED.motivo_invalidez,
          version_lectura = EXCLUDED.version_lectura, calidad_lectura = EXCLUDED.calidad_lectura,
          unidad_origen = EXCLUDED.unidad_origen, archivo_origen = EXCLUDED.archivo_origen,
          fila_origen = EXCLUDED.fila_origen
        WHERE (EXCLUDED.version_lectura, EXCLUDED.archivo_origen, EXCLUDED.fila_origen)
            > (f.version_lectura, f.archivo_origen, f.fila_origen)
        RETURNING 1
        """,
        [(g.frontera_id, g.ts_utc, g.valor_kwh, g.estado, g.motivo_invalidez, g.version_lectura,
          g.calidad_lectura, g.unidad_origen, g.archivo, g.fila) for g in ganadoras],
        pagina=_PAGINA_CONSUMOS)


def contar_consumos(cur) -> int:
    cur.execute("SELECT count(*) FROM core.fact_consumo_horario")
    return cur.fetchone()[0]


def registrar_rechazos(cur, rechazos: Sequence[Rechazo], corrida_id: uuid.UUID | str) -> int:
    """Cuarentena. Reprocesar el mismo archivo no duplica nada (DO NOTHING sobre la clave unica)."""
    return _ejecutar(cur, """
        INSERT INTO quarantine.rechazo
          (fuente, archivo, fila_origen, clave_natural, motivo, detalle, payload_cifrado, corrida_id)
        VALUES %s
        ON CONFLICT (fuente, archivo, fila_origen, motivo) DO NOTHING
        RETURNING 1
        """,
        [(r.fuente, r.archivo, r.fila, r.clave_natural, r.motivo, r.detalle, r.payload_cifrado,
          str(corrida_id)) for r in rechazos],
        template="(%s,%s,%s,%s,%s,%s,%s,%s::uuid)")


# ------------------------------------------------------------- libro de archivos (ops)
@dataclass(frozen=True)
class RegistroArchivo:
    nombre: str
    sha256: str
    fuente: str                 # consumos | facturacion
    estado: str                 # CARGADO | RECHAZADO
    filas_leidas: int
    filas_cargadas: int
    filas_rechazadas: int
    motivo_rechazo: str | None = None


def ledger_cargados(cur) -> dict[str, set[str]]:
    """nombre de archivo -> hashes ya CARGADOS. Un archivo con el mismo hash no se vuelve a cargar."""
    cur.execute("SELECT nombre_archivo, sha256 FROM ops.archivo_cargado WHERE estado = 'CARGADO'")
    visto: dict[str, set[str]] = {}
    for nombre, sha in cur.fetchall():
        visto.setdefault(nombre, set()).add(sha)
    return visto


def ledger_registrar(cur, registros: Sequence[RegistroArchivo], corrida_id: uuid.UUID | str) -> int:
    return _ejecutar(cur, """
        INSERT INTO ops.archivo_cargado
          (nombre_archivo, sha256, fuente, estado, filas_leidas, filas_cargadas,
           filas_rechazadas, motivo_rechazo, corrida_id)
        VALUES %s
        ON CONFLICT (nombre_archivo, sha256) DO NOTHING
        RETURNING 1
        """,
        [(r.nombre, r.sha256, r.fuente, r.estado, r.filas_leidas, r.filas_cargadas,
          r.filas_rechazadas, r.motivo_rechazo, str(corrida_id)) for r in registros],
        template="(%s,%s,%s,%s,%s,%s,%s,%s,%s::uuid)")
