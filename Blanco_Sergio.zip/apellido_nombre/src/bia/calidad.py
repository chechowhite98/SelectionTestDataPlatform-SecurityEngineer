"""Calidad de datos de consumo (Parte B, reglas B3-B5), como funciones PURAS.

Sin base de datos ni E/S: entra una lista de archivos ya leidos, sale un
resultado. Eso lo hace trivial de probar y garantiza determinismo: el mismo
conjunto de archivos da siempre el mismo resultado, venga en el orden que venga.

Orden de las reglas (decision documentada, ver DECISIONS.md):
    B3 deduplicar  ->  B4 validar la lectura GANADORA  ->  B5 huecos
Si la ganadora es invalida, la hora es un hueco: la lectura perdedora, aunque
fuera valida, NO resucita (una correccion invalida invalida la hora).
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal

from . import reglas as R
from .consumos import ArchivoLeido, FilaRechazada, Lectura


@dataclass(frozen=True)
class Ganadora:
    """La lectura que queda para una (frontera, hora): lo que se carga a core."""
    frontera_id: str
    ts_utc: datetime
    valor_kwh: Decimal | None        # None si es invalida (no se imputa)
    estado: str                      # VALIDA | INVALIDA
    motivo_invalidez: str | None     # NULO | NEGATIVO | OUTLIER
    version_lectura: int
    calidad_lectura: str | None
    unidad_origen: str
    archivo: str
    fila: int
    # Valor que se DESCARTO por invalido (B4), para la cuarentena: "lo rechazado no se
    # borra". None si la lectura es valida o si el invalido era un nulo.
    valor_descartado: Decimal | None = None


@dataclass
class ResultadoCalidad:
    ganadoras: list[Ganadora]
    rechazadas: list[FilaRechazada]                 # filas apartadas (cuarentena)
    archivos_rechazados: list[tuple[str, str]]      # (nombre, motivo)
    dq: dict                                        # claves de out/dq_report.json
    rechazos_por_motivo: dict = field(default_factory=dict)
    meses: list[str] = field(default_factory=list)


def _clave_orden(lec: Lectura) -> tuple:
    """B3: gana la mayor version; si empatan, la ultima en orden de archivo
    (nombre, orden lexicografico) y, dentro del archivo, la ultima fila."""
    return (lec.version_lectura, lec.archivo, lec.fila)


def _clasificar_valor(valor: Decimal | None) -> tuple[str, str | None]:
    """B4: valor nulo/vacio, negativo o > 1.000.000 kWh -> invalido (se descarta)."""
    if valor is None:
        return R.INVALIDA, R.NULO
    if valor < 0:
        return R.INVALIDA, R.NEGATIVO
    if valor > R.UMBRAL_OUTLIER_KWH:
        return R.INVALIDA, R.OUTLIER
    return R.VALIDA, None


def resolver(archivos: list[ArchivoLeido], fronteras_validas: set[str] | None = None) -> ResultadoCalidad:
    """Aplica B3, B4 y B5 sobre todos los archivos aceptados.

    fronteras_validas: ids del maestro. Una lectura de una frontera que no existe
    en el maestro no puede cargarse (clave foranea) y va a cuarentena.
    """
    rechazadas: list[FilaRechazada] = []
    archivos_rechazados = [(a.nombre, a.motivo_rechazo) for a in archivos if a.estado == "RECHAZADO"]
    aceptados = [a for a in archivos if a.estado == "OK"]
    for a in aceptados:
        rechazadas.extend(a.rechazadas)

    # Las lecturas se procesan en orden lexicografico de archivo (B3); resolver es
    # independiente del orden en que lleguen los archivos en la lista.
    lecturas: list[Lectura] = []
    for a in sorted(aceptados, key=lambda x: x.nombre):
        for lec in a.lecturas:
            if fronteras_validas is not None and lec.frontera_id not in fronteras_validas:
                rechazadas.append(FilaRechazada(lec.archivo, lec.fila, R.M_FRONTERA_DESCONOCIDA))
            else:
                lecturas.append(lec)

    # --- B3: ganadora por (frontera, hora) --------------------------------------
    mejor: dict[tuple, Lectura] = {}
    for lec in lecturas:
        k = (lec.frontera_id, lec.ts_utc)
        if k not in mejor or _clave_orden(lec) > _clave_orden(mejor[k]):
            mejor[k] = lec

    exactos = conflictivos = 0
    grupos_con_correccion: set[tuple] = set()
    for lec in lecturas:
        k = (lec.frontera_id, lec.ts_utc)
        gan = mejor[k]
        if lec is gan:
            continue
        if lec.version_lectura < gan.version_lectura:
            grupos_con_correccion.add(k)            # reemplazada por una version mayor
        elif lec.valor_kwh == gan.valor_kwh:
            exactos += 1                            # misma version, mismo valor
        else:
            conflictivos += 1                       # misma version, valor distinto

    # --- B4: validar la ganadora ---------------------------------------------------
    ganadoras: list[Ganadora] = []
    negativos = nulos = outliers = 0
    for k in sorted(mejor):
        lec = mejor[k]
        estado, motivo = _clasificar_valor(lec.valor_kwh)
        if motivo == R.NULO:
            nulos += 1
        elif motivo == R.NEGATIVO:
            negativos += 1
        elif motivo == R.OUTLIER:
            outliers += 1
        ganadoras.append(Ganadora(
            lec.frontera_id, lec.ts_utc,
            lec.valor_kwh if estado == R.VALIDA else None,
            estado, motivo, lec.version_lectura, lec.calidad_lectura,
            lec.unidad_origen, lec.archivo, lec.fila,
            lec.valor_kwh if estado == R.INVALIDA else None))

    # --- B5: huecos ---------------------------------------------------------------
    meses = sorted({R.mes_local(g.ts_utc) for g in ganadoras})
    fronteras = sorted(fronteras_validas if fronteras_validas is not None
                       else {g.frontera_id for g in ganadoras})
    huecos = calcular_huecos(ganadoras, fronteras, meses)

    dq = {
        "filas_leidas": sum(a.filas_leidas for a in aceptados),
        "duplicados_exactos": exactos,
        "duplicados_conflictivos": conflictivos,
        "registros_negativos": negativos,
        "registros_nulos": nulos,
        "registros_outlier": outliers,
        "registros_mwh_convertidos": sum(a.convertidas_a_kwh for a in aceptados),
        "correcciones_tardias_aplicadas": len(grupos_con_correccion),
        "horas_sin_lectura_valida_total": sum(huecos.values()),
        "horas_sin_lectura_valida_por_frontera": huecos,
    }
    motivos = Counter(r.motivo for r in rechazadas)
    motivos.update(m for _, m in archivos_rechazados)
    return ResultadoCalidad(ganadoras, rechazadas, archivos_rechazados, dq, dict(motivos), meses)


def calcular_huecos(ganadoras: list[Ganadora], fronteras: list[str], meses: list[str]) -> dict[str, int]:
    """B5: horas sin lectura VALIDA por frontera, sobre los meses cargados.

    Hueco = hora esperada (calendario) sin ganadora valida: da igual si la fila no
    existia o si existia y fue descartada por B4. Se reportan, no se rellenan.
    Solo aparecen las fronteras con al menos un hueco.
    """
    validas = Counter((g.frontera_id, R.mes_local(g.ts_utc)) for g in ganadoras if g.estado == R.VALIDA)
    por_frontera: dict[str, int] = {}
    for f in fronteras:
        faltan = sum(R.horas_del_mes(m) - validas[(f, m)] for m in meses)
        if faltan:
            por_frontera[f] = faltan
    return por_frontera


def consumo_mensual(ganadoras: list[Ganadora]) -> list[tuple[str, str, Decimal, int]]:
    """(frontera_id, mes, consumo_kwh a 3 decimales, horas_con_dato) para cada
    combinacion con al menos una lectura valida. Misma definicion que la vista
    analytics.v_consumo_mensual; sirve para contrastar y para tests."""
    suma: dict[tuple, Decimal] = {}
    horas: Counter = Counter()
    for g in ganadoras:
        if g.estado != R.VALIDA:
            continue
        k = (g.frontera_id, R.mes_local(g.ts_utc))
        suma[k] = suma.get(k, Decimal(0)) + g.valor_kwh
        horas[k] += 1
    cuantum = Decimal("0.001")
    return [(f, m, suma[(f, m)].quantize(cuantum, rounding=ROUND_HALF_UP), horas[(f, m)])
            for (f, m) in sorted(suma)]
