"""Rechazo hacia la zona de cuarentena (quarantine.rechazo)."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Rechazo:
    fuente: str                          # clientes | fronteras | facturacion | consumos | stream
    archivo: str
    fila: int                            # 0 = rechazo a nivel de archivo
    motivo: str                          # codigo estable, p.ej. FRONTERA_HUERFANA
    clave_natural: str | None = None     # id tecnico NO personal (cliente_id, factura_id)
    detalle: str | None = None           # solo codigos; jamas contenido de la fila
    payload_cifrado: bytes | None = None # la fila original, cifrada (puede traer PII)


# Motivos de rechazo de maestros y facturacion (codigos estables para metricas y runbook)
M_NUM_CAMPOS = "NUM_CAMPOS_INVALIDO"
M_CLIENTE_ID_INVALIDO = "CLIENTE_ID_INVALIDO"
M_CLIENTE_DUPLICADO = "CLIENTE_DUPLICADO"
M_RAZON_SOCIAL_VACIA = "RAZON_SOCIAL_VACIA"
M_NIT_INVALIDO = "NIT_INVALIDO"
M_NIT_DUPLICADO = "NIT_DUPLICADO"
M_FRONTERA_INVALIDA = "FRONTERA_INVALIDA"
M_FRONTERA_DUPLICADA = "FRONTERA_DUPLICADA"
M_FRONTERA_DESCONOCIDA = "FRONTERA_DESCONOCIDA"
M_CLIENTE_INEXISTENTE = "CLIENTE_INEXISTENTE"
M_VALOR_INVALIDO = "VALOR_INVALIDO"
M_BANDA_INVALIDA = "BANDA_INVALIDA"
M_ARCHIVO_INVALIDO = "ARCHIVO_INVALIDO"
M_FACTURA_INVALIDA = "FACTURA_INVALIDA"
M_FACTURA_DUPLICADA = "FACTURA_DUPLICADA"
M_FRONTERA_HUERFANA = "FRONTERA_HUERFANA"     # B6
