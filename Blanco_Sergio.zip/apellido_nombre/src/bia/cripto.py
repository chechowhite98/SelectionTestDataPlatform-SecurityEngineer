"""Cifrado a nivel de aplicacion (C3): AES-256-GCM + indice ciego HMAC-SHA256.

Por que a nivel de aplicacion y no pgcrypto: con pgcrypto la llave viajaria dentro
de la sentencia SQL y quedaria en pg_stat_statements, en el log del servidor y en
el historial de quien tenga acceso a la sesion. Aqui la llave nunca entra a la
base: quien se roba un dump, o es DBA, ve solo bytes opacos.

Formato de cada valor cifrado (contrato con el dominio SQL core.pii_cifrado):

    version_de_llave (1 B) || nonce (12 B) || texto_cifrado (n B) || tag GCM (16 B)

  * La version de llave permite rotar: se cifra con la actual y se descifra con
    cualquiera de las anteriores.
  * El nonce es aleatorio por valor (96 bits).
  * Contexto (AAD): cada valor queda atado a "tabla.columna|id_de_registro". Si
    alguien con acceso de escritura copia el NIT cifrado del cliente A a la fila
    del cliente B, el descifrado FALLA en vez de entregar un dato equivocado.

Indice ciego: para hacer JOIN por un campo sensible (el NIT) sin exponerlo se
guarda HMAC-SHA256(llave_indice, valor_normalizado). Es determinista (permite
igualdad) pero irreversible sin la llave, y usa una llave DISTINTA a la de cifrado.

Riesgo residual (va al threat model): el proceso de ingesta tiene las llaves en su
entorno, asi que un proceso de ingesta comprometido puede descifrar. En AWS la
llave vive en KMS y la politica del rol limita quien puede usarla (ver infra/).
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import os
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

NONCE_LEN = 12
TAG_LEN = 16
LARGO_MINIMO = 1 + NONCE_LEN + TAG_LEN      # 29: igual que el CHECK de core.pii_cifrado
LARGO_LLAVE = 32                            # AES-256 / HMAC-SHA256


class ErrorCripto(Exception):
    """Fallo criptografico. El mensaje NUNCA incluye llaves ni datos en claro."""


class ConfiguracionInvalida(ErrorCripto):
    """Faltan llaves o son inseguras: el pipeline no debe arrancar."""


@dataclass(frozen=True, repr=False)
class Llaves:
    cifrado: dict            # version (int) -> llave de 32 bytes
    version_actual: int
    indice: bytes

    def __repr__(self) -> str:   # jamas imprimir material de llave (logs, trazas)
        return f"Llaves(versiones={sorted(self.cifrado)}, actual={self.version_actual}, <secretas>)"


def _decodificar_llave(b64: str, nombre: str) -> bytes:
    try:
        llave = base64.b64decode(b64.strip(), validate=True)
    except (binascii.Error, ValueError):
        raise ConfiguracionInvalida(f"{nombre}: no es base64 valido") from None
    if len(llave) != LARGO_LLAVE:
        raise ConfiguracionInvalida(f"{nombre}: debe tener {LARGO_LLAVE} bytes, tiene {len(llave)}")
    if len(set(llave)) < 16:    # una llave aleatoria de 32 B tiene ~28 bytes distintos
        raise ConfiguracionInvalida(f"{nombre}: entropia insuficiente (parece una llave de relleno)")
    return llave


def cargar_llaves(env: Mapping[str, str] | None = None) -> Llaves:
    """Lee las llaves del entorno. Falla rapido y sin revelar nada.

    BIA_ENC_KEYS   "1:<base64>[,2:<base64>...]"   llaves de cifrado por version
    BIA_ENC_KEY_VERSION  (opcional)               version con la que se cifra; defecto: la mayor
    BIA_INDEX_KEY  "<base64>"                     llave del indice ciego (distinta a las anteriores)
    Cada llave son 32 bytes en base64. Generarlas con:  python -m bia.cripto
    """
    env = os.environ if env is None else env
    crudo = (env.get("BIA_ENC_KEYS") or "").strip()
    crudo_idx = (env.get("BIA_INDEX_KEY") or "").strip()
    if not crudo:
        raise ConfiguracionInvalida("falta BIA_ENC_KEYS (generar con: python -m bia.cripto)")
    if not crudo_idx:
        raise ConfiguracionInvalida("falta BIA_INDEX_KEY (generar con: python -m bia.cripto)")

    llaves: dict[int, bytes] = {}
    for par in crudo.split(","):
        version_txt, sep, b64 = par.strip().partition(":")
        if not sep or not re.fullmatch(r"\d{1,3}", version_txt) or not 1 <= int(version_txt) <= 255:
            raise ConfiguracionInvalida("BIA_ENC_KEYS: formato esperado 'version:base64[,version:base64]' (version 1-255)")
        version = int(version_txt)
        if version in llaves:
            raise ConfiguracionInvalida(f"BIA_ENC_KEYS: version {version} repetida")
        llaves[version] = _decodificar_llave(b64, f"BIA_ENC_KEYS[{version}]")

    actual_txt = (env.get("BIA_ENC_KEY_VERSION") or "").strip()
    actual = int(actual_txt) if actual_txt.isdigit() else max(llaves)
    if actual not in llaves:
        raise ConfiguracionInvalida(f"BIA_ENC_KEY_VERSION={actual} no esta en BIA_ENC_KEYS")

    indice = _decodificar_llave(crudo_idx, "BIA_INDEX_KEY")
    if indice in llaves.values():
        raise ConfiguracionInvalida("BIA_INDEX_KEY debe ser distinta a las llaves de cifrado (separacion de llaves)")
    return Llaves(llaves, actual, indice)


def generar_llave() -> str:
    """32 bytes aleatorios en base64."""
    return base64.b64encode(os.urandom(LARGO_LLAVE)).decode()


class Cifrador:
    def __init__(self, llaves: Llaves):
        self._aead = {v: AESGCM(k) for v, k in llaves.cifrado.items()}
        self._version = llaves.version_actual
        self._indice = llaves.indice

    @property
    def version_actual(self) -> int:
        return self._version

    # ------------------------------------------------------------------ cifrado
    def cifrar(self, dato: str | bytes, contexto: str) -> bytes:
        """Cifra y ata el resultado a `contexto` (p.ej. 'core.dim_cliente.nit_cifrado|CLI0001')."""
        crudo = dato.encode("utf-8") if isinstance(dato, str) else dato
        nonce = os.urandom(NONCE_LEN)
        cifrado = self._aead[self._version].encrypt(nonce, crudo, contexto.encode("utf-8"))
        return bytes([self._version]) + nonce + cifrado

    def descifrar(self, blob: bytes, contexto: str) -> bytes:
        blob = bytes(blob)
        if len(blob) < LARGO_MINIMO:
            raise ErrorCripto("valor cifrado demasiado corto")
        version = blob[0]
        if version not in self._aead:
            raise ErrorCripto(f"version de llave desconocida ({version})")
        try:
            return self._aead[version].decrypt(blob[1:1 + NONCE_LEN], blob[1 + NONCE_LEN:],
                                               contexto.encode("utf-8"))
        except InvalidTag:
            raise ErrorCripto("autenticacion fallida: dato alterado o contexto distinto") from None

    def descifrar_texto(self, blob: bytes, contexto: str) -> str:
        return self.descifrar(blob, contexto).decode("utf-8")

    def necesita_rotacion(self, blob: bytes) -> bool:
        """True si el valor se cifro con una version de llave que ya no es la actual."""
        return bytes(blob)[0] != self._version

    # ------------------------------------------------------- indice ciego y huella
    def indice_ciego(self, valor_normalizado: str) -> bytes:
        """HMAC-SHA256 determinista: permite JOIN por igualdad sin exponer el valor."""
        return hmac.new(self._indice, b"idx|" + valor_normalizado.encode("utf-8"), hashlib.sha256).digest()

    def huella(self, partes: Sequence[str | None]) -> bytes:
        """Huella del contenido (en claro) de un registro. Se guarda junto al registro
        para saber si CAMBIO sin descifrar nada: el cifrado es aleatorio, asi que
        comparar cifrados diria siempre 'distinto' y cada corrida reescribiria todo.
        Dominio separado del indice ciego (prefijo distinto)."""
        canonico = json.dumps(list(partes), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return hmac.new(self._indice, b"fp|" + canonico, hashlib.sha256).digest()


def normalizar_nit(crudo: str) -> str | None:
    """'900.123.456-7', 'NIT 900123456-7', '9001234567' -> '9001234567'.

    Solo digitos (incluye el digito de verificacion). Sin esto, el mismo NIT en dos
    formatos daria dos hashes distintos y los JOIN fallarian en silencio.
    Devuelve None si no tiene entre 9 y 10 digitos.
    """
    digitos = re.sub(r"\D", "", crudo or "")
    return digitos if 9 <= len(digitos) <= 10 else None


if __name__ == "__main__":
    # python -m bia.cripto  ->  lineas listas para pegar en .env (make up las usa si faltan)
    print(f"BIA_ENC_KEYS=1:{generar_llave()}")
    print(f"BIA_INDEX_KEY={generar_llave()}")
