"""Parte D: consumidor de streaming que emite alertas (out/alertas.json).

Estructura (a proposito, para poder probar la logica sin un broker):
  * `Detector`      logica PURA: recibe eventos uno a uno y devuelve alertas. Sin I/O.
  * `leer_kafka`    capa fina que lee el topico y TERMINA SOLA (sin consumidor colgado).
  * `ejecutar`      une todo: lee, detecta, escribe out/alertas.json de forma atomica y loguea.

Reglas (exactas, del enunciado):
  FRONTERA_SIN_REPORTE   3 intervalos consecutivos de 15 min sin medicion. UNA alerta por caida;
                         ts = el del TERCER intervalo ausente.
  CONSUMO_FUERA_DE_BANDA kwh ESTRICTAMENTE mayor que max_kwh de la frontera. ts = el de la medicion.
  LECTURA_RETROACTIVA    ts_medicion anterior a la ultima ya procesada de esa frontera. ts = el de la
                         medicion tardia.

Decisiones de robustez (ver DECISIONS.md):
  * Se deduplica por evento_id: si el topico se publica dos veces (p.ej. el evaluador corre el
    productor y ademas `make stream` publica), el resultado no cambia.
  * Un evento mal formado (JSON roto, campos que faltan, kwh no numerico, ts sin zona) se cuenta
    y se descarta; nunca tumba el consumidor ni entra en las alertas.
  * La caida se detecta de forma incremental (al llegar el siguiente evento de la frontera) y, al
    cerrar el stream, tambien la cola del dia (una frontera que calla hasta las 23:45).
  * Las comparaciones de banda usan Decimal (no float) para que "estrictamente mayor" sea exacto.
"""
from __future__ import annotations

import csv
import json
import math
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Iterable, Iterator

from .logs import LogJson, nuevo_id_corrida
from .salidas import escribir_json

BOGOTA = timezone(timedelta(hours=-5))                      # Colombia no tiene horario de verano
INICIO_DIA = datetime(2026, 6, 1, 0, 0, tzinfo=BOGOTA)
INTERVALO = timedelta(minutes=15)
N_INTERVALOS = 96
SIN_REPORTE_UMBRAL = 3

FRONTERA_SIN_REPORTE = "FRONTERA_SIN_REPORTE"
CONSUMO_FUERA_DE_BANDA = "CONSUMO_FUERA_DE_BANDA"
LECTURA_RETROACTIVA = "LECTURA_RETROACTIVA"


class EventoInvalido(ValueError):
    """Motivo corto y SIN datos del evento (el mensaje va a los logs)."""


@dataclass(frozen=True)
class Evento:
    evento_id: str
    frontera_id: str
    ts: datetime
    kwh: Decimal


def parsear_evento(crudo) -> Evento:
    if not isinstance(crudo, dict):
        raise EventoInvalido("no_es_objeto")
    eid, fid, tsraw, kwh = (crudo.get(k) for k in ("evento_id", "frontera_id", "ts_medicion", "kwh"))
    if not isinstance(eid, str) or not eid or not isinstance(fid, str) or not fid:
        raise EventoInvalido("falta_id")
    if not isinstance(tsraw, str):
        raise EventoInvalido("ts_invalido")
    try:
        ts = datetime.fromisoformat(tsraw.strip().replace("Z", "+00:00"))
    except ValueError:
        raise EventoInvalido("ts_invalido") from None
    if ts.tzinfo is None:
        raise EventoInvalido("ts_sin_zona")                  # ambiguo: no se adivina la zona
    if isinstance(kwh, bool) or not isinstance(kwh, (int, float)) or (isinstance(kwh, float) and not math.isfinite(kwh)):
        raise EventoInvalido("kwh_invalido")
    return Evento(eid, fid, ts.astimezone(BOGOTA), Decimal(repr(kwh)))


def iso(ts: datetime) -> str:
    return ts.astimezone(BOGOTA).isoformat()


def cargar_limites(ruta: Path) -> dict[str, Decimal]:
    limites: dict[str, Decimal] = {}
    with open(ruta, newline="", encoding="utf-8-sig") as fh:
        for fila in csv.DictReader(fh):
            try:
                limites[fila["frontera_id"].strip()] = Decimal(fila["max_kwh"].strip())
            except (KeyError, AttributeError, InvalidOperation):
                continue
    if not limites:
        raise ValueError("limites_frontera.csv vacio o ilegible")
    return limites


@dataclass
class _Estado:
    ultimo_ts: datetime | None = None            # ultima medicion procesada (por ts, no por llegada)
    ultimo_slot: int = -1                        # ultimo intervalo del dia visto


@dataclass
class Detector:
    limites: dict[str, Decimal]
    _estado: dict[str, _Estado] = field(default_factory=dict)
    _vistos: set[str] = field(default_factory=set)
    _alertas: dict[tuple, dict] = field(default_factory=dict)
    leidos: int = 0
    duplicados: int = 0
    invalidos: dict[str, int] = field(default_factory=dict)
    sin_limite: set[str] = field(default_factory=set)

    # ------------------------------------------------------------------ entrada
    def procesar_crudo(self, crudo) -> None:
        self.leidos += 1
        try:
            ev = parsear_evento(crudo)
        except EventoInvalido as e:
            self.invalidos[str(e)] = self.invalidos.get(str(e), 0) + 1
            return
        self.procesar(ev)

    def procesar(self, ev: Evento) -> None:
        if ev.evento_id in self._vistos:
            self.duplicados += 1
            return
        self._vistos.add(ev.evento_id)
        st = self._estado.setdefault(ev.frontera_id, _Estado())

        # 1) retroactiva: estrictamente anterior a la ultima YA procesada (igual no cuenta)
        if st.ultimo_ts is not None and ev.ts < st.ultimo_ts:
            self._alerta(LECTURA_RETROACTIVA, ev.frontera_id, ev.ts)
        else:
            st.ultimo_ts = ev.ts

        # 2) banda: estrictamente mayor
        maximo = self.limites.get(ev.frontera_id)
        if maximo is None:
            self.sin_limite.add(ev.frontera_id)          # sin limite conocido no se puede alertar
        elif ev.kwh > maximo:
            self._alerta(CONSUMO_FUERA_DE_BANDA, ev.frontera_id, ev.ts)

        # 3) caidas: solo avanza con intervalos del dia nuevos (una tardia no reabre nada)
        slot = int((ev.ts - INICIO_DIA) // INTERVALO)
        if 0 <= slot < N_INTERVALOS and slot > st.ultimo_slot:
            self._hueco(ev.frontera_id, st.ultimo_slot, slot)
            st.ultimo_slot = slot

    def cerrar(self) -> None:
        """Fin del stream: la cola del dia tambien cuenta (la frontera que calla hasta el final)."""
        for fid, st in self._estado.items():
            self._hueco(fid, st.ultimo_slot, N_INTERVALOS)

    # ------------------------------------------------------------------ salida
    def alertas(self) -> list[dict]:
        return sorted(self._alertas.values(), key=lambda a: (a["tipo"], a["frontera_id"], a["ts"]))

    def conteo(self) -> dict[str, int]:
        c: dict[str, int] = {}
        for a in self._alertas.values():
            c[a["tipo"]] = c.get(a["tipo"], 0) + 1
        return c

    # ------------------------------------------------------------------ internos
    def _hueco(self, fid: str, anterior: int, siguiente: int) -> None:
        """Intervalos ausentes: anterior+1 .. siguiente-1. >=3 -> UNA alerta en el tercero."""
        if siguiente - anterior - 1 >= SIN_REPORTE_UMBRAL:
            tercero = anterior + SIN_REPORTE_UMBRAL
            self._alerta(FRONTERA_SIN_REPORTE, fid, INICIO_DIA + tercero * INTERVALO)

    def _alerta(self, tipo: str, fid: str, ts: datetime) -> None:
        clave = (tipo, fid, iso(ts))                      # sin duplicados (exigido por el contrato)
        self._alertas.setdefault(clave, {"tipo": tipo, "frontera_id": fid, "ts": iso(ts)})


# ---------------------------------------------------------------------------------- fuentes
def leer_ndjson(ruta: Path) -> Iterator[object]:
    """Fuente sin broker (pruebas y modo --archivo). Una linea rota se entrega como None."""
    with open(ruta, encoding="utf-8") as fh:
        for linea in fh:
            if linea.strip():
                try:
                    yield json.loads(linea)
                except ValueError:
                    yield None


def _bootstrap_listo(bootstrap: str, espera_s: float):
    """Reintenta hasta que el broker responda (el compose espera healthcheck, pero no sobra)."""
    from kafka import KafkaConsumer
    from kafka.errors import NoBrokersAvailable
    limite = time.monotonic() + espera_s
    while True:
        try:
            return KafkaConsumer(bootstrap_servers=bootstrap, group_id=None, enable_auto_commit=False,
                                 auto_offset_reset="earliest", request_timeout_ms=30000)
        except NoBrokersAvailable:
            if time.monotonic() > limite:
                raise
            time.sleep(2)


def publicar_archivo(bootstrap: str, topic: str, archivo: Path) -> int:
    """Publica el ndjson con la misma clave que tools/producer.py (frontera_id => orden por frontera)."""
    from kafka import KafkaProducer
    prod = KafkaProducer(bootstrap_servers=bootstrap, acks="all", retries=5,
                         key_serializer=lambda k: k.encode("utf-8"),
                         value_serializer=lambda v: json.dumps(v).encode("utf-8"))
    n = 0
    for crudo in leer_ndjson(archivo):
        if isinstance(crudo, dict) and isinstance(crudo.get("frontera_id"), str):
            prod.send(topic, key=crudo["frontera_id"], value=crudo)
            n += 1
    prod.flush(timeout=60)
    prod.close()
    return n


def leer_kafka(bootstrap: str, topic: str, *, archivo_para_publicar: Path | None = None,
               ocioso_s: float = 6.0, maximo_s: float = 200.0, espera_broker_s: float = 90.0,
               log: LogJson | None = None) -> Iterator[object]:
    """Lee `topic` desde el inicio y TERMINA cuando (a) ya llego al final conocido y
    (b) pasaron `ocioso_s` sin mensajes nuevos, o (c) vence `maximo_s` (tope duro < 300 s del
    evaluador). Sin grupo ni offsets guardados: cada corrida relee todo y da el mismo resultado.
    Si el topico esta vacio y se indico un archivo, lo publica (el evaluador no avisa quien produce)."""
    from kafka import TopicPartition
    from kafka.errors import KafkaError

    inicio = time.monotonic()
    consumidor = _bootstrap_listo(bootstrap, espera_broker_s)
    try:
        # el topico puede no existir aun: pedir metadata lo crea (auto-create de Redpanda)
        particiones = None
        while particiones is None and time.monotonic() - inicio < espera_broker_s:
            particiones = consumidor.partitions_for_topic(topic)
            if particiones is None:
                time.sleep(1)
        if not particiones:
            if archivo_para_publicar is None:
                raise RuntimeError("el topico no existe y no hay archivo para publicar")
            particiones = {0}
        tps = [TopicPartition(topic, p) for p in sorted(particiones)]
        consumidor.assign(tps)
        consumidor.seek_to_beginning(*tps)

        if archivo_para_publicar is not None and sum(consumidor.end_offsets(tps).values()) == 0:
            n = publicar_archivo(bootstrap, topic, archivo_para_publicar)
            if log:
                log.evento("stream_publicado", eventos=n)

        ultimo_mensaje = time.monotonic()
        while time.monotonic() - inicio < maximo_s:
            lote = consumidor.poll(timeout_ms=1000)
            if lote:
                ultimo_mensaje = time.monotonic()
                for registros in lote.values():
                    for r in registros:
                        try:
                            yield json.loads(r.value)
                        except (ValueError, TypeError):
                            yield None
                continue
            finales = consumidor.end_offsets(tps)
            al_dia = all(consumidor.position(tp) >= finales[tp] for tp in tps)
            if al_dia and time.monotonic() - ultimo_mensaje >= ocioso_s:
                return
        if log:
            log.evento("stream_tope_de_tiempo", nivel="WARNING", segundos=int(maximo_s))
    except KafkaError:
        raise
    finally:
        consumidor.close()


# ---------------------------------------------------------------------------------- orquestacion
def ejecutar(env=None, *, archivo: Path | None = None) -> int:
    """0 = alertas.json escrito. 1 = error (broker inaccesible, limites ilegibles...)."""
    env = os.environ if env is None else env
    data = Path(env.get("BIA_DATA_DIR") or "data")
    out = Path(env.get("BIA_OUT_DIR") or "out")
    log = LogJson(Path(env.get("BIA_LOGS_DIR") or "logs") / "pipeline.log", nuevo_id_corrida())
    t0 = time.monotonic()
    log.evento("stream_inicio", modo="archivo" if archivo else "kafka")
    try:
        limites = cargar_limites(data / "maestros" / "limites_frontera.csv")
        det = Detector(limites)
        fuente_ndjson = data / "eventos" / "mediciones_stream.ndjson"
        if archivo:
            fuente: Iterable = leer_ndjson(archivo)
        else:
            fuente = leer_kafka(env.get("KAFKA_BOOTSTRAP", "localhost:9092"),
                                env.get("KAFKA_TOPIC", "mediciones.raw"),
                                archivo_para_publicar=fuente_ndjson if fuente_ndjson.is_file() else None,
                                log=log)
        for crudo in fuente:
            det.procesar_crudo(crudo)
        det.cerrar()
        escribir_json(out / "alertas.json", det.alertas())
        log.evento("stream_fin", resultado="OK", eventos_leidos=det.leidos, duplicados_descartados=det.duplicados,
                   eventos_invalidos=det.invalidos, fronteras_sin_limite=len(det.sin_limite),
                   alertas_por_tipo=det.conteo(), duracion_s=round(time.monotonic() - t0, 2))
        return 0
    except Exception as e:                                 # noqa: BLE001 - se registra la clase, no el mensaje
        log.error("stream_fin", e, resultado="ERROR", duracion_s=round(time.monotonic() - t0, 2))
        return 1
    finally:
        log.cerrar()
