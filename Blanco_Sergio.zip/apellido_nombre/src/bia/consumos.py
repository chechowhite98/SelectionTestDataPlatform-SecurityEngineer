"""Lectura robusta de archivos de consumo (Parte A, "descubrimiento" y robustez).

Principio: el formato se DETECTA mirando el contenido, nunca se asume por el
nombre del archivo ni por una lista fija de meses. Dos veredictos posibles:

  * Archivo RECHAZADO ENTERO: ilegible, binario, truncado, encabezado
    desconocido o demasiadas filas malas. No aporta ninguna lectura, asi que
    JAMAS puede alterar lo ya cargado.
  * Archivo ACEPTADO: las filas buenas pasan; las filas malas se apartan con su
    motivo (cuarentena), sin perderse en silencio.

Lo que NO hace este modulo: deduplicar, validar rangos ni calcular huecos. Eso
es calidad.py. Aqui solo se entiende el archivo y se normaliza (B1, B2).

Nada de lo que se registra aqui contiene contenido de las filas: solo numero de
fila y codigo de motivo (el log no puede filtrar datos, ver Parte E).
"""
from __future__ import annotations

import csv
import hashlib
import io
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path

from . import reglas as R
from .texto import decodificar, normalizar_nombre

# --------------------------------------------------------------------------- tipos
@dataclass(frozen=True)
class Formato:
    """Lo que se detecto de un archivo (se reporta en metricas, no es PII)."""
    encoding: str
    delimitador: str
    tz_naive: str                 # 'UTC' o 'LOCAL': como leer timestamps sin offset
    columnas: dict                # rol -> indice de columna
    unidad_defecto: str           # unidad si el archivo no trae columna de unidad
    tiene_columna_unidad: bool


@dataclass(frozen=True)
class Lectura:
    """Una fila ya normalizada: instante UTC (B1) y valor en kWh (B2)."""
    frontera_id: str
    ts_utc: datetime
    valor_kwh: Decimal | None     # None = nulo/vacio en origen
    unidad_origen: str            # unidad que DECLARABA la fila (Wh, kWh, MWh, GWh)
    version_lectura: int
    calidad_lectura: str | None
    archivo: str
    fila: int                     # n.o de fila de datos, base 1 (desempate B3)


@dataclass(frozen=True)
class FilaRechazada:
    archivo: str
    fila: int                     # 0 = rechazo a nivel de archivo
    motivo: str
    detalle: str | None = None    # solo codigos (nombre de columna), nunca contenido


@dataclass
class ArchivoLeido:
    nombre: str
    sha256: str
    estado: str                   # 'OK' | 'RECHAZADO'
    motivo_rechazo: str | None = None
    formato: Formato | None = None
    lecturas: list[Lectura] = field(default_factory=list)
    rechazadas: list[FilaRechazada] = field(default_factory=list)
    filas_leidas: int = 0
    convertidas_a_kwh: int = 0    # filas con unidad != kWh y valor convertido (B2)


# ----------------------------------------------------------------------- descubrimiento
_EXTENSIONES = {".csv", ".tsv", ".txt"}


def descubrir(directorio: Path) -> list[Path]:
    """Todo lo que haya en el directorio, en orden lexicografico de nombre (B3).

    No hay lista de meses: un archivo nuevo se procesa solo con dejarlo caer.
    """
    return sorted(
        (p for p in Path(directorio).iterdir()
         if p.is_file() and not p.name.startswith(".") and p.suffix.lower() in _EXTENSIONES),
        key=lambda p: p.name,
    )


# --------------------------------------------------------------------- deteccion de formato
_SINONIMOS = {
    "frontera": {"frontera_id", "frontera", "codigo_frontera", "id_frontera", "cod_frontera"},
    "timestamp": {"timestamp", "timestamp_utc", "timestamp_local", "fecha_hora", "fecha_hora_utc",
                  "fecha_hora_local", "ts", "datetime", "fecha"},
    "valor": {"consumo_kwh", "kwh", "consumo_mwh", "mwh", "consumo", "energia_kwh", "energia", "valor"},
    "version": {"version_lectura", "version", "version_de_lectura"},
    "calidad": {"calidad_lectura", "calidad", "estado_lectura"},
    "unidad": {"unidad", "unidad_medida", "unit", "units"},
}
_OBLIGATORIAS = ("frontera", "timestamp", "valor")


def _mapear_columnas(encabezado: list[str]) -> tuple[dict, str, str] | None:
    """-> (rol->indice, tz_naive, unidad_defecto) o None si faltan columnas obligatorias."""
    mapa: dict[str, int] = {}
    nombres: dict[str, str] = {}
    for i, crudo in enumerate(encabezado):
        n = normalizar_nombre(crudo)
        for rol, sinonimos in _SINONIMOS.items():
            if n in sinonimos and rol not in mapa:       # ante duplicados, gana la primera
                mapa[rol] = i
                nombres[rol] = n
    if not all(r in mapa for r in _OBLIGATORIAS):
        return None
    tz_naive = "UTC" if "utc" in nombres["timestamp"] else "LOCAL"
    nv = nombres["valor"]
    unidad = "MWh" if "mwh" in nv else "kWh"
    return mapa, tz_naive, unidad


def _detectar_formato(texto: str, encoding: str) -> Formato | None:
    primera = next((ln for ln in texto.splitlines() if ln.strip()), None)
    if primera is None:
        return None
    # Candidatos ordenados por cuantas veces aparecen en el encabezado (empate: coma).
    for delim in sorted(",;\t|", key=lambda d: -primera.count(d)):
        if primera.count(delim) < 2:      # hacen falta al menos 3 columnas
            continue
        try:
            cols = next(csv.reader([primera], delimiter=delim))
        except csv.Error:
            continue
        mapeo = _mapear_columnas(cols)
        if mapeo:
            mapa, tz_naive, unidad = mapeo
            return Formato(encoding, delim, tz_naive, mapa, unidad, "unidad" in mapa)
    return None


# --------------------------------------------------------------------- parseo de campos
_NULOS = {"", "null", "none", "nan", "n/a", "na", "nd", "s/d", "-", "--"}
_NUMERO = re.compile(r"[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?")
_TS = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(?:[.,](\d+))?)?\s*"
    r"(Z|z|[+-]\d{2}(?::?\d{2})?)?$")
_MES_EN_NOMBRE = re.compile(r"(\d{4})-(\d{2})")


def _parsear_valor(texto: str) -> tuple[bool, Decimal | None]:
    """-> (ok, valor). ok=False: no es un numero ni un nulo reconocible.

    Acepta punto o coma decimal ('163.795' / '163,795') y, si vienen ambos,
    toma el ultimo como decimal ('1.234,56'). Una coma sola es decimal.
    """
    t = texto.strip().replace(" ", "").replace("\u00a0", "")
    if t.lower() in _NULOS:
        return True, None
    if "," in t and "." in t:
        dec = "," if t.rfind(",") > t.rfind(".") else "."
        mil = "." if dec == "," else ","
        t = t.replace(mil, "").replace(dec, ".")
    elif "," in t:
        t = t.replace(",", ".")
    if not _NUMERO.fullmatch(t):
        return False, None
    try:
        v = Decimal(t)
    except InvalidOperation:
        return False, None
    return (True, v) if v.is_finite() else (False, None)


def _parsear_timestamp(texto: str, tz_naive: str) -> datetime | None:
    """Devuelve un datetime UTC (B1), o None si no se entiende.

    Prioridad: offset explicito en el valor (Z, +00:00, -05:00) > pista del nombre
    de la columna (timestamp_utc) > hora local de Colombia.
    """
    m = _TS.match(texto.strip())
    if not m:
        return None
    anio, mes, dia, hh, mm = (int(m.group(i)) for i in range(1, 6))
    ss = int(m.group(6) or 0)
    if m.group(7) and int(m.group(7)) != 0:          # fracciones de segundo: no es horario
        return None
    try:
        naive = datetime(anio, mes, dia, hh, mm, ss)
    except ValueError:
        return None
    tz = m.group(8)
    if tz is None:
        offset = timedelta(0) if tz_naive == "UTC" else timedelta(hours=-5)
    elif tz in ("Z", "z"):
        offset = timedelta(0)
    else:
        signo = -1 if tz[0] == "-" else 1
        dig = tz[1:].replace(":", "")
        offset = signo * timedelta(hours=int(dig[:2]), minutes=int(dig[2:] or 0))
    return (naive - offset).replace(tzinfo=R.UTC)


# ----------------------------------------------------------------------------- lectura
def _rechazo_total(nombre: str, sha: str, motivo: str, fmt: Formato | None = None) -> ArchivoLeido:
    return ArchivoLeido(nombre=nombre, sha256=sha, estado="RECHAZADO", motivo_rechazo=motivo, formato=fmt)


def leer_archivo(ruta: Path) -> ArchivoLeido:
    """Lee un archivo de consumo y devuelve su veredicto. Nunca lanza por datos malos."""
    ruta = Path(ruta)
    nombre = ruta.name
    datos = ruta.read_bytes()
    sha = hashlib.sha256(datos).hexdigest()

    if not datos.strip():
        return _rechazo_total(nombre, sha, R.M_ARCHIVO_VACIO)
    if b"\x00" in datos:                                   # bytes nulos: no es texto
        return _rechazo_total(nombre, sha, R.M_CONTENIDO_BINARIO)

    texto, encoding = decodificar(datos)
    fmt = _detectar_formato(texto, encoding)
    if fmt is None:
        return _rechazo_total(nombre, sha, R.M_ENCABEZADO_NO_RECONOCIDO)

    try:
        registros = list(csv.reader(io.StringIO(texto, newline=""), delimiter=fmt.delimitador))
    except csv.Error:                                       # p.ej. un campo gigante
        return _rechazo_total(nombre, sha, R.M_CSV_MALFORMADO, fmt)

    # Primera fila no vacia = encabezado; el resto son datos.
    inicio = next((i for i, r in enumerate(registros) if any(c.strip() for c in r)), None)
    if inicio is None:
        return _rechazo_total(nombre, sha, R.M_ARCHIVO_VACIO, fmt)
    ncols = len(registros[inicio])

    mes_nombre = None
    mm = _MES_EN_NOMBRE.search(nombre)
    if mm:
        mes_nombre = f"{mm.group(1)}-{mm.group(2)}"

    c = fmt.columnas
    resultado = ArchivoLeido(nombre=nombre, sha256=sha, estado="OK", formato=fmt)
    ultima_fila_mala = False
    fila = 0

    for reg in registros[inicio + 1:]:
        if not reg or all(not x.strip() for x in reg):      # linea en blanco: no es dato
            continue
        fila += 1
        resultado.filas_leidas += 1
        lect, rechazo = _parsear_fila(reg, ncols, fmt, c, nombre, fila, mes_nombre)
        if rechazo:
            resultado.rechazadas.append(rechazo)
            ultima_fila_mala = True
            continue
        ultima_fila_mala = False
        resultado.lecturas.append(lect)
        if lect.valor_kwh is not None and lect.unidad_origen != "kWh":
            resultado.convertidas_a_kwh += 1

    # --- veredicto del archivo ---------------------------------------------------
    if resultado.filas_leidas == 0 or not resultado.lecturas:
        return _rechazo_total(nombre, sha, R.M_SIN_FILAS_VALIDAS, fmt)
    termina_en_salto = texto.endswith(("\n", "\r"))
    if ultima_fila_mala and not termina_en_salto:
        # Cortado a mitad de una fila: el archivo esta incompleto. Un mes parcial
        # subregistra consumo y por tanto facturacion; es mejor rechazarlo entero.
        return _rechazo_total(nombre, sha, R.M_ARCHIVO_TRUNCADO, fmt)
    if len(resultado.rechazadas) / resultado.filas_leidas > R.MAX_RATIO_FILAS_RECHAZADAS:
        return _rechazo_total(nombre, sha, R.M_DEMASIADAS_FILAS_INVALIDAS, fmt)
    return resultado


def _parsear_fila(reg, ncols, fmt, c, nombre, fila, mes_nombre):
    """-> (Lectura, None) o (None, FilaRechazada)."""
    def mal(motivo, detalle=None):
        return None, FilaRechazada(nombre, fila, motivo, detalle)

    # Un delimitador final sobrante ("a,b,c,") no es un error.
    if len(reg) == ncols + 1 and not reg[-1].strip():
        reg = reg[:-1]
    if len(reg) != ncols:
        return mal(R.M_NUM_CAMPOS)

    frontera = reg[c["frontera"]].strip().upper()
    if not R.FRONTERA_RE.match(frontera):
        return mal(R.M_FRONTERA_INVALIDA)

    ts = _parsear_timestamp(reg[c["timestamp"]], fmt.tz_naive)
    if ts is None:
        return mal(R.M_TIMESTAMP_INVALIDO)
    if ts.minute or ts.second:                               # el modelo es horario
        return mal(R.M_TIMESTAMP_NO_HORARIO)
    if mes_nombre and R.mes_local(ts) != mes_nombre:
        # Un archivo mensual no puede tocar otro mes: protege lo ya cargado.
        return mal(R.M_MES_FUERA_DEL_ARCHIVO)

    ok, valor = _parsear_valor(reg[c["valor"]])
    if not ok:
        return mal(R.M_VALOR_NO_NUMERICO)

    unidad = fmt.unidad_defecto
    if fmt.tiene_columna_unidad:
        crudo = reg[c["unidad"]].strip().lower()
        if crudo:
            if crudo not in R.FACTOR_A_KWH:
                return mal(R.M_UNIDAD_DESCONOCIDA)
            unidad = R.UNIDAD_CANONICA[crudo]
    if valor is not None:
        valor = valor * R.FACTOR_A_KWH[unidad.lower()]       # B2: todo a kWh, exacto (Decimal)

    version = 1
    if "version" in c and reg[c["version"]].strip():
        try:
            version = int(reg[c["version"]].strip())
        except ValueError:
            return mal(R.M_VERSION_INVALIDA)
        if version < 1:
            return mal(R.M_VERSION_INVALIDA)

    calidad = reg[c["calidad"]].strip() or None if "calidad" in c else None
    return Lectura(frontera, ts, valor, unidad, version, calidad, nombre, fila), None


def leer_directorio(directorio: Path) -> list[ArchivoLeido]:
    """Descubre y lee todo lo que haya, en orden lexicografico de nombre."""
    return [leer_archivo(p) for p in descubrir(directorio)]
