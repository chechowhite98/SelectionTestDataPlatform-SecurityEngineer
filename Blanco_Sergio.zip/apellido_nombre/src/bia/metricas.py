"""Metricas de la corrida -> out/metrics.json (Parte E).

Minimo exigido: filas leidas, filas cargadas, filas rechazadas por motivo, duracion
por etapa y timestamp de la corrida. Se agrega el detalle por fuente y los archivos
rechazados, que es lo primero que se mira cuando algo falla a las 2 a.m.

`filas_cargadas` son las filas REALMENTE insertadas o modificadas en esta corrida
(no las enviadas): en la segunda corrida sobre los mismos datos vale 0, y esa cifra
es la prueba directa de idempotencia.
"""
from __future__ import annotations

import time
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone

from .rechazo import Rechazo


class Metricas:
    def __init__(self, corrida_id: str):
        self.corrida_id = corrida_id
        self.inicio = datetime.now(timezone.utc)
        self._t0 = time.perf_counter()
        self.duracion_por_etapa: dict[str, float] = {}
        self.leidas: dict[str, int] = {}
        self.cargadas: dict[str, int] = {}
        self.rechazos: list[Rechazo] = []
        self.archivos_rechazados: list[dict] = []
        self.formatos: dict[str, dict] = {}
        self.extra: dict = {}

    @contextmanager
    def etapa(self, nombre: str):
        t = time.perf_counter()
        try:
            yield
        finally:
            self.duracion_por_etapa[nombre] = round(time.perf_counter() - t, 3)

    # -- agregados -----------------------------------------------------------------
    @property
    def total_leidas(self) -> int:
        return sum(self.leidas.values())

    @property
    def total_cargadas(self) -> int:
        return sum(self.cargadas.values())

    def como_dict(self, resultado: str) -> dict:
        por_motivo = Counter(r.motivo for r in self.rechazos)
        por_fuente: dict[str, Counter] = {}
        for r in self.rechazos:
            por_fuente.setdefault(r.fuente, Counter())[r.motivo] += 1
        return {
            "corrida_id": self.corrida_id,
            "resultado": resultado,
            "timestamp_corrida": self.inicio.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "filas_leidas": self.total_leidas,
            "filas_cargadas": self.total_cargadas,
            "filas_rechazadas": len(self.rechazos),
            "filas_rechazadas_por_motivo": dict(sorted(por_motivo.items())),
            "duracion_por_etapa_s": dict(self.duracion_por_etapa),
            "duracion_total_s": round(time.perf_counter() - self._t0, 3),
            "detalle_por_fuente": {
                fuente: {
                    "leidas": self.leidas.get(fuente, 0),
                    "cargadas": self.cargadas.get(fuente, 0),
                    "rechazadas": sum(por_fuente.get(fuente, Counter()).values()),
                    "rechazadas_por_motivo": dict(sorted(por_fuente.get(fuente, Counter()).items())),
                }
                for fuente in sorted(set(self.leidas) | set(self.cargadas) | set(por_fuente))
            },
            "archivos_rechazados": self.archivos_rechazados,
            "formatos_detectados": self.formatos,
            **self.extra,
        }
