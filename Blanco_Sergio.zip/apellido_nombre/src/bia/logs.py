"""Logs estructurados en JSON, una linea por evento (Parte E).  logs/pipeline.log

Los logs NO pueden contener PII. Tres capas, de la mas fuerte a la mas debil:

  1. Por construccion: el pipeline solo registra contadores, nombres de archivo,
     nombres de etapa y codigos de motivo. Nunca el contenido de una fila.
  2. Excepciones: de un error de base de datos se registra SOLO la clase y el codigo
     SQLSTATE. El mensaje de PostgreSQL puede traer el valor de la fila que fallo
     ("Failing row contains (...)"), asi que no se imprime jamas. Solo los errores
     propios (variable de entorno faltante, maestro ilegible), cuyos mensajes
     nombran archivos y variables y nunca datos, conservan su mensaje.
  3. Red de seguridad: todo texto que se vaya a escribir pasa por el detector de PII
     (correo, celular, cedula) y, si algo se cuela, se enmascara y se marca el evento.

Los numeros (contadores) no se tocan: un total de 115340 filas no es una cedula.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from . import pii
from .config import ConfigError
from .clasificacion import ClasificacionInvalida
from .cripto import ConfiguracionInvalida, ErrorCripto
from .maestros import MaestroInvalido

# Errores propios cuyo mensaje es seguro por diseno (nombran archivos/variables, no datos).
_MENSAJE_SEGURO = (ConfigError, ConfiguracionInvalida, ErrorCripto, MaestroInvalido, ClasificacionInvalida)


def nuevo_id_corrida() -> str:
    """UUID v4 sin falsos positivos de detectores de PII.

    Los segmentos solo-digitos de un UUID pueden parecer una cedula a un escaner
    generico (p.ej. 'a1b2c3d4-12345678-...'). Se re-sortea hasta que no los haya:
    cuesta un intento de media y evita alertas falsas sobre los logs.
    """
    while True:
        u = str(uuid.uuid4())
        if not pii.contiene_pii(u):
            return u


def _ahora() -> str:
    t = datetime.now(timezone.utc)
    # milisegundos (no microsegundos): seis digitos seguidos parecerian una cedula
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond // 1000:03d}Z"


class LogJson:
    def __init__(self, ruta: Path, corrida_id: str):
        self.ruta = Path(ruta)
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        self.corrida_id = corrida_id
        self._fh = open(self.ruta, "a", encoding="utf-8", buffering=1)   # una linea = un flush

    # ------------------------------------------------------------------ API
    def evento(self, evento: str, nivel: str = "INFO", **campos) -> None:
        redactadas = 0
        limpios = {}
        for clave, valor in campos.items():
            limpios[clave], n = self._limpiar(valor)
            redactadas += n
        registro = {"ts": _ahora(), "nivel": nivel, "evento": evento, "corrida_id": self.corrida_id}
        registro.update(limpios)
        if redactadas:
            registro["pii_redactada"] = redactadas        # alarma: algo intento colarse
            registro["nivel"] = "WARNING" if nivel == "INFO" else nivel
        self._fh.write(json.dumps(registro, ensure_ascii=False, default=str) + "\n")

    def error(self, evento: str, exc: BaseException, **campos) -> None:
        """Registra un error SIN su mensaje (salvo errores propios, que son seguros)."""
        extra = {"error_tipo": type(exc).__name__}
        codigo = getattr(exc, "pgcode", None)            # SQLSTATE de psycopg2
        if codigo:
            extra["pgcode"] = codigo
        if isinstance(exc, _MENSAJE_SEGURO):
            extra["error_mensaje"] = str(exc)
        self.evento(evento, nivel="ERROR", **extra, **campos)

    def cerrar(self) -> None:
        if not self._fh.closed:
            self._fh.close()

    # ------------------------------------------------------------- internos
    @staticmethod
    def _limpiar(valor):
        """-> (valor limpio, n.o de enmascarados). Recorre estructuras; no toca numeros."""
        if isinstance(valor, str):
            r = pii.enmascarar(valor)
            return (r.texto if r.tenia_pii else valor), len(r.tipos)
        if isinstance(valor, dict):
            total, salida = 0, {}
            for k, v in valor.items():
                salida[k], n = LogJson._limpiar(v)
                total += n
            return salida, total
        if isinstance(valor, (list, tuple, set)):
            total, salida = 0, []
            for v in valor:
                limpio, n = LogJson._limpiar(v)
                salida.append(limpio)
                total += n
            return salida, total
        return valor, 0
