"""Configuracion del pipeline, leida SOLO del entorno (C6: cero credenciales en el codigo).

Reglas:
  * El pipeline se conecta como el rol `ingesta`. Ese rol NO es configurable: no hay
    forma de apuntarlo al superusuario por error (el superusuario solo lo usa el
    arranque de la base y el evaluador para verificar el cifrado).
  * Falla rapido y con mensajes que nombran la VARIABLE, nunca su valor.
  * El .env es una comodidad para uso directo (`python -m bia run`); el Makefile ya
    lo exporta. Lo que ya este en el entorno siempre gana sobre el .env.
"""
from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from .cripto import ConfiguracionInvalida, Llaves, cargar_llaves

ROL_PIPELINE = "ingesta"


class ConfigError(Exception):
    """Configuracion invalida. El mensaje nombra la variable, jamas su valor."""


@dataclass(frozen=True, repr=False)
class Config:
    data_dir: Path
    out_dir: Path
    logs_dir: Path
    pg_host: str
    pg_port: int
    pg_db: str
    pg_password: str
    llaves: Llaves
    fallar_si_parcial: bool = False
    pg_usuario: str = ROL_PIPELINE

    def __repr__(self) -> str:                       # nunca imprimir la contrasena ni las llaves
        return (f"Config(data_dir={self.data_dir}, out_dir={self.out_dir}, logs_dir={self.logs_dir}, "
                f"pg={self.pg_usuario}@{self.pg_host}:{self.pg_port}/{self.pg_db}, <secretos>)")


def leer_dotenv(ruta: Path) -> dict[str, str]:
    """Parser minimo de KEY=VALUE (sin dependencias). Ignora comentarios y lineas vacias."""
    valores: dict[str, str] = {}
    if not ruta.is_file():
        return valores
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        linea = linea.strip()
        if not linea or linea.startswith("#") or "=" not in linea:
            continue
        clave, _, valor = linea.partition("=")
        valor = valor.strip()
        if len(valor) >= 2 and valor[0] == valor[-1] and valor[0] in "\"'":
            valor = valor[1:-1]
        valores[clave.strip()] = valor
    return valores


def _requerida(env: Mapping[str, str], nombre: str) -> str:
    valor = (env.get(nombre) or "").strip()
    if not valor:
        raise ConfigError(f"falta la variable {nombre}")
    return valor


def cargar_config(env: Mapping[str, str] | None = None, dotenv: Path | None = None) -> Config:
    """env=None -> usa os.environ y, si existe, el .env (sin pisar lo ya definido)."""
    if env is None:
        fusion = dict(leer_dotenv(dotenv or Path(".env")))
        fusion.update(os.environ)                    # el entorno real gana al .env
        env = fusion

    puerto = (env.get("PG_PORT") or "5432").strip()
    if not puerto.isdigit() or not 0 < int(puerto) < 65536:
        raise ConfigError("PG_PORT debe ser un numero de puerto valido")
    try:
        llaves = cargar_llaves(env)
    except ConfiguracionInvalida as e:               # el mensaje ya nombra la variable, no el valor
        raise ConfigError(str(e)) from None

    return Config(
        data_dir=Path(env.get("BIA_DATA_DIR") or "data"),
        out_dir=Path(env.get("BIA_OUT_DIR") or "out"),
        logs_dir=Path(env.get("BIA_LOGS_DIR") or "logs"),
        pg_host=(env.get("PG_HOST") or "localhost").strip(),
        pg_port=int(puerto),
        pg_db=(env.get("PG_DB") or "bia_datos").strip(),
        pg_password=_requerida(env, "INGESTA_PASSWORD"),
        llaves=llaves,
        fallar_si_parcial=(env.get("BIA_FALLAR_SI_PARCIAL") or "").strip().lower() in ("1", "true", "si", "yes"),
    )
