"""Bitacora de auditoria (C5): quien, que, cuando, cuantas filas, con que resultado.

Escribe en audit.pipeline_runs (append-only: UPDATE/DELETE revocados y bloqueados por
trigger) por una conexion PROPIA en autocommit. Es deliberado: si la transaccion de
carga se revierte por un error, el INICIO y el FIN con resultado ERROR ya quedaron
guardados. Una bitacora que desaparece junto con la transaccion que fallo no sirve
para nada justo cuando mas hace falta.

Fail-closed: si la bitacora no se puede escribir, la corrida FALLA. Operar sin
trazabilidad en un entorno bajo ISO 27001 no es una degradacion aceptable.

`detalle` solo admite contadores y codigos: pasa por el mismo detector de PII que
los logs.
"""
from __future__ import annotations

import json

from psycopg2.extras import Json

from . import pii


def _sin_pii(valor):
    if isinstance(valor, str):
        return pii.enmascarar(valor).texto or valor
    if isinstance(valor, dict):
        return {k: _sin_pii(v) for k, v in valor.items()}
    if isinstance(valor, (list, tuple)):
        return [_sin_pii(v) for v in valor]
    return valor


class Auditoria:
    def __init__(self, conexion, corrida_id: str):
        if not conexion.autocommit:
            raise ValueError("la conexion de auditoria debe estar en autocommit")
        self._conn = conexion
        self.corrida_id = corrida_id

    def _insertar(self, evento: str, etapa=None, resultado=None, leidas=None, cargadas=None,
                  rechazadas=None, detalle=None) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                """INSERT INTO audit.pipeline_runs
                     (corrida_id, evento, etapa, resultado, filas_leidas, filas_cargadas,
                      filas_rechazadas, detalle)
                   VALUES (%s::uuid, %s, %s, %s, %s, %s, %s, %s)""",
                (self.corrida_id, evento, etapa, resultado, leidas, cargadas, rechazadas,
                 Json(_sin_pii(detalle or {}), dumps=lambda o: json.dumps(o, default=str))))

    def inicio(self, detalle: dict | None = None) -> None:
        self._insertar("INICIO", detalle=detalle)

    def etapa(self, etapa: str, resultado: str = "OK", detalle: dict | None = None) -> None:
        self._insertar("ETAPA", etapa=etapa, resultado=resultado, detalle=detalle)

    def fin(self, resultado: str, leidas: int, cargadas: int, rechazadas: int,
            detalle: dict | None = None) -> None:
        self._insertar("FIN", resultado=resultado, leidas=leidas, cargadas=cargadas,
                       rechazadas=rechazadas, detalle=detalle)
