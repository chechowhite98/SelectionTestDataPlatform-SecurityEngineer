"""Lectura de los maestros: clientes (con PII), fronteras y limites.

Reglas de oro (B7 + C2 + C3):
  * Las entradas hostiles son DATOS, no codigo: se leen con el modulo csv (comillas
    anidadas, saltos de linea dentro de un campo citado, cadenas enormes) y mas
    tarde se insertan SIEMPRE con parametros, jamas concatenadas a SQL.
  * Ninguna fila se pierde en silencio: leidas = cargadas + rechazadas (cuarentena).
  * La PII sale de aqui ya cifrada (AES-GCM atada a su fila) y el texto libre ya
    enmascarado. El texto original no sobrevive en memoria mas alla de este modulo.
  * Nada de lo que se registra incluye contenido de filas: solo numero y motivo.

Un maestro ilegible (vacio, binario, sin las columnas esperadas) es FATAL: sin
clientes ni fronteras no se puede cargar nada, y los maestros son inmutables.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path

from . import rechazo as Z
from . import reglas as R
from .consumos import _parsear_valor
from .cripto import Cifrador, normalizar_nit
from .pii import enmascarar
from .rechazo import Rechazo
from .texto import decodificar, normalizar_nombre

# Un campo "enorme" hostil es un dato valido; el limite por defecto de csv (128 KiB)
# lo trataria como error. Se sube SOLO durante la lectura (ver _leer_tabla).
_LIMITE_CAMPO = 8 * 1024 * 1024
_ID_VALIDO = re.compile(r"^[A-Za-z0-9_-]{1,64}$")

CLIENTES_COLS = ("cliente_id", "razon_social", "nit", "email_contacto", "celular_contacto",
                 "direccion", "ciudad", "departamento", "representante_legal", "observaciones")
FRONTERAS_COLS = ("frontera_id", "codigo_sic", "cliente_id", "mercado", "operador_red",
                  "nivel_tension", "fecha_registro", "estado")
LIMITES_COLS = ("frontera_id", "min_kwh", "max_kwh")


class MaestroInvalido(Exception):
    """Maestro ilegible: el pipeline no puede continuar."""


# ------------------------------------------------------------------ lectura generica
def _leer_tabla(ruta: Path, requeridas: Sequence[str]):
    """-> (filas, sha256). filas = [(n, dict | None, registro_crudo)]; dict None = ancho incorrecto."""
    datos = ruta.read_bytes()
    sha = hashlib.sha256(datos).hexdigest()
    if not datos.strip() or b"\x00" in datos:
        raise MaestroInvalido(f"{ruta.name}: vacio o binario")
    texto, _ = decodificar(datos)
    primera = next(ln for ln in texto.splitlines() if ln.strip())
    delim = max(",;\t|", key=primera.count)

    previo = csv.field_size_limit(_LIMITE_CAMPO)
    try:
        registros = list(csv.reader(io.StringIO(texto, newline=""), delimiter=delim))
    except csv.Error:
        raise MaestroInvalido(f"{ruta.name}: CSV malformado") from None
    finally:
        csv.field_size_limit(previo)        # no contaminar a los demas lectores

    inicio = next(i for i, r in enumerate(registros) if any(c.strip() for c in r))
    encabezado = [normalizar_nombre(c) for c in registros[inicio]]
    faltan = [c for c in requeridas if c not in encabezado]
    if faltan:
        raise MaestroInvalido(f"{ruta.name}: faltan columnas {faltan}")
    idx = {c: encabezado.index(c) for c in requeridas}

    filas = []
    n = 0
    for reg in registros[inicio + 1:]:
        if not reg or all(not c.strip() for c in reg):
            continue
        n += 1
        if len(reg) != len(encabezado):
            filas.append((n, None, reg))
        else:
            filas.append((n, {c: reg[i] for c, i in idx.items()}, reg))
    return filas, sha


def _payload(cif: Cifrador, fuente: str, archivo: str, fila: int, contenido) -> bytes:
    """La fila original, cifrada: la cuarentena puede guardar PII y no puede quedar en claro."""
    crudo = json.dumps(contenido, ensure_ascii=False, default=str)
    return cif.cifrar(crudo, f"quarantine.rechazo.payload|{fuente}|{archivo}|{fila}")


# ------------------------------------------------------------------------ clientes
@dataclass(frozen=True)
class ClienteFila:
    cliente_id: str
    razon_social: str
    nit_hash: bytes
    nit_cifrado: bytes
    email_contacto_cifrado: bytes | None
    celular_contacto_cifrado: bytes | None
    direccion_cifrada: bytes | None
    representante_legal_cifrado: bytes | None
    observaciones_enmascaradas: str | None
    observaciones_pii_tipos: tuple[str, ...]
    ciudad: str | None
    departamento: str | None
    clave_version: int
    huella_contenido: bytes
    fila_origen: int = 0          # solo para trazabilidad; no se persiste


@dataclass
class ResultadoClientes:
    archivo: str
    sha256: str
    clientes: list[ClienteFila] = field(default_factory=list)
    rechazos: list[Rechazo] = field(default_factory=list)
    filas_leidas: int = 0
    con_pii_en_texto_libre: int = 0       # C2: clientes cuyo texto libre traia PII


def leer_clientes(ruta: Path, cif: Cifrador) -> ResultadoClientes:
    ruta = Path(ruta)
    filas, sha = _leer_tabla(ruta, CLIENTES_COLS)
    res = ResultadoClientes(archivo=ruta.name, sha256=sha, filas_leidas=len(filas))
    por_id: dict[str, ClienteFila] = {}
    id_por_nit: dict[bytes, str] = {}

    def rechazar(n, motivo, contenido, clave=None, detalle=None):
        res.rechazos.append(Rechazo("clientes", ruta.name, n, motivo, clave, detalle,
                                    _payload(cif, "clientes", ruta.name, n, contenido)))

    for n, d, crudo in filas:
        if d is None:
            rechazar(n, Z.M_NUM_CAMPOS, crudo)
            continue

        obs = enmascarar(d["observaciones"])                # C2: antes que nada
        if obs.tenia_pii:
            res.con_pii_en_texto_libre += 1

        cid = d["cliente_id"].strip()
        if not _ID_VALIDO.match(cid):
            rechazar(n, Z.M_CLIENTE_ID_INVALIDO, d)         # sin clave: el id podria ser hostil
            continue
        if not d["razon_social"].strip():
            rechazar(n, Z.M_RAZON_SOCIAL_VACIA, d, clave=cid)
            continue
        nit = normalizar_nit(d["nit"])
        if nit is None:
            rechazar(n, Z.M_NIT_INVALIDO, d, clave=cid)
            continue
        nit_hash = cif.indice_ciego(nit)
        if nit_hash in id_por_nit and id_por_nit[nit_hash] != cid:
            rechazar(n, Z.M_NIT_DUPLICADO, d, clave=cid)
            continue

        def cifrar_col(columna: str, valor: str) -> bytes | None:
            v = (valor or "").strip()
            return cif.cifrar(v, f"core.dim_cliente.{columna}|{cid}") if v else None

        email, celular = d["email_contacto"].strip(), d["celular_contacto"].strip()
        direccion, representante = d["direccion"].strip(), d["representante_legal"].strip()
        ciudad, depto = d["ciudad"].strip() or None, d["departamento"].strip() or None
        fila = ClienteFila(
            cliente_id=cid,
            razon_social=d["razon_social"],                  # dato tal cual, aunque parezca SQL
            nit_hash=nit_hash,
            nit_cifrado=cif.cifrar(nit, f"core.dim_cliente.nit_cifrado|{cid}"),
            email_contacto_cifrado=cifrar_col("email_contacto_cifrado", email),
            celular_contacto_cifrado=cifrar_col("celular_contacto_cifrado", celular),
            direccion_cifrada=cifrar_col("direccion_cifrada", direccion),
            representante_legal_cifrado=cifrar_col("representante_legal_cifrado", representante),
            observaciones_enmascaradas=obs.texto,
            observaciones_pii_tipos=obs.tipos,
            ciudad=ciudad, departamento=depto,
            clave_version=cif.version_actual,
            huella_contenido=cif.huella([cid, d["razon_social"], nit, email, celular, direccion,
                                         ciudad, depto, representante, obs.texto]),
            fila_origen=n,
        )
        if cid in por_id:                                    # mismo id otra vez: gana el ultimo
            previa = por_id[cid]
            res.rechazos.append(Rechazo("clientes", ruta.name, previa.fila_origen, Z.M_CLIENTE_DUPLICADO,
                                        cid, None, None))
            id_por_nit.pop(previa.nit_hash, None)
        por_id[cid] = fila
        id_por_nit[nit_hash] = cid

    res.clientes = sorted(por_id.values(), key=lambda c: c.cliente_id)
    return res


# ------------------------------------------------------------------------ fronteras
@dataclass(frozen=True)
class FronteraFila:
    frontera_id: str
    codigo_sic: str
    cliente_id: str
    mercado: str | None
    operador_red: str | None
    nivel_tension: int | None
    fecha_registro: date | None
    estado: str | None
    min_kwh: Decimal | None
    max_kwh: Decimal | None


@dataclass
class ResultadoFronteras:
    fronteras: list[FronteraFila] = field(default_factory=list)
    rechazos: list[Rechazo] = field(default_factory=list)
    filas_leidas: int = 0


def leer_fronteras(ruta_fronteras: Path, ruta_limites: Path, clientes_ids: set[str]) -> ResultadoFronteras:
    ruta_fronteras, ruta_limites = Path(ruta_fronteras), Path(ruta_limites)
    res = ResultadoFronteras()
    filas, _ = _leer_tabla(ruta_fronteras, FRONTERAS_COLS)
    res.filas_leidas = len(filas)
    base: dict[str, tuple[int, dict]] = {}

    def rechazar(archivo, n, motivo, clave=None, detalle=None):
        res.rechazos.append(Rechazo("fronteras", archivo, n, motivo, clave, detalle))

    for n, d, _crudo in filas:
        if d is None:
            rechazar(ruta_fronteras.name, n, Z.M_NUM_CAMPOS)
            continue
        fid = d["frontera_id"].strip().upper()
        if not R.FRONTERA_RE.match(fid):
            rechazar(ruta_fronteras.name, n, Z.M_FRONTERA_INVALIDA)
            continue
        if d["cliente_id"].strip() not in clientes_ids:
            rechazar(ruta_fronteras.name, n, Z.M_CLIENTE_INEXISTENTE, fid)
            continue
        if fid in base:                                      # duplicada: gana la ultima
            rechazar(ruta_fronteras.name, base[fid][0], Z.M_FRONTERA_DUPLICADA, fid)
        base[fid] = (n, d)

    # --- limites (banda operativa) ---------------------------------------------------
    bandas: dict[str, tuple[Decimal | None, Decimal | None]] = {}
    filas_lim, _ = _leer_tabla(ruta_limites, LIMITES_COLS)
    res.filas_leidas += len(filas_lim)
    pendiente: dict[str, int] = {}
    for n, d, _crudo in filas_lim:
        if d is None:
            rechazar(ruta_limites.name, n, Z.M_NUM_CAMPOS)
            continue
        fid = d["frontera_id"].strip().upper()
        if fid not in base:
            rechazar(ruta_limites.name, n, Z.M_FRONTERA_DESCONOCIDA, fid if R.FRONTERA_RE.match(fid) else None)
            continue
        ok_min, vmin = _parsear_valor(d["min_kwh"])
        ok_max, vmax = _parsear_valor(d["max_kwh"])
        if not (ok_min and ok_max):
            rechazar(ruta_limites.name, n, Z.M_VALOR_INVALIDO, fid)
            continue
        if vmin is not None and vmax is not None and vmin > vmax:
            rechazar(ruta_limites.name, n, Z.M_BANDA_INVALIDA, fid)
            continue
        if fid in pendiente:
            rechazar(ruta_limites.name, pendiente[fid], Z.M_FRONTERA_DUPLICADA, fid)
        pendiente[fid] = n
        bandas[fid] = (vmin, vmax)

    # --- ensamblado -------------------------------------------------------------------
    for fid in sorted(base):
        n, d = base[fid]
        try:
            nivel = int(d["nivel_tension"].strip()) if d["nivel_tension"].strip() else None
            fecha = date.fromisoformat(d["fecha_registro"].strip()) if d["fecha_registro"].strip() else None
        except ValueError:
            rechazar(ruta_fronteras.name, n, Z.M_VALOR_INVALIDO, fid)
            continue
        vmin, vmax = bandas.get(fid, (None, None))
        res.fronteras.append(FronteraFila(
            fid, d["codigo_sic"].strip(), d["cliente_id"].strip(),
            d["mercado"].strip() or None, d["operador_red"].strip() or None,
            nivel, fecha, d["estado"].strip() or None, vmin, vmax))
    return res
