"""Orquestador de `make run`.

Etapas:  maestros -> consumos_lectura -> calidad -> carga -> salidas

Decisiones de diseno (todas defendibles en la entrevista):

  * UNA transaccion para toda la carga: dimensiones, facturas, consumos, cuarentena y
    libro de archivos entran juntos o no entra nada. Un fallo a mitad no deja la base
    a medias.
  * La AUDITORIA va por una conexion aparte en autocommit: si la carga se revierte,
    el INICIO y el FIN con resultado ERROR ya estan guardados. Es fail-closed: si no
    se puede auditar, la corrida falla.
  * Se LEE todo cada vez (barato, y el reporte de calidad necesita ver todos los
    archivos), pero solo se CARGAN los archivos nuevos o cambiados segun el libro
    ops.archivo_cargado. Una correccion tardia entra sin recargar nada mas.
  * Autorreparacion: si la base tiene MENOS filas de consumo de las esperadas (alguien
    vacio la tabla pero el libro dice "cargado"), se recarga todo. El libro es una
    optimizacion, nunca la fuente de verdad.
  * Un archivo corrupto o truncado se rechaza ENTERO y no aporta ninguna fila: no puede
    alterar lo ya cargado. La corrida termina PARCIAL (exit 0 y alarma en logs y
    metricas); con BIA_FALLAR_SI_PARCIAL=1 termina con exit 2.
  * Un maestro ilegible, una base inaccesible o un error de carga son fatales (exit 1).
"""
from __future__ import annotations

import time
from collections import Counter
from contextlib import contextmanager

import psycopg2

from . import calidad, clasificacion, consumos, facturacion, maestros, repositorio, salidas
from . import reglas as R
from .auditoria import Auditoria
from .config import Config
from .cripto import Cifrador
from .logs import LogJson, nuevo_id_corrida
from .maestros import MaestroInvalido
from .metricas import Metricas
from .rechazo import M_ARCHIVO_INVALIDO, Rechazo
from .repositorio import RegistroArchivo

VERSION = "1.0"

EXIT_OK, EXIT_ERROR, EXIT_PARCIAL_ESTRICTO = 0, 1, 2


def _conectar(cfg: Config, autocommit: bool):
    conn = psycopg2.connect(host=cfg.pg_host, port=cfg.pg_port, dbname=cfg.pg_db,
                            user=cfg.pg_usuario, password=cfg.pg_password,
                            connect_timeout=10, application_name="bia-pipeline")
    conn.autocommit = autocommit
    return conn


class Corrida:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.id = nuevo_id_corrida()
        self.log = LogJson(cfg.logs_dir / "pipeline.log", self.id)
        self.met = Metricas(self.id)
        self.cif: Cifrador | None = None
        self.conn = None            # transaccion de carga
        self.conn_aud = None        # auditoria (autocommit)
        self.aud: Auditoria | None = None
        self.rechazos: list[Rechazo] = []
        self.archivos_rechazados: list[dict] = []

    # ------------------------------------------------------------------ utilidades
    @contextmanager
    def etapa(self, nombre: str):
        self.log.evento("etapa_inicio", etapa=nombre)
        t = time.perf_counter()
        try:
            with self.met.etapa(nombre):
                yield
        except BaseException:
            dur = round(time.perf_counter() - t, 3)
            self.log.evento("etapa_error", nivel="ERROR", etapa=nombre, duracion_s=dur)
            if self.aud:
                try:
                    self.aud.etapa(nombre, "ERROR", {"duracion_s": dur})
                except Exception as e:      # no tapar el error original con uno de auditoria
                    self.log.error("auditoria_fallo", e)
            raise
        else:
            dur = round(time.perf_counter() - t, 3)
            self.log.evento("etapa_fin", etapa=nombre, duracion_s=dur)
            if self.aud:
                self.aud.etapa(nombre, "OK", {"duracion_s": dur})

    # ---------------------------------------------------------------------- etapas
    def _clasificacion(self) -> None:
        """C1: la clasificacion de datos manda. Modelo y YAML desalineados => no se carga nada."""
        tablas = clasificacion.cargar()
        with self.conn.cursor() as cur:
            clasificacion.verificar(tablas, clasificacion.columnas_reales(cur))
        self.conn.rollback()                      # solo lectura de catalogo: no deja transaccion abierta
        self.log.evento("clasificacion_verificada", columnas=sum(len(c) for c in tablas.values()),
                        columnas_pii=len(clasificacion.columnas_pii(tablas)))

    def _maestros(self) -> None:
        d = self.cfg.data_dir
        for nombre in ("clientes.csv", "fronteras.csv", "limites_frontera.csv"):
            if not (d / "maestros" / nombre).is_file():
                raise MaestroInvalido(f"falta maestros/{nombre}")
        self.cl = maestros.leer_clientes(d / "maestros" / "clientes.csv", self.cif)
        self.fr = maestros.leer_fronteras(d / "maestros" / "fronteras.csv",
                                          d / "maestros" / "limites_frontera.csv",
                                          {c.cliente_id for c in self.cl.clientes})
        self.fronteras_ids = {f.frontera_id for f in self.fr.fronteras}
        if (d / "facturacion").is_dir():
            self.fa = facturacion.leer_facturacion(d / "facturacion", self.fronteras_ids, self.cif)
        else:
            self.log.evento("facturacion_ausente", nivel="WARNING")
            self.fa = facturacion.ResultadoFacturacion()

        self.met.leidas.update(clientes=self.cl.filas_leidas, fronteras=self.fr.filas_leidas,
                               facturacion=self.fa.facturas_leidas)
        self.rechazos += self.cl.rechazos + self.fr.rechazos + self.fa.rechazos
        for nombre, _sha, estado in self.fa.archivos:
            if estado == "RECHAZADO":
                self.archivos_rechazados.append({"archivo": nombre, "fuente": "facturacion",
                                                 "motivo": M_ARCHIVO_INVALIDO})
        self.log.evento("maestros_leidos", clientes=len(self.cl.clientes),
                        fronteras=len(self.fr.fronteras), facturas=len(self.fa.facturas),
                        facturas_huerfanas=self.fa.fronteras_huerfanas,
                        clientes_con_pii_en_texto_libre=self.cl.con_pii_en_texto_libre,
                        rechazos=len(self.cl.rechazos) + len(self.fr.rechazos) + len(self.fa.rechazos))

    def _leer_consumos(self) -> None:
        ruta = self.cfg.data_dir / "consumos"
        if not ruta.is_dir():
            raise MaestroInvalido("falta el directorio consumos/")
        self.archivos = consumos.leer_directorio(ruta)
        for a in self.archivos:
            f = a.formato
            self.log.evento(
                "archivo_leido", nivel="INFO" if a.estado == "OK" else "WARNING",
                archivo=a.nombre, estado=a.estado, motivo=a.motivo_rechazo,
                filas_leidas=a.filas_leidas, filas_rechazadas=len(a.rechazadas),
                encoding=f.encoding if f else None, delimitador=f.delimitador if f else None,
                zona_horaria_sin_offset=f.tz_naive if f else None)
            if f:
                self.met.formatos[a.nombre] = {
                    "encoding": f.encoding, "delimitador": f.delimitador,
                    "zona_horaria_sin_offset": f.tz_naive, "columna_unidad": f.tiene_columna_unidad}
        self.met.leidas["consumos"] = sum(a.filas_leidas for a in self.archivos)

    def _calidad(self) -> None:
        self.res = calidad.resolver(self.archivos, self.fronteras_ids)
        self.dq = self.res.dq

        cuarentena: list[Rechazo] = [
            Rechazo("consumos", r.archivo, r.fila, r.motivo, None, r.detalle) for r in self.res.rechazadas]
        for g in self.res.ganadoras:                          # B4: lo descartado no se borra
            if g.estado == R.INVALIDA:
                detalle = None if g.valor_descartado is None else f"valor_kwh={g.valor_descartado}"
                cuarentena.append(Rechazo("consumos", g.archivo, g.fila, g.motivo_invalidez,
                                          f"{g.frontera_id}|{g.ts_utc.isoformat()}", detalle))
        for nombre, motivo in self.res.archivos_rechazados:   # archivo rechazado entero
            cuarentena.append(Rechazo("consumos", nombre, 0, motivo))
            self.archivos_rechazados.append({"archivo": nombre, "fuente": "consumos", "motivo": motivo})
            self.log.evento("archivo_rechazado", nivel="WARNING", archivo=nombre, motivo=motivo)
        self.cuarentena_consumos = cuarentena
        self.rechazos += cuarentena
        self.met.rechazos = self.rechazos
        self.met.archivos_rechazados = self.archivos_rechazados
        self.log.evento("calidad_resuelta", ganadoras=len(self.res.ganadoras), meses=self.res.meses,
                        horas_sin_lectura_valida=self.dq["horas_sin_lectura_valida_total"],
                        duplicados_exactos=self.dq["duplicados_exactos"],
                        duplicados_conflictivos=self.dq["duplicados_conflictivos"],
                        correcciones_tardias=self.dq["correcciones_tardias_aplicadas"])

    def _cargar(self) -> None:
        with self.conn:                                       # commit si sale bien, rollback si no
            cur = self.conn.cursor()
            ya = repositorio.ledger_cargados(cur)
            nuevos = {a.nombre for a in self.archivos
                      if a.estado == "OK" and a.sha256 not in ya.get(a.nombre, set())}
            modificados = sorted(a.nombre for a in self.archivos
                                 if a.nombre in ya and a.sha256 not in ya[a.nombre])
            for nombre in modificados:                        # los archivos son inmutables
                self.log.evento("archivo_modificado_tras_carga", nivel="WARNING", archivo=nombre)
            omitidos = [a.nombre for a in self.archivos if a.estado == "OK" and a.nombre not in nuevos]

            n_cli = repositorio.upsert_clientes(cur, self.cl.clientes)
            n_fr = repositorio.upsert_fronteras(cur, self.fr.fronteras)
            n_fac, n_comp = repositorio.upsert_facturas(cur, self.fa.facturas)

            a_cargar = [g for g in self.res.ganadoras if g.archivo in nuevos]
            n_cons = repositorio.upsert_consumos(cur, a_cargar)

            en_base = repositorio.contar_consumos(cur)
            if en_base < len(self.res.ganadoras):             # autorreparacion
                self.log.evento("reparacion_automatica", nivel="WARNING",
                                filas_esperadas=len(self.res.ganadoras), filas_en_base=en_base)
                n_cons += repositorio.upsert_consumos(cur, self.res.ganadoras)
                en_base = repositorio.contar_consumos(cur)
                if en_base < len(self.res.ganadoras):
                    raise RuntimeError("inconsistencia de carga no reparable")

            n_rech = repositorio.registrar_rechazos(cur, self.rechazos, self.id)
            repositorio.ledger_registrar(cur, self._registros_libro(), self.id)

        self.met.cargadas.update(clientes=n_cli, fronteras=n_fr, facturacion=n_fac,
                                 facturacion_componentes=n_comp, consumos=n_cons)
        self.met.extra["archivos_consumo_omitidos_ya_cargados"] = omitidos
        self.met.extra["archivos_modificados_tras_carga"] = modificados
        self.met.extra["cuarentena_filas_nuevas"] = n_rech
        self.log.evento("carga_confirmada", clientes=n_cli, fronteras=n_fr, facturas=n_fac,
                        componentes=n_comp, consumos=n_cons, consumos_en_base=en_base,
                        archivos_cargados=len(nuevos), archivos_omitidos=len(omitidos),
                        cuarentena_nuevas=n_rech)

    def _registros_libro(self) -> list[RegistroArchivo]:
        ganadoras = Counter(g.archivo for g in self.res.ganadoras)
        rechazadas = Counter(r.archivo for r in self.cuarentena_consumos if r.fila != 0)
        libro = [RegistroArchivo(
            a.nombre, a.sha256, "consumos", "CARGADO" if a.estado == "OK" else "RECHAZADO",
            a.filas_leidas, ganadoras.get(a.nombre, 0), rechazadas.get(a.nombre, 0), a.motivo_rechazo)
            for a in self.archivos]
        fact_ok = Counter(f.archivo for f in self.fa.facturas)
        fact_rech = Counter(r.archivo for r in self.fa.rechazos)
        for nombre, sha, estado in self.fa.archivos:
            libro.append(RegistroArchivo(
                nombre, sha, "facturacion", "CARGADO" if estado == "OK" else "RECHAZADO",
                fact_ok.get(nombre, 0) + fact_rech.get(nombre, 0), fact_ok.get(nombre, 0),
                fact_rech.get(nombre, 0), M_ARCHIVO_INVALIDO if estado == "RECHAZADO" else None))
        return libro

    def _salidas(self) -> None:
        with self.conn:
            cur = self.conn.cursor()
            filas = salidas.consultar_consumo_mensual(cur)
            tablas = {}
            for t in ("core.dim_cliente", "core.dim_frontera", "core.fact_consumo_horario",
                      "core.fact_factura", "quarantine.rechazo", "ops.archivo_cargado"):
                cur.execute(f"SELECT count(*) FROM {t}")           # nombres fijos, sin datos externos
                tablas[t] = cur.fetchone()[0]
        n = salidas.escribir_consumo_mensual(self.cfg.out_dir / "consumo_mensual.csv", filas)
        if filas != calidad.consumo_mensual(self.res.ganadoras):
            # La base tiene algo que los archivos actuales no explican (p.ej. un archivo ya
            # cargado que se retiro de la carpeta). No es un error, pero hay que verlo.
            self.log.evento("conciliacion_base_vs_archivos", nivel="WARNING", filas_en_base=n,
                            filas_esperadas=len(calidad.consumo_mensual(self.res.ganadoras)))
        reporte = salidas.construir_dq_report(
            self.dq, self.fa.fronteras_huerfanas, self.cl.con_pii_en_texto_libre)
        salidas.escribir_json(self.cfg.out_dir / "dq_report.json", reporte)
        self.met.extra["filas_en_base"] = tablas
        self.log.evento("salidas_escritas", consumo_mensual_filas=n)

    # ------------------------------------------------------------------- ejecucion
    def correr(self) -> int:
        resultado, codigo = "ERROR", EXIT_ERROR
        try:
            self.log.evento("corrida_inicio", version=VERSION)
            self.cif = Cifrador(self.cfg.llaves)
            self.conn_aud = _conectar(self.cfg, autocommit=True)
            self.aud = Auditoria(self.conn_aud, self.id)
            self.aud.inicio({"version": VERSION})
            self.conn = _conectar(self.cfg, autocommit=False)

            with self.etapa("clasificacion"):
                self._clasificacion()
            with self.etapa("maestros"):
                self._maestros()
            with self.etapa("consumos_lectura"):
                self._leer_consumos()
            with self.etapa("calidad"):
                self._calidad()
            with self.etapa("carga"):
                self._cargar()
            with self.etapa("salidas"):
                self._salidas()

            resultado = "PARCIAL" if self.archivos_rechazados else "OK"
            codigo = EXIT_PARCIAL_ESTRICTO if (resultado == "PARCIAL" and self.cfg.fallar_si_parcial) else EXIT_OK
        except Exception as e:                                  # noqa: BLE001 - se registra y se sale con 1
            self.log.error("corrida_error", e)
        finally:
            self._cerrar(resultado)
        return codigo

    def _cerrar(self, resultado: str) -> None:
        nivel = {"OK": "INFO", "PARCIAL": "WARNING"}.get(resultado, "ERROR")
        self.log.evento("corrida_fin", nivel=nivel, resultado=resultado,
                        filas_leidas=self.met.total_leidas, filas_cargadas=self.met.total_cargadas,
                        filas_rechazadas=len(self.rechazos),
                        archivos_rechazados=len(self.archivos_rechazados))
        try:
            if self.conn is not None:
                self.conn.rollback()                            # no-op si ya hubo commit
            if self.aud is not None:
                self.aud.fin(resultado, self.met.total_leidas, self.met.total_cargadas,
                             len(self.rechazos),
                             {"archivos_rechazados": len(self.archivos_rechazados)})
        except Exception as e:                                  # noqa: BLE001
            self.log.error("auditoria_fin_fallo", e)
        try:
            salidas.escribir_json(self.cfg.out_dir / "metrics.json", self.met.como_dict(resultado))
        except Exception as e:                                  # noqa: BLE001
            self.log.error("metricas_fallo", e)
        for conexion in (self.conn, self.conn_aud):
            try:
                if conexion is not None:
                    conexion.close()
            except Exception:                                   # noqa: BLE001
                pass
        self.log.cerrar()


def ejecutar(cfg: Config) -> int:
    """Corre el pipeline completo. Devuelve el codigo de salida del proceso."""
    return Corrida(cfg).correr()
