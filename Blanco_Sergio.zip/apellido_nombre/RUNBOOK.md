# RUNBOOK — qué hacer cuando falla a las 2 a. m.

**Primero**: mira el resultado y el código de salida de `make run` y la última línea `corrida_fin` de `logs/pipeline.log`
(`resultado`: `OK` | `PARCIAL` | `ERROR`). Cada evento lleva `corrida_id`; busca `"nivel": "ERROR"` con ese id.
La traza completa de lo que pasó también está en `audit.pipeline_runs` (rol `auditor`).

| Síntoma | Causa probable | Qué hacer |
|---|---|---|
| Exit 1, `error_tipo: OperationalError` | Postgres caído o credencial incorrecta | `docker compose ps`; `make up`; revisar `.env`. Reintentar `make run` (es idempotente). |
| Exit 1, `ClasificacionInvalida … sin clasificar: tabla.columna` | Alguien agregó una columna sin clasificarla | Clasificarla en `data_classification.yaml` (y protegerla si es PII). No se cargó nada. |
| Exit 1, `ConfiguracionInvalida`/`falta la variable X` | `.env` incompleto o llaves sin generar | `python3 tools/init_env.py`; **no** regenerar llaves si ya hay datos cifrados. |
| Exit 1, `ErrorCripto` | Llave equivocada o dato alterado | Restaurar el `.env` correcto. Nunca sobrescribir `BIA_ENC_KEYS` en una base con datos. |
| `resultado: PARCIAL` (exit 0) | Un archivo de consumo corrupto/truncado se rechazó entero | Ver `archivos_rechazados` en `out/metrics.json`; pedir reenvío; rerun. Lo ya cargado no se alteró. |
| `filas_cargadas = 0` en la 2.ª corrida | Normal (idempotente) | Nada. |
| La tabla de consumos tiene menos filas de las esperadas | Alguien la vació; el libro cree que ya cargó | El pipeline lo detecta y recarga solo; si no, `make run` otra vez. |
| `make stream` sin `alertas.json` o exit 1 | Redpanda no sano / sin datos | `docker compose ps` y `docker compose logs redpanda`; reintentar. Termina solo (tope 200 s). |
| `pii_redactada` en un log | Algo intentó escribir PII en logs | Tratar como incidente: localizar el evento y corregir quién lo emite. |

**Escalar** si: `auditor` ve eventos que no corresponden a corridas conocidas, el trigger de auditoría aparece deshabilitado,
o aparece PII en claro en `core`/`logs`/`out`.

**Recuperar desde cero**: `make clean && make up && make run` (conserva el `.env`; las llaves son las mismas).
