#!/usr/bin/env python3
"""Prepara .env sin pasos manuales (solo libreria estandar).

- Si .env no existe, lo copia de .env.example.
- Si BIA_ENC_KEYS / BIA_INDEX_KEY estan vacias, genera llaves aleatorias de 32 bytes (base64).
- NUNCA sobrescribe valores existentes: perder las llaves haria ilegibles los datos cifrados.
"""
import base64
import os
import re
import secrets
import shutil
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
ENV, EJEMPLO = RAIZ / ".env", RAIZ / ".env.example"


def llave() -> str:
    return base64.b64encode(secrets.token_bytes(32)).decode()


def main() -> int:
    if not ENV.exists():
        if not EJEMPLO.exists():
            print("falta .env.example", file=sys.stderr)
            return 1
        shutil.copy(EJEMPLO, ENV)
        os.chmod(ENV, 0o600)
        print("[init_env] .env creado desde .env.example")
    lineas, cambios = ENV.read_text().splitlines(), 0
    for i, l in enumerate(lineas):
        m = re.fullmatch(r"(BIA_ENC_KEYS|BIA_INDEX_KEY)=\s*", l)
        if m:
            lineas[i] = f"BIA_ENC_KEYS=1:{llave()}" if m.group(1) == "BIA_ENC_KEYS" else f"BIA_INDEX_KEY={llave()}"
            cambios += 1
    if cambios:
        ENV.write_text("\n".join(lineas) + "\n")
        os.chmod(ENV, 0o600)
        print(f"[init_env] {cambios} llave(s) generada(s) (guardelas: sin ellas los datos cifrados no se recuperan)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
