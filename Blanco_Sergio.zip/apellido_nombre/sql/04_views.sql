-- =============================================================================
-- 04_views.sql · Capa analitica (lo unico que ve el rol analista)
--
-- Las vistas corren con los privilegios de su DUENO (bia_owner), por eso el
-- analista no necesita ni tiene acceso a las tablas base. Columnas listadas
-- una a una (nunca SELECT *): si manana alguien agrega una columna PII a core,
-- NO aparece sola en la vista.
-- security_barrier evita que un filtro del consumidor se evalue antes que el
-- de la vista (fuga por funciones con efectos laterales).
-- =============================================================================
\set ON_ERROR_STOP on
SET client_min_messages = warning;
SET ROLE bia_owner;

-- Una fila por frontera-mes con al menos una lectura valida (= out/consumo_mensual.csv)
CREATE OR REPLACE VIEW analytics.v_consumo_mensual
WITH (security_barrier = true) AS
SELECT c.frontera_id,
       f.codigo_sic,
       f.cliente_id,          -- identificador seudonimo (CLI0001), no es PII
       f.mercado,
       f.nivel_tension,
       c.mes,
       round(sum(c.consumo_kwh), 3) AS consumo_kwh,
       count(*)::int                AS horas_con_dato
FROM core.fact_consumo_horario c
JOIN core.dim_frontera f ON f.frontera_id = c.frontera_id
WHERE c.estado = 'VALIDA'
GROUP BY c.frontera_id, f.codigo_sic, f.cliente_id, f.mercado, f.nivel_tension, c.mes;

-- Cobertura (B5): por cada frontera y cada mes CARGADO, cuantas horas faltan.
-- Un hueco es una hora sin lectura valida, exista la fila o no: horas_esperadas
-- sale del calendario, no de lo que haya en la tabla.
CREATE OR REPLACE VIEW analytics.v_cobertura_mensual
WITH (security_barrier = true) AS
WITH meses AS (
  SELECT DISTINCT mes FROM core.fact_consumo_horario
), esperado AS (
  SELECT f.frontera_id,
         m.mes,
         (extract(epoch FROM (to_date(m.mes || '-01', 'YYYY-MM-DD') + interval '1 month'
                              - to_date(m.mes || '-01', 'YYYY-MM-DD'))) / 3600)::int
           AS horas_esperadas
  FROM core.dim_frontera f
  CROSS JOIN meses m
), real AS (
  SELECT frontera_id, mes, (count(*) FILTER (WHERE estado = 'VALIDA'))::int AS horas_con_dato
  FROM core.fact_consumo_horario
  GROUP BY frontera_id, mes
)
SELECT e.frontera_id,
       e.mes,
       e.horas_esperadas,
       coalesce(r.horas_con_dato, 0)                        AS horas_con_dato,
       e.horas_esperadas - coalesce(r.horas_con_dato, 0)    AS horas_sin_lectura_valida
FROM esperado e
LEFT JOIN real r ON r.frontera_id = e.frontera_id AND r.mes = e.mes;

RESET ROLE;
