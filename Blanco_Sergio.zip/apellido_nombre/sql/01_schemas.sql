-- =============================================================================
-- 01_schemas.sql · Esquemas (una zona de confianza por esquema)
--   core        modelo analitico (dimensiones y hechos) · PII solo cifrada
--   analytics   vistas que consume el rol analista · sin PII
--   quarantine  filas rechazadas, con motivo
--   ops         libro de archivos procesados (idempotencia)
--   audit       bitacora append-only
-- =============================================================================
\set ON_ERROR_STOP on

CREATE SCHEMA IF NOT EXISTS core       AUTHORIZATION bia_owner;
CREATE SCHEMA IF NOT EXISTS analytics  AUTHORIZATION bia_owner;
CREATE SCHEMA IF NOT EXISTS quarantine AUTHORIZATION bia_owner;
CREATE SCHEMA IF NOT EXISTS ops        AUTHORIZATION bia_owner;
CREATE SCHEMA IF NOT EXISTS audit      AUTHORIZATION bia_owner;

REVOKE ALL ON SCHEMA core, analytics, quarantine, ops, audit FROM PUBLIC;

-- Lo que bia_owner cree en el futuro no hereda EXECUTE para PUBLIC.
ALTER DEFAULT PRIVILEGES FOR ROLE bia_owner REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
