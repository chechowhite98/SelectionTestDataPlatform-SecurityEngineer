-- =============================================================================
-- 03_quarantine_ops_audit.sql · Cuarentena, libro de archivos y bitacora
-- =============================================================================
\set ON_ERROR_STOP on
SET client_min_messages = warning;
SET ROLE bia_owner;

-- -----------------------------------------------------------------------------
-- quarantine.rechazo · lo rechazado NO se borra, queda con su motivo.
--   * clave_natural y detalle: SOLO datos no personales (ids tecnicos, codigos).
--   * payload_cifrado: la fila original completa, cifrada por la aplicacion
--     (puede traer NIT/email, p.ej. una factura huerfana). Mismo dominio de
--     PII cifrada que el resto del modelo.
--   * UNIQUE (fuente, archivo, fila_origen, motivo): reprocesar el mismo archivo
--     no duplica la cuarentena (idempotencia). Se inserta con ON CONFLICT DO NOTHING.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS quarantine.rechazo (
  rechazo_id      bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  fuente          text NOT NULL CHECK (fuente IN ('consumos','facturacion','clientes','fronteras','stream')),
  archivo         text NOT NULL,
  fila_origen     integer NOT NULL,
  clave_natural   text,
  motivo          text NOT NULL,
  detalle         text,
  payload_cifrado core.pii_cifrado,
  corrida_id      uuid NOT NULL,
  registrado_en   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (fuente, archivo, fila_origen, motivo)
);

-- -----------------------------------------------------------------------------
-- ops.archivo_cargado · libro de archivos vistos (nombre + hash).
-- Permite saltar archivos ya cargados y dejar constancia de los rechazados
-- enteros (truncados/corruptos) sin tocar lo que ya estaba cargado.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ops.archivo_cargado (
  nombre_archivo    text NOT NULL,
  sha256            text NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
  fuente            text NOT NULL,
  estado            text NOT NULL CHECK (estado IN ('CARGADO','RECHAZADO')),
  filas_leidas      integer NOT NULL CHECK (filas_leidas >= 0),
  filas_cargadas    integer NOT NULL CHECK (filas_cargadas >= 0),
  filas_rechazadas  integer NOT NULL CHECK (filas_rechazadas >= 0),
  motivo_rechazo    text,
  corrida_id        uuid NOT NULL,
  procesado_en      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (nombre_archivo, sha256)
);

-- -----------------------------------------------------------------------------
-- audit.pipeline_runs · bitacora APPEND-ONLY (C5)
-- Tabla de EVENTOS: como UPDATE esta prohibido, una corrida escribe una fila
-- INICIO, opcionalmente una por ETAPA, y una FIN. Si el proceso muere a mitad,
-- queda el INICIO sin FIN: eso tambien es evidencia.
--   quien  -> ejecutado_por (session_user: no se falsea con SET ROLE) + origen_ip
--   que    -> etapa / detalle (SOLO contadores y codigos; jamas contenido de filas)
--   cuando -> ocurrido_en (clock_timestamp, no el inicio de la transaccion)
--   cuantas filas / resultado -> columnas dedicadas
-- El id de corrida lo genera el cliente (uuid4), asi ingesta no necesita SELECT.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit.pipeline_runs (
  evento_id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  corrida_id        uuid NOT NULL,
  evento            text NOT NULL CHECK (evento IN ('INICIO','ETAPA','FIN')),
  etapa             text,
  resultado         text CHECK (resultado IN ('OK','ERROR','PARCIAL')),
  filas_leidas      bigint CHECK (filas_leidas      >= 0),
  filas_cargadas    bigint CHECK (filas_cargadas    >= 0),
  filas_rechazadas  bigint CHECK (filas_rechazadas  >= 0),
  detalle           jsonb NOT NULL DEFAULT '{}'::jsonb,
  ejecutado_por     text NOT NULL DEFAULT session_user,
  origen_ip         inet DEFAULT inet_client_addr(),
  ocurrido_en       timestamptz NOT NULL DEFAULT clock_timestamp(),
  CONSTRAINT ck_resultado_requerido CHECK (evento = 'INICIO' OR resultado IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS ix_pipeline_runs_corrida ON audit.pipeline_runs (corrida_id, evento_id);

-- Segunda capa, ademas del REVOKE (ver 05_grants.sql): un trigger que aborta
-- cualquier UPDATE/DELETE/TRUNCATE, incluso del superusuario. ENABLE ALWAYS lo
-- mantiene activo aunque alguien cambie session_replication_role.
CREATE OR REPLACE FUNCTION audit.fn_bloquear_mutacion() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'audit.% es append-only: % no permitido', TG_TABLE_NAME, TG_OP
    USING ERRCODE = 'insufficient_privilege';
END $$;

CREATE OR REPLACE TRIGGER trg_pipeline_runs_inmutable
  BEFORE UPDATE OR DELETE ON audit.pipeline_runs
  FOR EACH ROW EXECUTE FUNCTION audit.fn_bloquear_mutacion();

CREATE OR REPLACE TRIGGER trg_pipeline_runs_sin_truncate
  BEFORE TRUNCATE ON audit.pipeline_runs
  FOR EACH STATEMENT EXECUTE FUNCTION audit.fn_bloquear_mutacion();

ALTER TABLE audit.pipeline_runs ENABLE ALWAYS TRIGGER trg_pipeline_runs_inmutable;
ALTER TABLE audit.pipeline_runs ENABLE ALWAYS TRIGGER trg_pipeline_runs_sin_truncate;

RESET ROLE;
