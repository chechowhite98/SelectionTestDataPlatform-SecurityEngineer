-- =============================================================================
-- 02_core.sql · Modelo analitico (dimensional)
--
-- Todo se crea como bia_owner (nologin). Idempotente: IF NOT EXISTS.
-- Convencion de nombres: columnas con PII terminan en _cifrado/_cifrada.
-- =============================================================================
\set ON_ERROR_STOP on
SET client_min_messages = warning;
SET ROLE bia_owner;

-- -----------------------------------------------------------------------------
-- Dominio de PII cifrada.
-- Contrato con la capa de aplicacion (envelope AES-256-GCM):
--     version_clave(1 B) || nonce(12 B) || texto_cifrado(n B) || tag(16 B)
-- => minimo 29 bytes aun con texto vacio. Un NIT o un email en claro (< 29 B,
-- o al menos mal formado) NO entra: la base rechaza el INSERT. Es una red de
-- seguridad contra un bug del pipeline, no reemplaza al cifrado.
-- -----------------------------------------------------------------------------
DO $$
BEGIN
  CREATE DOMAIN core.pii_cifrado AS bytea
    CONSTRAINT ck_pii_cifrado_formato CHECK (octet_length(VALUE) >= 29);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- -----------------------------------------------------------------------------
-- dim_cliente · contiene PII (Ley 1581)
--   nit_hash = HMAC-SHA256(llave_indice, NIT normalizado a solo digitos).
--   Sirve para JOIN/igualdad sin exponer el NIT; no es reversible sin la llave.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS core.dim_cliente (
  cliente_id                   text PRIMARY KEY,
  razon_social                 text NOT NULL,               -- sin limite de largo (B7)
  nit_hash                     bytea NOT NULL UNIQUE
                                 CONSTRAINT ck_nit_hash_len CHECK (octet_length(nit_hash) = 32),
  nit_cifrado                  core.pii_cifrado NOT NULL,
  email_contacto_cifrado       core.pii_cifrado,
  celular_contacto_cifrado     core.pii_cifrado,
  direccion_cifrada            core.pii_cifrado,
  representante_legal_cifrado  core.pii_cifrado,
  observaciones_enmascaradas   text,                        -- texto libre YA enmascarado (C2)
  observaciones_pii_tipos      text[] NOT NULL DEFAULT '{}',-- p.ej. {email,celular}; vacio = sin PII
  ciudad                       text,
  departamento                 text,
  clave_version                smallint NOT NULL CHECK (clave_version > 0),
  -- HMAC del contenido en claro del registro. El cifrado es aleatorio (nonce nuevo
  -- cada vez), asi que no se puede saber si un cliente cambio comparando cifrados;
  -- con la huella, el upsert solo reescribe lo que realmente cambio (idempotencia).
  huella_contenido             bytea NOT NULL
                                 CONSTRAINT ck_huella_len CHECK (octet_length(huella_contenido) = 32),
  cargado_en                   timestamptz NOT NULL DEFAULT now()
);

-- -----------------------------------------------------------------------------
-- dim_frontera · incluye la banda operativa (limites_frontera.csv)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS core.dim_frontera (
  frontera_id     text PRIMARY KEY
                    CONSTRAINT ck_frontera_id CHECK (frontera_id ~ '^CO[0-9]{10}$'),
  codigo_sic      text NOT NULL,
  cliente_id      text NOT NULL REFERENCES core.dim_cliente (cliente_id),
  mercado         text,
  operador_red    text,
  nivel_tension   smallint,
  fecha_registro  date,
  estado          text,
  min_kwh         numeric(20,6),
  max_kwh         numeric(20,6),
  cargado_en      timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_banda CHECK (max_kwh IS NULL OR min_kwh IS NULL OR max_kwh >= min_kwh)
);

-- -----------------------------------------------------------------------------
-- fact_consumo_horario · una fila por (frontera, hora) = la lectura GANADORA.
--
-- B1: la fuente de verdad es el instante UTC; hora y mes locales (America/Bogota,
--     UTC-5 fijo) son columnas generadas, asi nadie puede desalinearlas.
-- B3: desempate DETERMINISTA e independiente del orden de carga:
--        (version_lectura, archivo_origen, fila_origen)  mayor gana.
--     Por eso reprocesar un archivo viejo, o cargar abril antes que su
--     correccion, converge siempre al mismo estado.
-- B4/B5: si la lectura ganadora es invalida se guarda con estado='INVALIDA' y
--     consumo NULL (no se imputa). Cuenta como hueco, y la lectura perdedora
--     que fuera valida NO resucita. Las vistas solo suman estado='VALIDA'.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS core.fact_consumo_horario (
  frontera_id       text NOT NULL REFERENCES core.dim_frontera (frontera_id),
  ts_utc            timestamptz NOT NULL,
  ts_local          timestamp GENERATED ALWAYS AS (ts_utc AT TIME ZONE 'America/Bogota') STORED,
  -- 'YYYY-MM' en hora local. No se usa to_char(): Postgres lo marca STABLE y
  -- no se permite en columnas generadas; extract + lpad si son inmutables.
  mes               text GENERATED ALWAYS AS (
                      extract(year  FROM (ts_utc AT TIME ZONE 'America/Bogota'))::int::text
                      || '-' ||
                      lpad(extract(month FROM (ts_utc AT TIME ZONE 'America/Bogota'))::int::text, 2, '0')
                    ) STORED,
  consumo_kwh       numeric(20,6),
  estado            text NOT NULL,
  motivo_invalidez  text,
  version_lectura   integer NOT NULL CHECK (version_lectura >= 1),
  calidad_lectura   text,
  unidad_origen     text NOT NULL DEFAULT 'kWh' CHECK (unidad_origen IN ('Wh','kWh','MWh','GWh')),
  -- COLLATE "C": el desempate de B3 compara nombres de archivo y debe ser orden
  -- lexicografico por codigo de caracter, igual que en Python, sin depender de la
  -- locale del servidor (con en_US, '.' y '_' se ordenan distinto y el resultado cambiaria).
  archivo_origen    text COLLATE "C" NOT NULL,
  fila_origen       integer NOT NULL,
  cargado_en        timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (frontera_id, ts_utc),
  CONSTRAINT ck_hora_exacta CHECK (mod(extract(epoch FROM ts_utc), 3600) = 0),
  CONSTRAINT ck_estado_valor CHECK (
       (estado = 'VALIDA'   AND consumo_kwh BETWEEN 0 AND 1000000 AND motivo_invalidez IS NULL)
    OR (estado = 'INVALIDA' AND consumo_kwh IS NULL
                            AND motivo_invalidez IN ('NULO','NEGATIVO','OUTLIER'))
  )
);
CREATE INDEX IF NOT EXISTS ix_fact_consumo_mes ON core.fact_consumo_horario (mes, frontera_id);

-- -----------------------------------------------------------------------------
-- Facturacion (B6: las huerfanas NO llegan aqui; van a quarantine).
-- Minimizacion de datos: el JSON trae NIT y email de facturacion; no hacen
-- falta para analitica, asi que NO se persisten. Solo el hash del NIT, para
-- poder detectar una factura emitida a un NIT distinto al del maestro.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS core.fact_factura (
  factura_id             text PRIMARY KEY,
  frontera_id            text NOT NULL REFERENCES core.dim_frontera (frontera_id),
  periodo                text NOT NULL CHECK (periodo ~ '^[0-9]{4}-(0[1-9]|1[0-2])$'),
  cliente_nit_hash       bytea NOT NULL CHECK (octet_length(cliente_nit_hash) = 32),
  consumo_facturado_kwh  numeric(20,6),
  tarifa_cop_kwh         numeric(20,6),
  valor_total_cop        numeric(20,2),
  metodo_pago_tipo       text,
  cuenta_enmascarada     text,                -- ya viene enmascarada en origen
  archivo_origen         text NOT NULL,
  cargado_en             timestamptz NOT NULL DEFAULT now(),
  UNIQUE (frontera_id, periodo)
);

CREATE TABLE IF NOT EXISTS core.fact_factura_componente (
  factura_id     text NOT NULL REFERENCES core.fact_factura (factura_id),
  concepto       text NOT NULL,
  valor_cop_kwh  numeric(20,6),
  PRIMARY KEY (factura_id, concepto)
);

RESET ROLE;
