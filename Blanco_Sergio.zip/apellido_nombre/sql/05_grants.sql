-- =============================================================================
-- 05_grants.sql · Menor privilegio (C4). Es el ULTIMO archivo: parte de cero.
--
--   ingesta  escribe el modelo. Lee solo texto cifrado (jamas PII en claro: la
--            base no la contiene). Sin DELETE, TRUNCATE ni DDL.
--   analista solo SELECT sobre las vistas de analytics. Nada mas.
--   auditor  solo SELECT sobre audit.pipeline_runs. Nada mas.
-- =============================================================================
\set ON_ERROR_STOP on

-- Punto de partida limpio: se retira todo y se concede explicitamente.
REVOKE ALL ON ALL TABLES    IN SCHEMA core, analytics, quarantine, ops, audit
  FROM PUBLIC, ingesta, analista, auditor;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA core, analytics, quarantine, ops, audit
  FROM PUBLIC, ingesta, analista, auditor;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA core, analytics, quarantine, ops, audit
  FROM PUBLIC, ingesta, analista, auditor;

-- ---- ingesta -----------------------------------------------------------------
GRANT USAGE ON SCHEMA core, quarantine, ops, audit TO ingesta;
-- UPDATE y SELECT hacen falta para el upsert (ON CONFLICT DO UPDATE ... WHERE
-- compara contra la fila existente). No se concede DELETE a proposito.
GRANT SELECT, INSERT, UPDATE ON core.dim_cliente, core.dim_frontera,
      core.fact_consumo_horario, core.fact_factura, core.fact_factura_componente
  TO ingesta;
GRANT SELECT, INSERT ON quarantine.rechazo, ops.archivo_cargado TO ingesta;
GRANT INSERT ON audit.pipeline_runs TO ingesta;      -- solo insertar, ni siquiera leer

-- ---- analista ----------------------------------------------------------------
GRANT USAGE ON SCHEMA analytics TO analista;
GRANT SELECT ON analytics.v_consumo_mensual, analytics.v_cobertura_mensual TO analista;

-- ---- auditor -----------------------------------------------------------------
GRANT USAGE ON SCHEMA audit TO auditor;
GRANT SELECT ON audit.pipeline_runs TO auditor;

-- ---- bitacora append-only: UPDATE/DELETE/TRUNCATE revocados DE VERDAD ----------
-- Tambien al dueno. (El trigger de 03_ cubre el resto, incluido el superusuario.)
REVOKE UPDATE, DELETE, TRUNCATE ON audit.pipeline_runs
  FROM PUBLIC, ingesta, analista, auditor, bia_owner;
