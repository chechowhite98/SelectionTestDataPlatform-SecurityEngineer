-- =============================================================================
-- 00_roles.sql · Roles y endurecimiento a nivel de base de datos
--
-- Corre como superusuario, UNA vez por volumen (lo invoca docker/initdb) o a
-- mano con `make migrate`. Es idempotente: se puede repetir sin efectos.
--
-- Las contrasenas NO viven en este archivo: se leen de variables de entorno
-- con \getenv, asi no quedan en el repo ni en la lista de procesos (ps).
-- =============================================================================
\set ON_ERROR_STOP on
\getenv ingesta_pw  INGESTA_PASSWORD
\getenv analista_pw ANALISTA_PASSWORD
\getenv auditor_pw  AUDITOR_PASSWORD

-- Falla rapido si falta una variable (psql dejaria :'x' literal -> error de
-- sintaxis) o si la contrasena es trivial.
SELECT (length(:'ingesta_pw') >= 12 AND length(:'analista_pw') >= 12
        AND length(:'auditor_pw') >= 12) AS pw_ok \gset
\if :pw_ok
\else
  DO $$ BEGIN RAISE EXCEPTION 'Las contrasenas de roles deben tener >= 12 caracteres'; END $$;
\endif

-- Que las contrasenas no queden en el log del servidor ni se guarden en claro.
SET log_statement = 'none';
SET password_encryption = 'scram-sha-256';

-- bia_owner es DUENO de los objetos y no puede iniciar sesion: nadie "es" el
-- dueno, asi que ningun login corriente puede hacer DDL ni saltarse los grants.
SELECT format('CREATE ROLE %I', r)
FROM unnest(ARRAY['bia_owner','ingesta','analista','auditor']) AS r
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r)
\gexec

ALTER ROLE bia_owner NOLOGIN   NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
ALTER ROLE ingesta   LOGIN     NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS
       CONNECTION LIMIT 10 PASSWORD :'ingesta_pw';
ALTER ROLE analista  LOGIN     NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS
       CONNECTION LIMIT 10 PASSWORD :'analista_pw';
ALTER ROLE auditor   LOGIN     NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS
       CONNECTION LIMIT 5  PASSWORD :'auditor_pw';

-- Defensa en profundidad (no sustituye a los GRANT): sesiones de solo lectura
-- y con topes de tiempo para los roles que consultan.
ALTER ROLE analista SET default_transaction_read_only = on;
ALTER ROLE analista SET statement_timeout = '30s';
ALTER ROLE analista SET idle_in_transaction_session_timeout = '60s';
ALTER ROLE auditor  SET default_transaction_read_only = on;
ALTER ROLE auditor  SET statement_timeout = '30s';
ALTER ROLE auditor  SET idle_in_transaction_session_timeout = '60s';
ALTER ROLE ingesta  SET idle_in_transaction_session_timeout = '10min';

-- Base de datos: nadie entra ni crea temporales por el simple hecho de existir.
SELECT current_database() AS db \gset
REVOKE ALL ON DATABASE :"db" FROM PUBLIC;
GRANT CONNECT ON DATABASE :"db" TO ingesta, analista, auditor;

-- El esquema public queda inutilizable para todos menos el superusuario.
REVOKE ALL ON SCHEMA public FROM PUBLIC;
