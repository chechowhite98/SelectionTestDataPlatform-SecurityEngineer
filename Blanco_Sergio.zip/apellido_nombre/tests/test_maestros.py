"""Maestros (clientes, fronteras) y facturacion: B6, B7, C2, C3."""
import csv
import io
import json
import re
from decimal import Decimal
from pathlib import Path

import pytest

from bia import facturacion, maestros, pii
from bia import rechazo as Z
from bia.cripto import ErrorCripto
from bia.maestros import MaestroInvalido

ENC = ["cliente_id", "razon_social", "nit", "email_contacto", "celular_contacto", "direccion",
       "ciudad", "departamento", "representante_legal", "observaciones"]


def _cliente(cid="CLI0001", razon="Acme SAS", nit="900123456-7", email="contacto@acme.co",
             cel="3001234567", direccion="Cra 7 # 71-21", ciudad="Bogota", depto="Cundinamarca",
             rep="Maria Perez", obs="Sin novedades."):
    return [cid, razon, nit, email, cel, direccion, ciudad, depto, rep, obs]


def _csv_clientes(tmp_path, filas, encoding="latin-1", encabezado=ENC):
    buf = io.StringIO(newline="")
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(encabezado)
    w.writerows(filas)
    ruta = tmp_path / "clientes.csv"
    ruta.write_bytes(buf.getvalue().encode(encoding))
    return ruta


# --------------------------------------------------------------- clientes (sinteticos)
def test_una_fila_normal_sale_cifrada_y_atada_a_su_fila(tmp_path, cifrador):
    r = maestros.leer_clientes(_csv_clientes(tmp_path, [_cliente()]), cifrador)
    c = r.clientes[0]
    assert cifrador.descifrar_texto(c.nit_cifrado, "core.dim_cliente.nit_cifrado|CLI0001") == "9001234567"
    assert cifrador.descifrar_texto(c.email_contacto_cifrado,
                                    "core.dim_cliente.email_contacto_cifrado|CLI0001") == "contacto@acme.co"
    assert c.nit_hash == cifrador.indice_ciego("9001234567")
    with pytest.raises(ErrorCripto):                         # el NIT de CLI0001 no sirve para CLI0002
        cifrador.descifrar(c.nit_cifrado, "core.dim_cliente.nit_cifrado|CLI0002")


def test_acentos_en_latin1_se_conservan(tmp_path, cifrador):
    f = _cliente(razon="Compañía Ñandú S.A.", direccion="Calle 10 # 5-20, Bogotá")
    r = maestros.leer_clientes(_csv_clientes(tmp_path, [f], encoding="latin-1"), cifrador)
    assert r.clientes[0].razon_social == "Compañía Ñandú S.A."
    assert cifrador.descifrar_texto(r.clientes[0].direccion_cifrada,
                                    "core.dim_cliente.direccion_cifrada|CLI0001") == "Calle 10 # 5-20, Bogotá"


def test_entradas_hostiles_son_datos_y_ninguna_fila_se_pierde(tmp_path, cifrador):
    hostiles = [
        _cliente("CLI0001", razon='Empresa "Los \'Mejores\'" y "otra ""anidada"""'),         # comillas anidadas
        _cliente("CLI0002", nit="800.111.222-3", direccion="Calle 1\nPiso 2\r\nOficina 3"),  # saltos de linea
        _cliente("CLI0003", nit="811222333-4", razon="X" * 200_000),                          # cadena larguisima
        _cliente("CLI0004", nit="822333444-5", razon="Robert'); DROP TABLE core.fact_consumo_horario;--"),
        _cliente("CLI0005", nit="833444555-6", razon="'; DELETE FROM core.dim_cliente; --"),
    ]
    r = maestros.leer_clientes(_csv_clientes(tmp_path, hostiles), cifrador)
    assert r.filas_leidas == 5 and len(r.clientes) == 5 and r.rechazos == []
    por = {c.cliente_id: c for c in r.clientes}
    assert por["CLI0001"].razon_social == hostiles[0][1]
    assert len(por["CLI0003"].razon_social) == 200_000
    assert por["CLI0004"].razon_social == "Robert'); DROP TABLE core.fact_consumo_horario;--"
    assert cifrador.descifrar_texto(por["CLI0002"].direccion_cifrada,
                                    "core.dim_cliente.direccion_cifrada|CLI0002") == "Calle 1\nPiso 2\r\nOficina 3"


def test_leidas_es_igual_a_cargadas_mas_rechazadas(tmp_path, cifrador):
    filas = [
        _cliente("CLI0001"),
        _cliente("CLI0002", nit="800111222-3"),
        ["CLI0003", "solo", "tres"],                                                   # ancho incorrecto
        _cliente("CLI 0004", nit="811222333-4"),                                       # id invalido
        _cliente("CLI0005", nit="no-tiene-digitos"),                                   # NIT invalido
        _cliente("CLI0006", razon="   ", nit="822333444-5"),                           # razon vacia
        _cliente("CLI0007", nit="800.111.222-3"),                                      # NIT repetido (de CLI0002)
        _cliente("CLI0001", razon="Acme actualizada", nit="900123456-7"),              # id repetido: gana la ultima
    ]
    r = maestros.leer_clientes(_csv_clientes(tmp_path, filas), cifrador)
    assert r.filas_leidas == 8
    assert len(r.clientes) + len(r.rechazos) == 8                                      # NADA se pierde
    assert {c.cliente_id for c in r.clientes} == {"CLI0001", "CLI0002"}
    assert next(c for c in r.clientes if c.cliente_id == "CLI0001").razon_social == "Acme actualizada"
    assert sorted(x.motivo for x in r.rechazos) == sorted([
        Z.M_NUM_CAMPOS, Z.M_CLIENTE_ID_INVALIDO, Z.M_NIT_INVALIDO, Z.M_RAZON_SOCIAL_VACIA,
        Z.M_NIT_DUPLICADO, Z.M_CLIENTE_DUPLICADO])


def test_la_cuarentena_no_guarda_pii_en_claro(tmp_path, cifrador):
    r = maestros.leer_clientes(_csv_clientes(tmp_path, [_cliente("CLI0001", nit="sin-digitos",
                                                                 email="secreto@privado.co")]), cifrador)
    x = r.rechazos[0]
    assert x.motivo == Z.M_NIT_INVALIDO and x.payload_cifrado and b"secreto@privado.co" not in x.payload_cifrado
    assert x.detalle is None and "secreto" not in repr(x.clave_natural)
    original = json.loads(cifrador.descifrar_texto(x.payload_cifrado, f"quarantine.rechazo.payload|clientes|clientes.csv|{x.fila}"))
    assert original["email_contacto"] == "secreto@privado.co"           # y es recuperable por quien tiene la llave


def test_pii_en_observaciones_se_enmascara_y_se_cuenta(tmp_path, cifrador):
    filas = [_cliente("CLI0001", obs="Enviar a x@y.co"),
             _cliente("CLI0002", nit="800111222-3", obs="CC 80123456"),
             _cliente("CLI0003", nit="811222333-4", obs="Sin novedades."),
             _cliente("CLI0004", nit="822333444-5", obs="")]
    r = maestros.leer_clientes(_csv_clientes(tmp_path, filas), cifrador)
    assert r.con_pii_en_texto_libre == 2
    obs = {c.cliente_id: c.observaciones_enmascaradas for c in r.clientes}
    assert obs == {"CLI0001": "Enviar a [EMAIL]", "CLI0002": "CC [CEDULA]", "CLI0003": "Sin novedades.", "CLI0004": None}
    assert not any(pii.contiene_pii(v) for v in obs.values())


def test_campos_vacios_no_se_cifran(tmp_path, cifrador):
    r = maestros.leer_clientes(_csv_clientes(tmp_path, [_cliente(email="", cel="  ", direccion="")]), cifrador)
    c = r.clientes[0]
    assert (c.email_contacto_cifrado, c.celular_contacto_cifrado, c.direccion_cifrada) == (None, None, None)


def test_la_huella_es_estable_aunque_el_cifrado_cambie(tmp_path, cifrador):
    """Base de la idempotencia: dos lecturas del mismo archivo cifran distinto pero con la misma huella."""
    ruta = _csv_clientes(tmp_path, [_cliente()])
    a = maestros.leer_clientes(ruta, cifrador).clientes[0]
    b = maestros.leer_clientes(ruta, cifrador).clientes[0]
    assert a.nit_cifrado != b.nit_cifrado and a.huella_contenido == b.huella_contenido
    ruta2 = _csv_clientes(tmp_path, [_cliente(direccion="Otra direccion")])
    assert maestros.leer_clientes(ruta2, cifrador).clientes[0].huella_contenido != a.huella_contenido


def test_cada_formato_de_nit_da_el_mismo_indice(tmp_path, cifrador):
    formatos = ["900123456-7", "900.123.456-7", "NIT 900123456-7", "9001234567"]
    hashes = {maestros.leer_clientes(_csv_clientes(tmp_path, [_cliente(nit=n)]), cifrador).clientes[0].nit_hash
              for n in formatos}
    assert len(hashes) == 1


@pytest.mark.parametrize("contenido", [b"", b"   \r\n", b"\x00\x01\x02"])
def test_maestro_ilegible_es_fatal(tmp_path, cifrador, contenido):
    ruta = tmp_path / "clientes.csv"
    ruta.write_bytes(contenido)
    with pytest.raises(MaestroInvalido):
        maestros.leer_clientes(ruta, cifrador)


def test_maestro_sin_columnas_esperadas_es_fatal(tmp_path, cifrador):
    ruta = _csv_clientes(tmp_path, [["a", "b"]], encabezado=["a", "b"])
    with pytest.raises(MaestroInvalido, match="faltan columnas"):
        maestros.leer_clientes(ruta, cifrador)


def test_leer_clientes_no_deja_el_limite_de_csv_cambiado(tmp_path, cifrador):
    antes = csv.field_size_limit()
    maestros.leer_clientes(_csv_clientes(tmp_path, [_cliente(razon="X" * 300_000)]), cifrador)
    assert csv.field_size_limit() == antes                       # no contamina a los demas lectores


# ---------------------------------------------------------------- fronteras (sinteticos)
def _escribir_csv(ruta, encabezado, filas):
    buf = io.StringIO(newline="")
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(encabezado)
    w.writerows(filas)                       # cita lo necesario, p.ej. el decimal con coma "200,5"
    ruta.write_bytes(buf.getvalue().encode("latin-1"))
    return ruta


FR_COLS = ["frontera_id", "codigo_sic", "cliente_id", "mercado", "operador_red", "nivel_tension", "fecha_registro", "estado"]


def test_fronteras_con_banda_y_rechazos(tmp_path):
    fr = _escribir_csv(tmp_path / "f.csv", FR_COLS, [
        ["CO0000000001", "frt1", "CLI0001", "No Regulado", "ENEL", "3", "2024-01-05", "ACTIVA"],
        ["CO0000000002", "frt2", "CLI9999", "No Regulado", "ENEL", "3", "2024-01-05", "ACTIVA"],   # cliente inexistente
        ["XX0000000003", "frt3", "CLI0001", "", "", "", "", ""],                                   # id invalido
        ["CO0000000004", "frt4", "CLI0001", "", "", "x", "", ""],                                  # nivel_tension no numerico
        ["CO0000000005", "frt5", "CLI0001", "", "", "", "no-es-fecha", ""],                        # fecha invalida
        ["CO0000000006", "frt6", "CLI0001", "", "", "", "", ""],
    ])
    lim = _escribir_csv(tmp_path / "l.csv", ["frontera_id", "min_kwh", "max_kwh"], [
        ["CO0000000001", "8.0", "200,5"],
        ["CO0000000006", "9", "1"],                    # min > max: banda invalida (la frontera se carga sin banda)
        ["CO0000000099", "1", "2"],                    # frontera que no existe
    ])
    r = maestros.leer_fronteras(fr, lim, {"CLI0001"})
    assert {f.frontera_id for f in r.fronteras} == {"CO0000000001", "CO0000000006"}
    f1 = next(f for f in r.fronteras if f.frontera_id == "CO0000000001")
    assert (f1.min_kwh, f1.max_kwh) == (Decimal("8.0"), Decimal("200.5"))
    assert next(f for f in r.fronteras if f.frontera_id == "CO0000000006").max_kwh is None
    assert sorted(x.motivo for x in r.rechazos) == sorted([
        Z.M_CLIENTE_INEXISTENTE, Z.M_FRONTERA_INVALIDA, Z.M_VALOR_INVALIDO, Z.M_VALOR_INVALIDO,
        Z.M_BANDA_INVALIDA, Z.M_FRONTERA_DESCONOCIDA])


# -------------------------------------------------------------- facturacion (sinteticos)
def _factura(fid="F-202605-0001", frontera="CO0000000001", nit="900123456-7", **extra):
    f = {"factura_id": fid, "frontera_id": frontera,
         "cliente": {"nit": nit, "razon_social": "Acme", "email_facturacion": "fact@acme.co"},
         "consumo_facturado_kwh": 1234.5, "tarifa_cop_kwh": 497.23, "valor_total_cop": 613777.4,
         "componentes": [{"concepto": "G", "valor_cop_kwh": 223.75}, {"concepto": "T", "valor_cop_kwh": 39.78}],
         "metodo_pago": {"tipo": "debito_automatico", "cuenta_enmascarada": "****6527"}}
    f.update(extra)
    return f


def _json_fact(tmp_path, nombre, facturas, periodo="2026-05"):
    d = tmp_path / "fact"
    d.mkdir(exist_ok=True)
    (d / nombre).write_text(json.dumps({"periodo": periodo, "emisor": {"nombre": "Bia", "nit": "1"},
                                        "generado_en": "2026-06-01T00:00:00-05:00", "facturas": facturas}),
                            encoding="utf-8")
    return d


def test_factura_huerfana_va_a_cuarentena_con_payload_cifrado(tmp_path, cifrador):
    d = _json_fact(tmp_path, "facturacion_2026-05.json",
                   [_factura(), _factura("F-202605-9001", "CO9999999999", nit="800111222-3")])
    r = facturacion.leer_facturacion(d, {"CO0000000001"}, cifrador)
    assert (r.facturas_leidas, len(r.facturas), r.fronteras_huerfanas) == (2, 1, 1)
    x = r.rechazos[0]
    assert (x.motivo, x.clave_natural, x.fuente) == (Z.M_FRONTERA_HUERFANA, "F-202605-9001", "facturacion")
    assert b"800111222" not in x.payload_cifrado and b"fact@acme.co" not in x.payload_cifrado


def test_la_factura_no_persiste_nit_ni_email_en_claro(tmp_path, cifrador):
    d = _json_fact(tmp_path, "facturacion_2026-05.json", [_factura()])
    f = facturacion.leer_facturacion(d, {"CO0000000001"}, cifrador).facturas[0]
    campos = repr(f.__dict__)
    assert "fact@acme.co" not in campos and "900123456" not in campos
    assert f.cliente_nit_hash == cifrador.indice_ciego("9001234567")


def test_los_decimales_son_exactos(tmp_path, cifrador):
    d = _json_fact(tmp_path, "facturacion_2026-05.json", [_factura()])
    f = facturacion.leer_facturacion(d, {"CO0000000001"}, cifrador).facturas[0]
    assert f.tarifa_cop_kwh == Decimal("497.23") and f.consumo_facturado_kwh == Decimal("1234.5")
    assert f.componentes == (("G", Decimal("223.75")), ("T", Decimal("39.78")))


def test_facturas_invalidas_y_duplicadas_no_se_pierden(tmp_path, cifrador):
    malas = [
        _factura("F-1", nit="sin-digitos"),                                   # NIT invalido
        _factura("F-2", componentes="no-es-lista"),                            # estructura
        _factura("F-3", consumo_facturado_kwh="mucho"),                        # tipo incorrecto
        _factura("F-4", componentes=[{"concepto": "G", "valor_cop_kwh": 1}, {"concepto": "G", "valor_cop_kwh": 2}]),
        "esto-no-es-una-factura",
        {"factura_id": "F-6"},                                                 # sin frontera
        _factura("F-7"),
        _factura("F-8"),                                                       # misma (frontera, periodo) que F-7
    ]
    d = _json_fact(tmp_path, "facturacion_2026-05.json", malas)
    r = facturacion.leer_facturacion(d, {"CO0000000001"}, cifrador)
    assert r.facturas_leidas == 8 and len(r.facturas) + len(r.rechazos) == 8      # NADA se pierde
    assert [f.factura_id for f in r.facturas] == ["F-8"]                           # gana la ultima
    motivos = sorted(x.motivo for x in r.rechazos)
    assert motivos.count(Z.M_FACTURA_INVALIDA) == 6 and motivos.count(Z.M_FACTURA_DUPLICADA) == 1


@pytest.mark.parametrize("contenido", ["{no es json", "[]", '{"periodo": "2026-05"}',
                                       '{"periodo": "mayo", "facturas": []}', '{"facturas": []}'])
def test_archivo_de_facturacion_invalido_se_rechaza_entero(tmp_path, cifrador, contenido):
    d = tmp_path / "fact"
    d.mkdir()
    (d / "facturacion_2026-05.json").write_text(contenido)
    (d / "facturacion_2026-06.json").write_text(json.dumps({"periodo": "2026-06", "facturas": [_factura()]}))
    r = facturacion.leer_facturacion(d, {"CO0000000001"}, cifrador)
    assert [e for _, _, e in r.archivos] == ["RECHAZADO", "OK"]
    assert r.rechazos[0].motivo == Z.M_ARCHIVO_INVALIDO and r.rechazos[0].fila == 0
    assert len(r.facturas) == 1                                              # el otro archivo no se ve afectado


# ------------------------------------------------------------- datos reales
@pytest.fixture(scope="module")
def real(datos_reales, cifrador):
    cl = maestros.leer_clientes(datos_reales / "maestros" / "clientes.csv", cifrador)
    fr = maestros.leer_fronteras(datos_reales / "maestros" / "fronteras.csv",
                                 datos_reales / "maestros" / "limites_frontera.csv",
                                 {c.cliente_id for c in cl.clientes})
    ruta = datos_reales / "facturacion"
    fa = facturacion.leer_facturacion(ruta, {f.frontera_id for f in fr.fronteras}, cifrador) if ruta.is_dir() else None
    return cl, fr, fa


def _originales(datos_reales):
    texto = (datos_reales / "maestros" / "clientes.csv").read_bytes().decode("latin-1")
    return {r["cliente_id"]: r for r in csv.DictReader(io.StringIO(texto, newline=""))}


def test_real_clientes_ninguna_fila_se_pierde(real):
    cl, _, _ = real
    assert cl.filas_leidas == 40 and len(cl.clientes) == 40 and cl.rechazos == []


def test_real_pii_en_texto_libre(real):
    cl, _, _ = real
    assert cl.con_pii_en_texto_libre == 25
    por_tipo = {t: sum(t in c.observaciones_pii_tipos for c in cl.clientes) for t in ("email", "celular", "cedula")}
    assert por_tipo == {"email": 14, "celular": 11, "cedula": 6}
    assert not any(pii.contiene_pii(c.observaciones_enmascaradas) for c in cl.clientes)


def test_real_los_hostiles_se_conservan_como_datos(real, datos_reales):
    cl, _, _ = real
    orig = _originales(datos_reales)
    por = {c.cliente_id: c for c in cl.clientes}
    assert "DROP TABLE" in por["CLI0036"].razon_social
    assert len(por["CLI0033"].razon_social) == 1632
    for cid in ("CLI0013", "CLI0022", "CLI0033", "CLI0036"):
        assert por[cid].razon_social == orig[cid]["razon_social"]


def test_real_toda_la_pii_se_recupera_y_nada_queda_en_claro(real, datos_reales, cifrador):
    cl, _, _ = real
    orig = _originales(datos_reales)
    columnas = {"nit_cifrado": None, "email_contacto_cifrado": "email_contacto",
                "celular_contacto_cifrado": "celular_contacto", "direccion_cifrada": "direccion",
                "representante_legal_cifrado": "representante_legal"}
    for c in cl.clientes:
        o = orig[c.cliente_id]
        todo = b""
        for col, campo in columnas.items():
            blob = getattr(c, col)
            esperado = re.sub(r"\D", "", o["nit"]) if campo is None else o[campo].strip()
            assert cifrador.descifrar_texto(blob, f"core.dim_cliente.{col}|{c.cliente_id}") == esperado
            assert esperado.encode("utf-8") not in blob and esperado.encode("latin-1", "ignore") not in blob
            todo += blob
        assert c.nit_hash not in todo and len(c.nit_hash) == 32


def test_real_el_nit_en_4_formatos_da_40_indices_distintos(real):
    cl, _, _ = real
    assert len({c.nit_hash for c in cl.clientes}) == 40


def test_real_fronteras(real):
    cl, fr, _ = real
    assert fr.filas_leidas == 80 and len(fr.fronteras) == 40 and fr.rechazos == []
    assert all(f.max_kwh is not None and f.min_kwh <= f.max_kwh for f in fr.fronteras)


def test_real_facturacion_b6(real, datos_reales):
    _, fr, fa = real
    if fa is None:
        pytest.skip("no hay data/facturacion")
    assert (fa.facturas_leidas, len(fa.facturas), fa.fronteras_huerfanas) == (172, 160, 12)
    assert {x.clave_natural for x in fa.rechazos} == {f"F-2026{m:02d}-{9000 + i}" for m, i in
                                                      [(1, 1), (1, 2), (1, 3), (2, 4), (2, 5), (2, 6),
                                                       (3, 7), (3, 8), (3, 9), (4, 10), (4, 11), (4, 12)]}
    assert all(x.motivo == Z.M_FRONTERA_HUERFANA and x.payload_cifrado for x in fa.rechazos)


def test_real_el_nit_de_cada_factura_coincide_con_el_de_su_cliente(real):
    cl, fr, fa = real
    if fa is None:
        pytest.skip("no hay data/facturacion")
    cliente_de = {f.frontera_id: f.cliente_id for f in fr.fronteras}
    hash_de = {c.cliente_id: c.nit_hash for c in cl.clientes}
    assert all(f.cliente_nit_hash == hash_de[cliente_de[f.frontera_id]] for f in fa.facturas)
