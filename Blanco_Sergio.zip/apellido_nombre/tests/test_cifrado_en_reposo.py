"""C3 · Cifrado en reposo, verificado COMO LO HARIA QUIEN SE ROBA UN DUMP.

Se lee la tabla cruda con el superusuario (lo que ve un DBA o quien tiene un volcado)
y se busca, en claro y en hexadecimal, cada correo, celular, cedula, NIT, direccion y
representante del maestro original. No debe aparecer ninguno.

Tambien comprueba la idempotencia de los maestros (correr dos veces deja los mismos
BYTES, no solo los mismos conteos) y que las entradas hostiles no ejecutan nada (B7).

Las pruebas con transaccion cargan como el rol `ingesta` y se revierten al final: no
dejan rastro. La del volcado (pg_dump) lee lo que haya COMMITEADO, asi que es la que
cobra sentido despues de `make run`.
"""
import csv
import io
import os
import shutil
import subprocess
import uuid
from pathlib import Path

import psycopg2
import pytest

from _pii_utils import fugas, pii_original
from bia import facturacion, maestros, repositorio

if not os.environ.get("PG_SUPERUSER_PASSWORD"):
    pytest.skip("Base de datos no configurada (falta PG_SUPERUSER_PASSWORD)", allow_module_level=True)

TABLAS = ["core.dim_cliente", "core.dim_frontera", "core.fact_factura",
          "core.fact_factura_componente", "quarantine.rechazo"]
ORDEN = {"core.dim_cliente": "cliente_id", "core.dim_frontera": "frontera_id",
         "core.fact_factura": "factura_id", "core.fact_factura_componente": "factura_id, concepto",
         "quarantine.rechazo": "fuente, archivo, fila_origen, motivo"}


def _conexion():
    return psycopg2.connect(
        host=os.environ.get("PG_HOST", "localhost"), port=int(os.environ.get("PG_PORT", "5432")),
        dbname=os.environ.get("PG_DB", "bia_datos"), user=os.environ["PG_SUPERUSER"],
        password=os.environ["PG_SUPERUSER_PASSWORD"], connect_timeout=10)


# ---------------------------------------------------------------------------- carga de prueba
def _cargar(cur, datos_reales, cifrador, con_facturas=True):
    """Una corrida de maestros completa, como el rol ingesta (relee y recifra todo)."""
    cl = maestros.leer_clientes(datos_reales / "maestros" / "clientes.csv", cifrador)
    fr = maestros.leer_fronteras(datos_reales / "maestros" / "fronteras.csv",
                                 datos_reales / "maestros" / "limites_frontera.csv",
                                 {c.cliente_id for c in cl.clientes})
    rechazos = cl.rechazos + fr.rechazos
    facturas = []
    ruta = datos_reales / "facturacion"
    if con_facturas and ruta.is_dir():
        fa = facturacion.leer_facturacion(ruta, {f.frontera_id for f in fr.fronteras}, cifrador)
        facturas, rechazos = fa.facturas, rechazos + fa.rechazos
    cur.execute("SET ROLE ingesta")
    repositorio.upsert_clientes(cur, cl.clientes)
    repositorio.upsert_fronteras(cur, fr.fronteras)
    repositorio.upsert_facturas(cur, facturas)
    repositorio.registrar_rechazos(cur, rechazos, uuid.uuid4())
    cur.execute("RESET ROLE")
    return cl, fr, facturas, rechazos


@pytest.fixture
def cur(datos_reales):
    conn = _conexion()
    try:
        with conn.cursor() as c:
            yield c
    finally:
        conn.rollback()
        conn.close()


def _volcado(cur):
    partes = []
    for t in TABLAS:
        cur.execute(f"SELECT x::text FROM {t} x ORDER BY {ORDEN[t]}")
        partes.extend(fila[0] for fila in cur.fetchall())
    return "\n".join(partes)


def _estado(cur):
    """Huella de TODOS los bytes de las tablas (el cifrado aleatorio cambiaria esto si hubiera reescrituras)."""
    out = {}
    for t in TABLAS:
        cur.execute(f"SELECT md5(coalesce(string_agg(x::text, E'\\n' ORDER BY {ORDEN[t]}), '')), count(*) FROM {t} x")
        out[t] = cur.fetchone()
    return out


# ------------------------------------------------------------------------------- las pruebas
def test_la_tabla_cruda_como_superusuario_no_contiene_pii_en_claro(cur, datos_reales, cifrador):
    _cargar(cur, datos_reales, cifrador)
    volcado = _volcado(cur)
    secretos = pii_original(datos_reales)
    assert len(secretos) > 100                                   # hay PII real que buscar
    assert fugas(volcado, secretos) == []


def test_el_detector_de_fugas_si_detecta(cur, datos_reales, cifrador):
    """Control de la prueba anterior: si la PII estuviera en claro, esta busqueda la veria."""
    _cargar(cur, datos_reales, cifrador)
    cur.execute("SELECT razon_social FROM core.dim_cliente WHERE cliente_id = 'CLI0001'")
    razon = cur.fetchone()[0]                                    # NO es PII: esta en claro a proposito
    assert fugas(_volcado(cur), [razon]) == [razon]
    cur.execute("SELECT encode(nit_cifrado, 'hex') FROM core.dim_cliente WHERE cliente_id = 'CLI0001'")
    assert fugas("\\x" + cur.fetchone()[0], ["900123456-7"]) == []   # y un cifrado no coincide con nada


def test_las_columnas_pii_son_bytes_opacos_y_con_el_formato_esperado(cur, datos_reales, cifrador):
    _cargar(cur, datos_reales, cifrador)
    cur.execute("""SELECT min(octet_length(nit_cifrado)), min(get_byte(nit_cifrado, 0)),
                          bool_and(octet_length(nit_hash) = 32)
                   FROM core.dim_cliente""")
    largo_min, version, hash_ok = cur.fetchone()
    assert largo_min >= 29 and version == cifrador.version_actual and hash_ok


def test_correr_los_maestros_dos_veces_deja_exactamente_los_mismos_bytes(cur, datos_reales, cifrador):
    _cargar(cur, datos_reales, cifrador)
    primera = _estado(cur)
    _cargar(cur, datos_reales, cifrador)                         # relee y RECIFRA todo (nonces nuevos)
    assert _estado(cur) == primera
    assert primera["core.dim_cliente"][1] >= 40


def test_un_cliente_que_cambia_se_actualiza_y_solo_ese(cur, datos_reales, cifrador, tmp_path):
    """La huella evita reescrituras inutiles, pero un cambio real SI debe llegar a la base."""
    _cargar(cur, datos_reales, cifrador)
    cur.execute("SELECT cliente_id, huella_contenido FROM core.dim_cliente ORDER BY cliente_id")
    antes = {cid: bytes(h) for cid, h in cur.fetchall()}

    texto = (datos_reales / "maestros" / "clientes.csv").read_bytes().decode("latin-1")
    filas = list(csv.reader(io.StringIO(texto, newline="")))
    cabecera = filas[0]
    for fila in filas[1:]:
        if fila[cabecera.index("cliente_id")] == "CLI0001":
            fila[cabecera.index("direccion")] = "Direccion NUEVA 123"
    buf = io.StringIO(newline="")
    csv.writer(buf, lineterminator="\r\n").writerows(filas)
    cambiado = tmp_path / "clientes.csv"
    cambiado.write_bytes(buf.getvalue().encode("latin-1"))

    nuevo = maestros.leer_clientes(cambiado, cifrador)
    cur.execute("SET ROLE ingesta")
    repositorio.upsert_clientes(cur, nuevo.clientes)
    cur.execute("RESET ROLE")

    cur.execute("SELECT cliente_id, huella_contenido FROM core.dim_cliente ORDER BY cliente_id")
    despues = {cid: bytes(h) for cid, h in cur.fetchall()}
    cambiados = [cid for cid in antes if antes[cid] != despues[cid]]
    assert cambiados == ["CLI0001"]
    cur.execute("SELECT direccion_cifrada FROM core.dim_cliente WHERE cliente_id = 'CLI0001'")
    blob = bytes(cur.fetchone()[0])
    assert cifrador.descifrar_texto(blob, "core.dim_cliente.direccion_cifrada|CLI0001") == "Direccion NUEVA 123"


def test_las_entradas_hostiles_no_se_ejecutan(cur, datos_reales, cifrador):
    """Eliminatoria 3: ni la tabla de consumos desaparece ni se vacia."""
    cur.execute("SELECT count(*) FROM core.fact_consumo_horario")
    antes = cur.fetchone()[0]
    _cargar(cur, datos_reales, cifrador)
    cur.execute("SELECT to_regclass('core.fact_consumo_horario') IS NOT NULL")
    assert cur.fetchone()[0] is True
    cur.execute("SELECT count(*) FROM core.fact_consumo_horario")
    assert cur.fetchone()[0] == antes
    cur.execute("SELECT razon_social FROM core.dim_cliente WHERE cliente_id = 'CLI0036'")
    assert "DROP TABLE" in cur.fetchone()[0]                     # esta guardado como TEXTO
    cur.execute("SELECT length(razon_social) FROM core.dim_cliente WHERE cliente_id = 'CLI0033'")
    assert cur.fetchone()[0] == 1632


def test_la_cuarentena_de_facturas_huerfanas(cur, datos_reales, cifrador):
    if not (datos_reales / "facturacion").is_dir():
        pytest.skip("no hay data/facturacion")
    _cargar(cur, datos_reales, cifrador)
    cur.execute("""SELECT count(*), bool_and(payload_cifrado IS NOT NULL), bool_and(detalle IS NULL)
                   FROM quarantine.rechazo WHERE fuente = 'facturacion' AND motivo = 'FRONTERA_HUERFANA'""")
    n, con_payload, sin_detalle = cur.fetchone()
    assert (n, con_payload, sin_detalle) == (12, True, True)
    _cargar(cur, datos_reales, cifrador)                         # otra corrida no duplica la cuarentena
    cur.execute("SELECT count(*) FROM quarantine.rechazo WHERE fuente = 'facturacion' AND motivo = 'FRONTERA_HUERFANA'")
    assert cur.fetchone()[0] == 12


@pytest.mark.skipif(shutil.which("pg_dump") is None, reason="pg_dump no esta instalado")
def test_un_pg_dump_de_lo_commiteado_no_contiene_pii_en_claro(datos_reales):
    """El robo de un volcado, literal. Lee lo ya commiteado: tiene sentido tras `make run`."""
    env = dict(os.environ, PGPASSWORD=os.environ["PG_SUPERUSER_PASSWORD"])
    p = subprocess.run(
        ["pg_dump", "-h", os.environ.get("PG_HOST", "localhost"), "-p", os.environ.get("PG_PORT", "5432"),
         "-U", os.environ["PG_SUPERUSER"], "-d", os.environ.get("PG_DB", "bia_datos"), "--no-owner"],
        capture_output=True, text=True, env=env, timeout=120)
    assert p.returncode == 0, p.stderr[:300]
    assert fugas(p.stdout, pii_original(datos_reales)) == []
