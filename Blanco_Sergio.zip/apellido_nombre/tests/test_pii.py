"""Deteccion y enmascarado de PII en texto libre (C2)."""
import random

import pytest

from bia import pii


@pytest.mark.parametrize("texto,esperado,tipos", [
    ("Enviar factura a juan.perez@empresa.com.co", "Enviar factura a [EMAIL]", ("email",)),
    ("Contacto alterno: a+b@x-y.org tel 3001234567", "Contacto alterno: [EMAIL] tel [CELULAR]", ("email", "celular")),
    ("Cel. de la planta: 3109876543", "Cel. de la planta: [CELULAR]", ("celular",)),
    ("Autorizo debito. CC 80123456 del rep legal.", "Autorizo debito. CC [CEDULA] del rep legal.", ("cedula",)),
    ("Sin novedades.", "Sin novedades.", ()),
])
def test_las_plantillas_reales(texto, esperado, tipos):
    r = pii.enmascarar(texto)
    assert (r.texto, r.tipos, r.tenia_pii) == (esperado, tipos, bool(tipos))


@pytest.mark.parametrize("celular", [
    "3001234567", "300 123 4567", "300-123-4567", "300.123.4567", "+57 300 123 4567",
    "573001234567", "+573001234567",
])
def test_formatos_de_celular(celular):
    r = pii.enmascarar(f"llamar al {celular} hoy")
    assert r.texto == "llamar al [CELULAR] hoy", celular


@pytest.mark.parametrize("cedula", ["80123456", "1020304050", "12.345.678", "1.020.304.050", "123456",
                                    "154.274"])        # 6 digitos con un solo punto: fuga hallada por el test aleatorio
def test_formatos_de_cedula(cedula):
    assert pii.enmascarar(f"CC {cedula}").texto == "CC [CEDULA]", cedula


@pytest.mark.parametrize("email", ["a@b.co", "nombre.apellido+filtro@sub.dominio.com.co", "ñandú@empresa.co",
                                   "x_y-z@a-b.c-d.org"])
def test_formatos_de_email(email):
    assert pii.enmascarar(f"escribir a {email}.").texto == "escribir a [EMAIL]."


def test_el_celular_no_se_confunde_con_cedula_y_viceversa():
    r = pii.enmascarar("cel 3001234567 y CC 1020304050")
    assert r.texto == "cel [CELULAR] y CC [CEDULA]" and r.tipos == ("celular", "cedula")


@pytest.mark.parametrize("texto", ["", "   ", None])
def test_vacio_o_none(texto):
    assert pii.enmascarar(texto) == pii.Enmascarado(None, ())


def test_un_numero_de_10_digitos_que_empieza_por_3_es_indistinguible_de_un_celular():
    """Se enmascara igual (no hay fuga); solo cambia la etiqueta. Documentado, no es un error."""
    assert pii.enmascarar("CC 3123456789") == pii.Enmascarado("CC [CELULAR]", ("celular",))


def test_no_toca_numeros_cortos_ni_texto_normal():
    t = "Contrato 2026, piso 12, 3 medidores, tension 13.2 kV, 13.200 V, 1.234 de factor, tel interno 4521"
    assert pii.enmascarar(t) == pii.Enmascarado(t, ())


def test_es_idempotente():
    una = pii.enmascarar("a@b.co 3001234567 CC 80123456")
    dos = pii.enmascarar(una.texto)
    assert dos.texto == una.texto and dos.tipos == ()


def test_contiene_pii():
    assert pii.contiene_pii("a@b.co") and pii.contiene_pii("CC 80123456")
    assert not pii.contiene_pii("[EMAIL] [CELULAR] [CEDULA]") and not pii.contiene_pii(None)


def test_sesgo_deliberado_a_enmascarar_ante_la_duda():
    """Un numero de contrato de 8 digitos se trata como cedula: un falso positivo es barato."""
    assert pii.enmascarar("contrato 20260101").tipos == ("cedula",)


# ---------- prueba aleatoria: ninguna PII incrustada sobrevive, sea cual sea el contexto
def _generar(rnd):
    email = f"{rnd.choice(['juan', 'ana.maria', 'x_y', 'c+d'])}{rnd.randint(0, 99)}@{rnd.choice(['bia', 'cliente-sa', 'mail'])}.{rnd.choice(['com', 'com.co', 'co'])}"
    d = "3" + "".join(rnd.choice("0123456789") for _ in range(9))
    cel = rnd.choice([d, f"{d[:3]} {d[3:6]} {d[6:]}", f"{d[:3]}-{d[3:6]}-{d[6:]}", f"+57 {d}"])
    n = "".join(rnd.choice("123456789") for _ in range(rnd.choice([6, 7, 8, 9, 10])))
    ced = rnd.choice([n, f"{int(n):,}".replace(",", ".")])
    return email, cel, ced


def test_ninguna_pii_sobrevive_en_textos_aleatorios():
    rnd = random.Random(2026)
    relleno = ["Revisar", "con", "el", "contacto", "de", "planta", "Autorizo", "debito", ":", "-", "(", ")", "ok"]
    for _ in range(500):
        email, cel, ced = _generar(rnd)
        piezas = rnd.sample(relleno, 4) + [email, cel, ced]
        rnd.shuffle(piezas)
        texto = " ".join(piezas)
        r = pii.enmascarar(texto)
        for secreto in (email, cel, ced):
            assert secreto not in r.texto, (texto, r.texto)
        assert not pii.contiene_pii(r.texto), r.texto
        assert {"email", "celular"} <= set(r.tipos)
        # una cedula de 10 digitos que empieza por 3 se etiqueta como celular (ver test dedicado)
        ambigua = ced.isdigit() and len(ced) == 10 and ced.startswith("3")
        assert "cedula" in r.tipos or ambigua, (ced, r.tipos)
