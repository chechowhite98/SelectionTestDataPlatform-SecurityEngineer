"""Logs estructurados (Parte E): una linea JSON por evento y SIN PII."""
import json
import re

import pytest

from bia import cripto, logs
from bia.config import ConfigError
from bia.logs import LogJson, nuevo_id_corrida
from bia.maestros import MaestroInvalido


@pytest.fixture
def log(tmp_path):
    lg = LogJson(tmp_path / "logs" / "pipeline.log", nuevo_id_corrida())
    yield lg
    lg.cerrar()


def _lineas(log):
    log._fh.flush()
    return [json.loads(x) for x in log.ruta.read_text(encoding="utf-8").splitlines()]


def test_cada_evento_es_una_linea_json_con_los_campos_basicos(log):
    log.evento("etapa_fin", etapa="calidad", duracion_s=1.234, filas=115340)
    log.evento("otro", ok=True, nada=None)
    lineas = _lineas(log)
    assert len(lineas) == 2
    assert {"ts", "nivel", "evento", "corrida_id"} <= set(lineas[0])
    assert lineas[0]["etapa"] == "calidad" and lineas[0]["filas"] == 115340
    assert re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z", lineas[0]["ts"])


def test_crea_el_directorio_y_agrega_sin_pisar(tmp_path):
    ruta = tmp_path / "a" / "b" / "pipeline.log"
    for i in range(2):
        lg = LogJson(ruta, nuevo_id_corrida())
        lg.evento("corrida", n=i)
        lg.cerrar()
    assert len(ruta.read_text().splitlines()) == 2


def test_los_numeros_grandes_no_se_confunden_con_pii(log):
    """115340 filas no es una cedula: los contadores quedan intactos y no se marca nada."""
    log.evento("fin", filas_leidas=115340, filas_cargadas=1234567890)
    r = _lineas(log)[0]
    assert r["filas_leidas"] == 115340 and r["filas_cargadas"] == 1234567890
    assert "pii_redactada" not in r and r["nivel"] == "INFO"


@pytest.mark.parametrize("texto,secreto", [
    ("contacto juan@empresa.com.co", "juan@empresa.com.co"),
    ("llamar 3001234567", "3001234567"),
    ("CC 80123456", "80123456"),
    ("+57 300 123 4567", "300 123 4567"),
])
def test_la_red_de_seguridad_enmascara_pii_que_se_cuele(log, texto, secreto):
    log.evento("algo", detalle=texto)
    r = _lineas(log)[0]
    assert secreto not in json.dumps(r)
    assert r["pii_redactada"] >= 1 and r["nivel"] == "WARNING"         # y avisa de que paso


def test_tambien_limpia_dentro_de_estructuras_anidadas(log):
    log.evento("x", a={"b": ["ok", "mail@x.co"], "c": ("3001234567",)})
    assert "mail@x.co" not in json.dumps(_lineas(log)[0]) and "3001234567" not in json.dumps(_lineas(log)[0])


def test_el_nombre_de_un_archivo_normal_no_se_toca(log):
    log.evento("archivo_leido", archivo="consumos_2026-04_correccion.csv")
    r = _lineas(log)[0]
    assert r["archivo"] == "consumos_2026-04_correccion.csv" and "pii_redactada" not in r


# ------------------------------------------------------------------ excepciones
class _ErrorBd(Exception):
    """Imita a psycopg2: lleva un SQLSTATE y un mensaje con el contenido de la fila."""
    pgcode = "23514"


def test_un_error_de_base_de_datos_no_registra_su_mensaje(log):
    exc = _ErrorBd('new row for relation "dim_cliente" violates check constraint DETAIL: '
                   'Failing row contains (CLI0001, Acme, juan.perez@acme.co, 3001234567)')
    log.error("corrida_error", exc)
    r = _lineas(log)[0]
    assert (r["error_tipo"], r["pgcode"], r["nivel"]) == ("_ErrorBd", "23514", "ERROR")
    assert "error_mensaje" not in r
    assert "acme" not in json.dumps(r).lower() and "3001234567" not in json.dumps(r)


def test_un_error_inesperado_tampoco_registra_su_mensaje(log):
    log.error("corrida_error", ValueError("dato secreto 80123456"))
    r = _lineas(log)[0]
    assert r["error_tipo"] == "ValueError" and "error_mensaje" not in r and "80123456" not in json.dumps(r)


@pytest.mark.parametrize("exc", [ConfigError("falta la variable INGESTA_PASSWORD"),
                                 MaestroInvalido("clientes.csv: vacio o binario"),
                                 cripto.ConfiguracionInvalida("BIA_ENC_KEYS: no es base64 valido")])
def test_los_errores_propios_conservan_su_mensaje_porque_son_seguros(log, exc):
    log.error("corrida_error", exc)
    assert _lineas(log)[0]["error_mensaje"] == str(exc)


def test_un_error_propio_que_trajera_pii_igual_se_enmascara(log):
    log.error("corrida_error", MaestroInvalido("fila rota de juan@x.co"))
    assert "juan@x.co" not in json.dumps(_lineas(log)[0])


# ---------------------------------------------------------------- id de corrida
def test_el_id_de_corrida_es_un_uuid_y_nunca_parece_pii():
    for _ in range(300):
        i = nuevo_id_corrida()
        assert re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", i)
        assert not logs.pii.contiene_pii(i)
