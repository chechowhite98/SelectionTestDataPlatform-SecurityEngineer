"""Parte D. La logica es pura (Detector), asi que se prueba sin broker; la capa de Kafka se
prueba con un broker falso que reproduce lo que importa: topico vacio, relectura, fin del stream."""
import json
from datetime import timedelta
from decimal import Decimal

import pytest

from bia import streaming
from bia.streaming import (CONSUMO_FUERA_DE_BANDA, FRONTERA_SIN_REPORTE, INICIO_DIA, INTERVALO,
                           LECTURA_RETROACTIVA, Detector)

F = "CO0000000001"


def ev(slot, kwh=1.0, eid=None, frontera=F):
    ts = (INICIO_DIA + slot * INTERVALO).isoformat()
    return {"evento_id": eid or f"E{frontera}{slot}-{kwh}", "frontera_id": frontera, "ts_medicion": ts,
            "kwh": kwh, "medidor": {"serial": "X", "firmware": "1"}}


def correr(eventos, limite="100.0", frontera=F):
    d = Detector({frontera: Decimal(limite)})
    for e in eventos:
        d.procesar_crudo(e)
    d.cerrar()
    return d


def tipos(d, solo=None):
    return sorted((a["tipo"], a["ts"]) for a in d.alertas() if solo in (None, a["tipo"]))


def hora(slot):
    return (INICIO_DIA + slot * INTERVALO).isoformat()


# ---------------------------------------------------------------- dataset real
def test_dataset_real_da_las_cifras_esperadas(datos_reales):
    d = Detector(streaming.cargar_limites(datos_reales / "maestros" / "limites_frontera.csv"))
    for crudo in streaming.leer_ndjson(datos_reales / "eventos" / "mediciones_stream.ndjson"):
        d.procesar_crudo(crudo)
    d.cerrar()
    assert d.conteo() == {CONSUMO_FUERA_DE_BANDA: 22, FRONTERA_SIN_REPORTE: 6, LECTURA_RETROACTIVA: 5}
    assert d.leidos == 3795 and d.duplicados == 0 and not d.invalidos
    claves = [(a["tipo"], a["frontera_id"], a["ts"]) for a in d.alertas()]
    assert len(claves) == len(set(claves))                        # sin duplicados


# ---------------------------------------------------------------- banda
def test_banda_es_estrictamente_mayor():
    B = CONSUMO_FUERA_DE_BANDA
    assert tipos(correr([ev(0, 100.0)]), B) == []                   # igual al maximo: NO
    assert tipos(correr([ev(0, 100.001)]), B) == [(B, hora(0))]
    assert tipos(correr([ev(0, 0.1 + 0.2)], limite="0.3"), B) == [(B, hora(0))]   # 0.30000000000000004 > 0.3


def test_frontera_sin_limite_no_alerta_pero_se_cuenta():
    d = correr([ev(0, 9e9, frontera="CO9")], frontera="CO1")
    assert tipos(d, CONSUMO_FUERA_DE_BANDA) == [] and d.sin_limite == {"CO9"}


# ---------------------------------------------------------------- retroactiva
def test_retroactiva_solo_si_es_estrictamente_anterior():
    d = correr([ev(5), ev(6), ev(5, eid="otro")])                  # llega la del slot 5 tras la del 6
    assert (LECTURA_RETROACTIVA, hora(5)) in tipos(d)
    R = LECTURA_RETROACTIVA
    assert tipos(correr([ev(5), ev(5, eid="otro")]), R) == []       # mismo ts: no es anterior
    assert tipos(correr([ev(s) for s in range(1, 96)] + [ev(0)]), R) == [(R, hora(0))]


def test_retroactiva_se_mide_contra_la_ultima_mas_reciente_no_la_ultima_en_llegar():
    d = correr([ev(10), ev(4), ev(6)])                              # la del 6 sigue siendo anterior al 10
    assert sorted(a["ts"] for a in d.alertas() if a["tipo"] == LECTURA_RETROACTIVA) == [hora(4), hora(6)]


# ---------------------------------------------------------------- caidas
def todos(menos):
    return [ev(s) for s in range(96) if s not in menos]


def test_dos_intervalos_ausentes_no_alertan_tres_si_en_el_tercero():
    assert tipos(correr(todos({10, 11}))) == []
    assert tipos(correr(todos({10, 11, 12}))) == [(FRONTERA_SIN_REPORTE, hora(12))]


def test_una_caida_larga_es_una_sola_alerta_en_el_tercer_intervalo():
    assert tipos(correr(todos(set(range(20, 30))))) == [(FRONTERA_SIN_REPORTE, hora(22))]


def test_dos_caidas_separadas_son_dos_alertas():
    assert tipos(correr(todos({10, 11, 12, 40, 41, 42, 43}))) == [(FRONTERA_SIN_REPORTE, hora(12)),
                                                                  (FRONTERA_SIN_REPORTE, hora(42))]


def test_la_frontera_que_calla_hasta_el_final_del_dia_alerta_al_cerrar():
    d = correr([ev(s) for s in range(90)])                          # faltan 90..95
    assert tipos(d) == [(FRONTERA_SIN_REPORTE, hora(92))]
    assert tipos(correr([ev(s) for s in range(94)])) == []          # faltan solo 2


def test_una_lectura_tardia_no_inventa_ni_borra_caidas():
    d = correr(todos({10, 11, 12}) + [ev(11, eid="tardia")])
    assert (FRONTERA_SIN_REPORTE, hora(12)) in tipos(d)
    assert (LECTURA_RETROACTIVA, hora(11)) in tipos(d)


# ---------------------------------------------------------------- robustez
def test_eventos_defectuosos_se_cuentan_y_no_tumban_nada():
    malos = [None, "texto", 5, {}, {"evento_id": "a", "frontera_id": F, "ts_medicion": "ayer", "kwh": 1},
             {"evento_id": "b", "frontera_id": F, "ts_medicion": "2026-06-01T00:00:00", "kwh": 1},   # sin zona
             {"evento_id": "c", "frontera_id": F, "ts_medicion": hora(0), "kwh": "9"},
             {"evento_id": "d", "frontera_id": F, "ts_medicion": hora(0), "kwh": float("nan")},
             {"evento_id": "e", "frontera_id": F, "ts_medicion": hora(0), "kwh": True}]
    d = correr(malos + [ev(0)])
    assert sum(d.invalidos.values()) == len(malos) and d.leidos == len(malos) + 1


def test_el_mismo_evento_publicado_dos_veces_no_cambia_el_resultado():
    base = todos({10, 11, 12}) + [ev(3, 500.0, eid="x")]
    assert correr(base + base).alertas() == correr(base).alertas()
    assert correr(base + base).duplicados == len(base)


def test_zona_horaria_distinta_se_normaliza_a_bogota():
    e = ev(0, 500.0)
    e["ts_medicion"] = "2026-06-01T05:00:00+00:00"                  # = 00:00 -05:00
    assert tipos(correr([e]), CONSUMO_FUERA_DE_BANDA) == [(CONSUMO_FUERA_DE_BANDA, hora(0))]


# ---------------------------------------------------------------- capa Kafka (broker falso)
class Mensaje:
    def __init__(self, v):
        self.value = v


class BrokerFalso:
    def __init__(self, inicial=()):
        self.mensajes = [json.dumps(m).encode() if not isinstance(m, bytes) else m for m in inicial]
        self.publicados = 0


@pytest.fixture
def kafka_falso(monkeypatch):
    import kafka
    broker = BrokerFalso()

    class Consumidor:
        def __init__(self, **kw):
            self.pos = 0
            self.cerrado = False

        def partitions_for_topic(self, t):
            return {0}

        def assign(self, tps):
            pass

        def seek_to_beginning(self, *tps):
            self.pos = 0

        def end_offsets(self, tps):
            return {tp: len(broker.mensajes) for tp in tps}

        def position(self, tp):
            return self.pos

        def poll(self, timeout_ms=0):
            if self.pos < len(broker.mensajes):
                lote = [Mensaje(m) for m in broker.mensajes[self.pos:self.pos + 500]]
                self.pos += len(lote)
                return {"tp": lote}
            return {}

        def close(self):
            self.cerrado = True

    class Productor:
        def __init__(self, **kw):
            pass

        def send(self, topic, key, value):
            broker.mensajes.append(json.dumps(value).encode())
            broker.publicados += 1

        def flush(self, timeout=None):
            pass

        def close(self):
            pass

    monkeypatch.setattr(kafka, "KafkaConsumer", Consumidor)
    monkeypatch.setattr(kafka, "KafkaProducer", Productor)
    return broker


def test_topico_vacio_se_publica_y_se_consume_y_termina_solo(kafka_falso, datos_reales):
    ndjson = datos_reales / "eventos" / "mediciones_stream.ndjson"
    d = Detector(streaming.cargar_limites(datos_reales / "maestros" / "limites_frontera.csv"))
    for crudo in streaming.leer_kafka("x:1", "t", archivo_para_publicar=ndjson, ocioso_s=0.2, maximo_s=30):
        d.procesar_crudo(crudo)
    d.cerrar()
    assert kafka_falso.publicados == 3795
    assert d.conteo() == {CONSUMO_FUERA_DE_BANDA: 22, FRONTERA_SIN_REPORTE: 6, LECTURA_RETROACTIVA: 5}


def test_si_el_topico_ya_tiene_datos_no_se_vuelve_a_publicar(kafka_falso, datos_reales):
    kafka_falso.mensajes.append(json.dumps(ev(0)).encode())
    list(streaming.leer_kafka("x:1", "t", archivo_para_publicar=datos_reales / "eventos" / "mediciones_stream.ndjson",
                              ocioso_s=0.1, maximo_s=30))
    assert kafka_falso.publicados == 0


def test_un_mensaje_que_no_es_json_se_entrega_como_none(kafka_falso):
    kafka_falso.mensajes += [b"\xff\xfe basura", json.dumps(ev(0)).encode()]
    salida = list(streaming.leer_kafka("x:1", "t", ocioso_s=0.1, maximo_s=30))
    assert salida[0] is None and salida[1]["frontera_id"] == F


def test_tope_duro_de_tiempo_corta_un_stream_que_nunca_termina(kafka_falso, monkeypatch):
    import kafka
    base = kafka.KafkaConsumer

    class Infinito(base):
        def poll(self, timeout_ms=0):
            return {"tp": [Mensaje(json.dumps(ev(0)).encode())]}
    monkeypatch.setattr(kafka, "KafkaConsumer", Infinito)
    import time
    t = time.monotonic()
    n = sum(1 for _ in streaming.leer_kafka("x:1", "t", ocioso_s=0.1, maximo_s=0.5))
    assert time.monotonic() - t < 3 and n > 0


def test_ejecutar_escribe_alertas_json_y_log_sin_datos_de_eventos(kafka_falso, datos_reales, tmp_path):
    env = {"BIA_DATA_DIR": str(datos_reales), "BIA_OUT_DIR": str(tmp_path / "out"),
           "BIA_LOGS_DIR": str(tmp_path / "logs"), "KAFKA_BOOTSTRAP": "x:1"}
    import bia.streaming as s
    orig = s.leer_kafka
    s.leer_kafka = lambda *a, **k: orig(*a, **{**k, "ocioso_s": 0.1, "maximo_s": 30})
    try:
        assert s.ejecutar(env) == 0
    finally:
        s.leer_kafka = orig
    alertas = json.loads((tmp_path / "out" / "alertas.json").read_text())
    assert len(alertas) == 33 and all(set(a) == {"tipo", "frontera_id", "ts"} for a in alertas)
    log = (tmp_path / "logs" / "pipeline.log").read_text()
    assert "stream_fin" in log and "EV0000000" not in log and "MDA3AA30" not in log


def test_si_el_broker_no_existe_falla_con_codigo_1_y_sin_mensaje_del_error(tmp_path, datos_reales, monkeypatch):
    import kafka
    from kafka.errors import NoBrokersAvailable

    def boom(**kw):
        raise NoBrokersAvailable()
    monkeypatch.setattr(kafka, "KafkaConsumer", boom)
    monkeypatch.setattr(streaming, "_bootstrap_listo", lambda b, e: boom())
    env = {"BIA_DATA_DIR": str(datos_reales), "BIA_OUT_DIR": str(tmp_path / "o"), "BIA_LOGS_DIR": str(tmp_path / "l")}
    assert streaming.ejecutar(env) == 1
    assert "NoBrokersAvailable" in (tmp_path / "l" / "pipeline.log").read_text()
