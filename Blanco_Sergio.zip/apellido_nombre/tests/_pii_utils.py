"""Utilidades de prueba: la PII original del paquete y un buscador de fugas.

Se usa para comprobar que NINGUN artefacto (tablas, volcados, logs, out/) contiene
un correo, celular, cedula, NIT, direccion o representante tal como vienen en los
archivos fuente. Se busca en claro y en hexadecimal (asi se ve un bytea en un volcado).
"""
import csv
import io
import json

from bia import pii


def pii_original(datos_reales):
    """Todo texto personal del maestro y de la facturacion, tal como viene en los archivos."""
    secretos = set()
    texto = (datos_reales / "maestros" / "clientes.csv").read_bytes().decode("latin-1")
    for r in csv.DictReader(io.StringIO(texto, newline="")):
        for campo in ("nit", "email_contacto", "celular_contacto", "direccion", "representante_legal"):
            secretos.add(r[campo].strip())
        secretos.add("".join(ch for ch in r["nit"] if ch.isdigit()))
        for patron in (pii.EMAIL, pii.CELULAR, pii.CEDULA):          # lo incrustado en observaciones
            secretos.update(m.group(0) for m in patron.finditer(r["observaciones"]))
    ruta = datos_reales / "facturacion"
    if ruta.is_dir():
        for f in sorted(ruta.glob("*.json")):
            for fac in json.loads(f.read_text(encoding="utf-8"))["facturas"]:
                secretos.add(fac["cliente"]["email_facturacion"])
                secretos.add(fac["cliente"]["nit"])
    return sorted(s for s in secretos if len(s) >= 6)


def fugas(volcado: str, secretos):
    """Secretos presentes en el texto, buscados en claro y en hexadecimal (bytea)."""
    bajo = volcado.lower()
    halladas = []
    for s in secretos:
        variantes = {s.lower(), s.encode("utf-8").hex(), s.encode("latin-1", "ignore").hex()}
        if any(v and v in bajo for v in variantes):
            halladas.append(s)
    return halladas
