"""Configuracion: fallo rapido, sin secretos en mensajes ni en repr (C6)."""
from pathlib import Path

import pytest

from bia import cripto
from bia.config import ROL_PIPELINE, ConfigError, cargar_config, leer_dotenv


def _env(**extra):
    env = {"INGESTA_PASSWORD": "una-clave-larga-123", "BIA_ENC_KEYS": f"1:{cripto.generar_llave()}",
           "BIA_INDEX_KEY": cripto.generar_llave()}
    env.update(extra)
    return env


def test_valores_por_defecto():
    c = cargar_config(_env())
    assert (c.pg_host, c.pg_port, c.pg_db) == ("localhost", 5432, "bia_datos")
    assert (c.data_dir, c.out_dir, c.logs_dir) == (Path("data"), Path("out"), Path("logs"))
    assert c.fallar_si_parcial is False


def test_el_pipeline_siempre_usa_el_rol_ingesta_y_no_se_puede_cambiar():
    assert cargar_config(_env()).pg_usuario == ROL_PIPELINE == "ingesta"
    # ni PG_USER ni PG_SUPERUSER en el entorno lo desvian: el superusuario no es para el pipeline
    c = cargar_config(_env(PG_USER="postgres", PG_SUPERUSER="postgres", POSTGRES_USER="postgres"))
    assert c.pg_usuario == "ingesta"


@pytest.mark.parametrize("quitar,fragmento", [
    ("INGESTA_PASSWORD", "INGESTA_PASSWORD"),
    ("BIA_ENC_KEYS", "BIA_ENC_KEYS"),
    ("BIA_INDEX_KEY", "BIA_INDEX_KEY"),
])
def test_falta_una_variable_obligatoria(quitar, fragmento):
    env = _env()
    del env[quitar]
    with pytest.raises(ConfigError, match=fragmento):
        cargar_config(env)


@pytest.mark.parametrize("puerto", ["abc", "0", "70000", "-1", ""])
def test_puerto_invalido(puerto):
    if puerto == "":
        assert cargar_config(_env(PG_PORT=puerto)).pg_port == 5432      # vacio = por defecto
    else:
        with pytest.raises(ConfigError, match="PG_PORT"):
            cargar_config(_env(PG_PORT=puerto))


def test_llave_invalida_se_reporta_como_error_de_configuracion_sin_el_valor():
    malo = "Y2xhdmVfY29ydGFfZGVfcHJ1ZWJh"             # la 'llave' corta de juguete (20 bytes)
    with pytest.raises(ConfigError) as e:
        cargar_config(_env(BIA_ENC_KEYS=f"1:{malo}"))
    assert malo not in str(e.value)


def test_repr_no_filtra_la_contrasena_ni_las_llaves():
    env = _env(INGESTA_PASSWORD="contrasena-super-secreta")
    texto = repr(cargar_config(env)) + str(cargar_config(env))
    assert "contrasena-super-secreta" not in texto
    assert env["BIA_ENC_KEYS"].split(":")[1] not in texto and env["BIA_INDEX_KEY"] not in texto


@pytest.mark.parametrize("valor,esperado", [("1", True), ("true", True), ("SI", True), ("0", False), ("", False)])
def test_modo_estricto(valor, esperado):
    assert cargar_config(_env(BIA_FALLAR_SI_PARCIAL=valor)).fallar_si_parcial is esperado


# ------------------------------------------------------------------------- .env
def test_leer_dotenv(tmp_path):
    ruta = tmp_path / ".env"
    ruta.write_text('# comentario\n\nA=1\nB = dos \nC="con espacios"\nD=\'x\'\nsin_igual\nE=a=b\n')
    assert leer_dotenv(ruta) == {"A": "1", "B": "dos", "C": "con espacios", "D": "x", "E": "a=b"}


def test_dotenv_inexistente(tmp_path):
    assert leer_dotenv(tmp_path / "no-existe") == {}


def test_el_entorno_real_gana_al_dotenv(tmp_path, monkeypatch):
    llaves = _env()
    (tmp_path / ".env").write_text("\n".join(f"{k}={v}" for k, v in llaves.items()) + "\nPG_HOST=desde-dotenv\nPG_DB=desde-dotenv\n")
    monkeypatch.setenv("PG_HOST", "desde-entorno")
    monkeypatch.delenv("PG_DB", raising=False)
    for k in llaves:
        monkeypatch.delenv(k, raising=False)
    c = cargar_config(dotenv=tmp_path / ".env")
    assert (c.pg_host, c.pg_db) == ("desde-entorno", "desde-dotenv")
