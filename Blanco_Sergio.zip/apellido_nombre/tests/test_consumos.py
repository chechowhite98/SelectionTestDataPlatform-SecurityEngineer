"""Lector de consumos: deteccion de formato, parseo de campos y archivos rotos."""
from decimal import Decimal

import pytest

import _fabrica as fb
from bia import calidad, consumos
from bia import reglas as R


def _leer(tmp_path, nombre, datos):
    return consumos.leer_archivo(fb.escribir(tmp_path, nombre, datos))


def _huella(arch):
    """(frontera, instante UTC, valor kWh): lo que debe ser igual venga en el formato que venga."""
    return sorted((x.frontera_id, x.ts_utc, x.valor_kwh) for x in arch.lecturas)


# ---------------------------------------------------------------- parseo de campos
@pytest.mark.parametrize("texto,esperado", [
    ("163.795", Decimal("163.795")),
    ("163,795", Decimal("163.795")),        # coma decimal (febrero)
    ("1.234,56", Decimal("1234.56")),       # miles con punto, decimal con coma
    ("1,234.56", Decimal("1234.56")),
    (" 5 ", Decimal("5")),
    ("1e3", Decimal("1000")),
    ("", None), ("NaN", None), ("null", None), ("N/A", None), ("--", None),
])
def test_parsear_valor_acepta(texto, esperado):
    assert consumos._parsear_valor(texto) == (True, esperado)


@pytest.mark.parametrize("texto", ["abc", "1,2,3", "12abc", "--5", "inf", "0x10"])
def test_parsear_valor_rechaza_lo_que_no_es_numero(texto):
    assert consumos._parsear_valor(texto)[0] is False


@pytest.mark.parametrize("texto,tz,esperado_utc_hora", [
    ("2026-05-01 00:00:00", "LOCAL", 5),            # local -> +5 h
    ("2026-05-01T05:00:00Z", "LOCAL", 5),           # Z gana a la pista
    ("2026-05-01T00:00:00-05:00", "UTC", 5),        # el offset explicito gana
    ("2026-05-01T05:00:00+00:00", "LOCAL", 5),
    ("2026-05-01 05:00:00", "UTC", 5),              # naive en columna *_utc
    ("2026-05-01T00:00-0500", "LOCAL", 5),
])
def test_parsear_timestamp_normaliza_a_utc(texto, tz, esperado_utc_hora):
    ts = consumos._parsear_timestamp(texto, tz)
    assert (ts.year, ts.month, ts.day, ts.hour) == (2026, 5, 1, esperado_utc_hora)


@pytest.mark.parametrize("texto", ["", "ayer", "2026-13-01 00:00:00", "2026-05-01", "2026-05-01 00:00:00.5"])
def test_parsear_timestamp_rechaza(texto):
    assert consumos._parsear_timestamp(texto, "LOCAL") is None


# --------------------------------------- un mes NUEVO en cada formato conocido
@pytest.mark.parametrize("construir", [fb.formato_local, fb.formato_utc, fb.formato_mwh])
def test_mes_nuevo_en_cada_formato_da_exactamente_lo_mismo(tmp_path, construir):
    valores = fb.valores_basicos(2026, 5)
    a = _leer(tmp_path, "consumos_2026-05.csv", construir(2026, 5, valores))
    assert a.estado == "OK" and not a.rechazadas
    referencia = _leer(tmp_path, "ref_2026-05.csv", fb.formato_local(2026, 5, valores))
    assert _huella(a) == _huella(referencia)


def test_el_formato_detectado_es_el_correcto(tmp_path):
    utc = _leer(tmp_path, "consumos_2026-05.csv", fb.formato_utc(2026, 5, fb.valores_basicos(2026, 5)))
    assert (utc.formato.delimitador, utc.formato.tz_naive) == (";", "UTC")
    mwh = _leer(tmp_path, "consumos_2026-06.csv", fb.formato_mwh(2026, 6, fb.valores_basicos(2026, 6)))
    assert mwh.formato.tiene_columna_unidad and mwh.convertidas_a_kwh == len(mwh.lecturas)
    assert {x.unidad_origen for x in mwh.lecturas} == {"MWh"}


@pytest.mark.parametrize("variante", [
    dict(bom=True),                      # BOM de Excel
    dict(eol="\n"),                      # LF en vez de CRLF
    dict(final=False),                   # sin salto de linea final (pero fila completa)
    dict(bom=True, eol="\n", final=False),
])
def test_variantes_de_formato_de_archivo_no_cambian_el_resultado(tmp_path, variante):
    valores = fb.valores_basicos(2026, 5)
    a = _leer(tmp_path, "consumos_2026-05.csv", fb.formato_local(2026, 5, valores, **variante))
    assert a.estado == "OK", a.motivo_rechazo
    assert len(a.lecturas) == len(valores)


def test_encoding_latin1_en_un_campo_de_texto(tmp_path):
    filas = [(f, fb.ts_local(h), v, 1, "ÓPTIMA") for (f, h, v) in fb.valores_basicos(2026, 5)]
    datos = fb.contenido(["frontera_id", "timestamp", "consumo_kwh", "version_lectura", "calidad_lectura"],
                         filas, encoding="latin-1")
    a = _leer(tmp_path, "consumos_2026-05.csv", datos)
    assert a.estado == "OK" and a.formato.encoding == "cp1252"
    assert a.lecturas[0].calidad_lectura == "ÓPTIMA"


def test_encabezados_con_otro_orden_mayusculas_y_tildes(tmp_path):
    filas = [(fb.ts_local(h), v, f) for (f, h, v) in fb.valores_basicos(2026, 5)]
    datos = fb.contenido(["Fecha Hora", "Consumo kWh", "Frontera ID"], filas, delim=";")
    a = _leer(tmp_path, "consumos_2026-05.csv", datos)
    assert a.estado == "OK" and len(a.lecturas) == len(filas)


# ----------------------------------------------------------------- archivos rotos
def test_archivo_truncado_a_mitad_de_fila_se_rechaza_entero(tmp_path):
    datos = fb.formato_local(2026, 5, fb.valores_basicos(2026, 5, n=24))
    corto = datos[: len(datos) - 14]                  # cortado dentro de la ultima fila
    a = _leer(tmp_path, "consumos_2026-05.csv", corto)
    assert a.estado == "RECHAZADO" and a.motivo_rechazo == R.M_ARCHIVO_TRUNCADO
    assert a.lecturas == []                           # no aporta NADA


def test_ultima_fila_completa_sin_salto_final_no_es_truncamiento(tmp_path):
    a = _leer(tmp_path, "consumos_2026-05.csv",
              fb.formato_local(2026, 5, fb.valores_basicos(2026, 5), final=False))
    assert a.estado == "OK"


def test_contenido_binario_se_rechaza(tmp_path):
    a = _leer(tmp_path, "consumos_2026-05.csv", b"frontera_id,timestamp,consumo_kwh\r\n\x00\x01\x02\xff" * 10)
    assert (a.estado, a.motivo_rechazo) == ("RECHAZADO", R.M_CONTENIDO_BINARIO)


def test_encabezado_desconocido_se_rechaza(tmp_path):
    datos = fb.contenido(["a", "b", "c"], [(1, 2, 3)] * 50)
    a = _leer(tmp_path, "consumos_2026-05.csv", datos)
    assert (a.estado, a.motivo_rechazo) == ("RECHAZADO", R.M_ENCABEZADO_NO_RECONOCIDO)


def test_archivo_vacio_se_rechaza(tmp_path):
    assert _leer(tmp_path, "consumos_2026-05.csv", b"  \r\n").motivo_rechazo == R.M_ARCHIVO_VACIO


def test_solo_encabezado_se_rechaza(tmp_path):
    datos = fb.formato_local(2026, 5, [])
    assert _leer(tmp_path, "consumos_2026-05.csv", datos).motivo_rechazo == R.M_SIN_FILAS_VALIDAS


def test_campo_gigante_no_tumba_el_pipeline(tmp_path):
    datos = fb.formato_local(2026, 5, fb.valores_basicos(2026, 5)) + b"CO0000000001,2026-05-02 00:00:00," + b"9" * 300_000 + b",1,OK\r\n"
    a = _leer(tmp_path, "consumos_2026-05.csv", datos)
    assert a.estado == "RECHAZADO" and a.motivo_rechazo == R.M_CSV_MALFORMADO


def test_filas_malas_aisladas_van_a_cuarentena_sin_rechazar_el_archivo(tmp_path):
    valores = fb.valores_basicos(2026, 5, n=72)               # 144 filas buenas
    filas = [(f, fb.ts_local(h), v, 1, "OK") for (f, h, v) in valores]
    filas.insert(10, (fb.F1, fb.ts_local(fb.horas(2026, 5, 1)[0]), "abc", 1, "OK"))   # valor
    filas.insert(50, (fb.F1, "no-es-fecha", 5, 1, "OK"))                              # timestamp
    filas.insert(90, ("XX123", fb.ts_local(fb.horas(2026, 5, 1)[0]), 5, 1, "OK"))     # frontera
    datos = fb.contenido(["frontera_id", "timestamp", "consumo_kwh", "version_lectura", "calidad_lectura"], filas)
    a = _leer(tmp_path, "consumos_2026-05.csv", datos)
    assert a.estado == "OK" and len(a.lecturas) == 144
    assert sorted(r.motivo for r in a.rechazadas) == sorted(
        [R.M_VALOR_NO_NUMERICO, R.M_TIMESTAMP_INVALIDO, R.M_FRONTERA_INVALIDA])
    assert a.filas_leidas == 147                               # nada se pierde en silencio
    assert all(r.detalle is None for r in a.rechazadas)        # ningun contenido de fila en el rechazo


def test_demasiadas_filas_malas_corrompen_el_archivo(tmp_path):
    filas = [(f, fb.ts_local(h), v, 1, "OK") for (f, h, v) in fb.valores_basicos(2026, 5, n=10)]
    filas += [(fb.F1, "basura", "x", 1, "OK")] * 10
    filas.append((fb.F1, fb.ts_local(fb.horas(2026, 5, 1)[0]), 1, 1, "OK"))
    datos = fb.contenido(["frontera_id", "timestamp", "consumo_kwh", "version_lectura", "calidad_lectura"], filas)
    assert _leer(tmp_path, "consumos_2026-05.csv", datos).motivo_rechazo == R.M_DEMASIADAS_FILAS_INVALIDAS


def test_una_fila_de_otro_mes_no_entra(tmp_path):
    """Un archivo mensual no puede tocar otro mes: es lo que protege lo ya cargado."""
    filas = [(f, fb.ts_local(h), v, 1, "OK") for (f, h, v) in fb.valores_basicos(2026, 5, n=72)]
    filas.insert(40, (fb.F1, "2026-01-01 00:00:00", 999999, 1, "OK"))
    datos = fb.contenido(["frontera_id", "timestamp", "consumo_kwh", "version_lectura", "calidad_lectura"], filas)
    a = _leer(tmp_path, "consumos_2026-05.csv", datos)
    assert [r.motivo for r in a.rechazadas] == [R.M_MES_FUERA_DEL_ARCHIVO]
    assert all(x.valor_kwh != 999999 for x in a.lecturas)


def test_el_mes_se_juzga_en_hora_local_no_en_utc(tmp_path):
    """01-may 00:00 local = 05:00Z; 30-abr 23:00 local = 04:00Z del 1-may (UTC dice mayo, local dice abril)."""
    filas = [(fb.F1, "2026-05-01T04:00:00Z", 1, 1, "OK"),    # = 30-abr 23:00 local -> NO es de mayo
             (fb.F1, "2026-05-01T05:00:00Z", 2, 1, "OK")]    # = 01-may 00:00 local -> si
    filas += [(fb.F2, fb.ts_utc(h), 3, 1, "OK") for h in fb.horas(2026, 5, 80)]
    datos = fb.contenido(["frontera_id", "timestamp_utc", "consumo_kwh", "version_lectura", "calidad_lectura"],
                         filas, delim=";")
    a = _leer(tmp_path, "consumos_2026-05.csv", datos)
    assert [r.motivo for r in a.rechazadas] == [R.M_MES_FUERA_DEL_ARCHIVO]


# ------------------------------------------------------------------ descubrimiento
def test_descubre_lo_que_haya_en_orden_lexicografico_e_ignora_lo_que_no_es_dato(tmp_path):
    for n in ["consumos_2026-04_correccion.csv", "consumos_2026-04.csv", "consumos_2026-01.csv",
              "README.md", ".gitkeep", "notas.pdf"]:
        (tmp_path / n).write_bytes(b"x")
    nombres = [p.name for p in consumos.descubrir(tmp_path)]
    # '.' (46) < '_' (95): la base va antes que su correccion
    assert nombres == ["consumos_2026-01.csv", "consumos_2026-04.csv", "consumos_2026-04_correccion.csv"]


# -------------------------------------------------- datos reales (si estan disponibles)
def test_real_se_detecta_cada_formato(datos_reales):
    por_nombre = {a.nombre: a for a in consumos.leer_directorio(datos_reales / "consumos")}
    esperado = {
        "consumos_2026-01.csv": (",", "LOCAL", False),
        "consumos_2026-02.csv": (";", "UTC", False),
        "consumos_2026-03.csv": (",", "LOCAL", True),
        "consumos_2026-04.csv": (",", "LOCAL", False),
        "consumos_2026-04_correccion.csv": (",", "LOCAL", False),
    }
    for nombre, (delim, tz, unidad) in esperado.items():
        a = por_nombre[nombre]
        assert a.estado == "OK" and not a.rechazadas, nombre
        assert (a.formato.delimitador, a.formato.tz_naive, a.formato.tiene_columna_unidad) == (delim, tz, unidad), nombre
    assert [a.filas_leidas for a in por_nombre.values()] == [29685, 26855, 29718, 28782, 300]
