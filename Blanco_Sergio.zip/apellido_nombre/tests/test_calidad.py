"""Reglas de calidad (B3-B5) y robustez frente a archivos nuevos o corruptos."""
import random
import shutil
from decimal import Decimal

import pytest

import _fabrica as fb
from bia import calidad, consumos
from bia import reglas as R

ENC = ["frontera_id", "timestamp", "consumo_kwh", "version_lectura", "calidad_lectura"]


def _archivo(tmp_path, nombre, filas):
    """filas: (frontera, datetime local, valor, version)."""
    datos = fb.contenido(ENC, [(f, fb.ts_local(h), v, ver, "OK") for (f, h, v, ver) in filas])
    return consumos.leer_archivo(fb.escribir(tmp_path, nombre, datos))


H0 = fb.horas(2026, 5, 1)[0]


def _una(tmp_path, valor, nombre="consumos_2026-05.csv", ver=1):
    """Resuelve una sola lectura y devuelve la ganadora."""
    arch = _archivo(tmp_path, nombre, [(fb.F1, H0, valor, ver)] * 1 + [(fb.F2, h, 1, 1) for h in fb.horas(2026, 5, 30)])
    res = calidad.resolver([arch])
    return next(g for g in res.ganadoras if g.frontera_id == fb.F1 and g.ts_utc == consumos._parsear_timestamp(fb.ts_local(H0), "LOCAL"))


# ----------------------------------------------------------------- B4 · inválidos
@pytest.mark.parametrize("valor,estado,motivo", [
    ("-0.001", R.INVALIDA, R.NEGATIVO),
    ("0", R.VALIDA, None),                      # cero es una lectura valida
    ("1000000", R.VALIDA, None),                # el limite exacto es valido (> estricto)
    ("1000000.001", R.INVALIDA, R.OUTLIER),
    ("", R.INVALIDA, R.NULO),
    ("NaN", R.INVALIDA, R.NULO),
])
def test_b4_umbrales(tmp_path, valor, estado, motivo):
    g = _una(tmp_path, valor)
    assert (g.estado, g.motivo_invalidez) == (estado, motivo)
    assert (g.valor_kwh is None) == (estado == R.INVALIDA)        # no se imputa


def test_b4_el_outlier_se_juzga_despues_de_convertir_unidades(tmp_path):
    """1000.000001 MWh = 1.000000001e6 kWh: solo es outlier si se convierte ANTES."""
    filas = [(fb.F1, H0, "1000.000001", "MWh", 1, "OK")] + [(fb.F2, h, 1, "kWh", 1, "OK") for h in fb.horas(2026, 5, 30)]
    datos = fb.contenido(["frontera_id", "timestamp", "consumo_kwh", "unidad", "version_lectura", "calidad_lectura"],
                         [(f, fb.ts_local(h), v, u, ver, c) for (f, h, v, u, ver, c) in filas])
    res = calidad.resolver([consumos.leer_archivo(fb.escribir(tmp_path, "consumos_2026-05.csv", datos))])
    assert res.dq["registros_outlier"] == 1


def test_b4_un_valor_en_mwh_se_convierte_a_kwh(tmp_path):
    filas = [(fb.F1, fb.ts_local(H0), "0.5", "MWh", 1, "OK")] + [(fb.F2, fb.ts_local(h), 1, "kWh", 1, "OK") for h in fb.horas(2026, 5, 30)]
    datos = fb.contenido(["frontera_id", "timestamp", "consumo_kwh", "unidad", "version_lectura", "calidad_lectura"], filas)
    res = calidad.resolver([consumos.leer_archivo(fb.escribir(tmp_path, "consumos_2026-05.csv", datos))])
    g = next(g for g in res.ganadoras if g.frontera_id == fb.F1)
    assert g.valor_kwh == Decimal("500") and g.unidad_origen == "MWh"
    assert res.dq["registros_mwh_convertidos"] == 1


# ----------------------------------------------------------------- B3 · duplicados
def test_b3_gana_la_mayor_version_aunque_este_en_un_archivo_anterior(tmp_path):
    a = _archivo(tmp_path, "consumos_2026-05.csv", [(fb.F1, H0, 10, 2), (fb.F2, H0, 1, 1)])
    b = _archivo(tmp_path, "consumos_2026-05_z.csv", [(fb.F1, H0, 99, 1), (fb.F2, H0, 1, 1)])
    res = calidad.resolver([a, b])
    g = next(g for g in res.ganadoras if g.frontera_id == fb.F1)
    assert g.valor_kwh == 10 and g.version_lectura == 2
    assert res.dq["correcciones_tardias_aplicadas"] == 1
    assert res.dq["duplicados_exactos"] == 1                       # F2: misma version y valor


def test_b3_empate_de_version_gana_el_ultimo_archivo_en_orden_lexicografico(tmp_path):
    a = _archivo(tmp_path, "consumos_2026-05.csv", [(fb.F1, H0, 10, 1)])
    b = _archivo(tmp_path, "consumos_2026-05_b.csv", [(fb.F1, H0, 20, 1)])
    for orden in ([a, b], [b, a]):                                 # el orden de la lista no importa
        res = calidad.resolver(orden)
        assert res.ganadoras[0].valor_kwh == 20
        assert res.dq["duplicados_conflictivos"] == 1 and res.dq["duplicados_exactos"] == 0


def test_b3_dentro_de_un_mismo_archivo_gana_la_ultima_fila(tmp_path):
    a = _archivo(tmp_path, "consumos_2026-05.csv", [(fb.F1, H0, 10, 1), (fb.F1, H0, 30, 1), (fb.F1, H0, 20, 1)])
    res = calidad.resolver([a])
    assert res.ganadoras[0].valor_kwh == 20
    assert res.dq["duplicados_conflictivos"] == 2                  # filas sobrantes, no grupos


def test_b3_la_ganadora_invalida_no_deja_resucitar_a_la_perdedora_valida(tmp_path):
    """v2 vacia reemplaza a v1 valida: la hora queda como hueco, no vuelve a 10."""
    a = _archivo(tmp_path, "consumos_2026-05.csv", [(fb.F1, H0, 10, 1)])
    c = _archivo(tmp_path, "consumos_2026-05_correccion.csv", [(fb.F1, H0, "", 2)])
    res = calidad.resolver([a, c])
    g = res.ganadoras[0]
    assert (g.estado, g.motivo_invalidez, g.valor_kwh) == (R.INVALIDA, R.NULO, None)
    assert res.dq["registros_nulos"] == 1 and res.dq["correcciones_tardias_aplicadas"] == 1
    assert calidad.consumo_mensual(res.ganadoras) == []


# ----------------------------------------------------------------- B5 · huecos
def test_b5_hueco_es_hora_sin_lectura_valida_exista_la_fila_o_no(tmp_path):
    """F1: 10 horas validas + 2 invalidas (B4) de 744 => 734 huecos. F2 completa => ninguno."""
    horas_mes = fb.horas(2026, 5, 744)
    filas = [(fb.F1, h, 5, 1) for h in horas_mes[:10]]
    filas += [(fb.F1, horas_mes[10], -1, 1), (fb.F1, horas_mes[11], "", 1)]     # existen pero se descartan
    filas += [(fb.F2, h, 5, 1) for h in horas_mes]
    res = calidad.resolver([_archivo(tmp_path, "consumos_2026-05.csv", filas)])
    assert res.dq["horas_sin_lectura_valida_por_frontera"] == {fb.F1: 734}
    assert res.dq["horas_sin_lectura_valida_total"] == 734


def test_b5_los_huecos_se_cuentan_sobre_el_mes_calendario_completo(tmp_path):
    """Febrero tiene 672 horas; un mes cargado al que le falta la mitad reporta la mitad."""
    res = calidad.resolver([_archivo(tmp_path, "consumos_2026-02.csv",
                                     [(fb.F1, h, 1, 1) for h in fb.horas(2026, 2, 336)])])
    assert res.dq["horas_sin_lectura_valida_total"] == 336


def test_b5_no_se_inventan_huecos_en_meses_que_no_se_cargaron(tmp_path):
    horas_mes = fb.horas(2026, 5, 744)
    res = calidad.resolver([_archivo(tmp_path, "consumos_2026-05.csv", [(fb.F1, h, 1, 1) for h in horas_mes])])
    assert res.meses == ["2026-05"] and res.dq["horas_sin_lectura_valida_total"] == 0


def test_frontera_desconocida_va_a_cuarentena_y_no_se_carga(tmp_path):
    arch = _archivo(tmp_path, "consumos_2026-05.csv", [(fb.F1, H0, 1, 1), (fb.F2, H0, 1, 1)])
    res = calidad.resolver([arch], fronteras_validas={fb.F1})
    assert [g.frontera_id for g in res.ganadoras] == [fb.F1]
    assert [r.motivo for r in res.rechazadas] == [R.M_FRONTERA_DESCONOCIDA]


# ------------------------------------------------- determinismo y pureza
def test_el_resultado_no_depende_del_orden_de_los_archivos(tmp_path):
    a = _archivo(tmp_path, "consumos_2026-05.csv", [(fb.F1, h, i, 1) for i, h in enumerate(fb.horas(2026, 5, 50))])
    b = _archivo(tmp_path, "consumos_2026-05_b.csv", [(fb.F1, h, i + 1000, 1) for i, h in enumerate(fb.horas(2026, 5, 30))])
    c = _archivo(tmp_path, "consumos_2026-05_c.csv", [(fb.F1, h, i + 5000, 2) for i, h in enumerate(fb.horas(2026, 5, 10))])
    referencia = calidad.resolver([a, b, c])
    for _ in range(10):
        lista = [a, b, c]
        random.shuffle(lista)
        otra = calidad.resolver(lista)
        assert otra.ganadoras == referencia.ganadoras and otra.dq == referencia.dq


# ------------------------- ROBUSTEZ: el archivo nuevo/corrupto no corrompe lo cargado
def _meses_cargados(res, meses):
    return [g for g in res.ganadoras if R.mes_local(g.ts_utc) in meses]


def test_un_mes_nuevo_no_cambia_los_ya_cargados(tmp_path):
    base = [_archivo(tmp_path, f"consumos_2026-0{m}.csv", [(fb.F1, h, m, 1) for h in fb.horas(2026, m, 40)])
            for m in (1, 2)]
    antes = calidad.resolver(base)
    nuevo = _archivo(tmp_path, "consumos_2026-05.csv", [(fb.F1, h, 7, 1) for h in fb.horas(2026, 5, 40)])
    despues = calidad.resolver(base + [nuevo])
    assert _meses_cargados(despues, {"2026-01", "2026-02"}) == antes.ganadoras
    assert [x for x in calidad.consumo_mensual(despues.ganadoras) if x[1] in ("2026-01", "2026-02")] \
        == calidad.consumo_mensual(antes.ganadoras)


def test_archivos_corruptos_no_cambian_nada_de_lo_cargado(tmp_path):
    base = [_archivo(tmp_path, f"consumos_2026-0{m}.csv", [(fb.F1, h, m, 1) for h in fb.horas(2026, m, 40)])
            for m in (1, 2)]
    antes = calidad.resolver(base)

    buenos = fb.formato_local(2026, 6, fb.valores_basicos(2026, 6, n=24))
    corruptos = {
        "consumos_2026-06.csv": buenos[: len(buenos) - 9],                                   # truncado
        "consumos_2026-07.csv": b"\x00\x01\x02" * 500,                                       # binario
        "consumos_2026-08.csv": fb.contenido(["x", "y", "z"], [(1, 2, 3)] * 30),             # encabezado raro
        # el ataque fino: parece valido pero trae filas de enero con otros valores
        "consumos_2026-09.csv": fb.contenido(ENC, [(fb.F1, fb.ts_local(h), 123456, 2, "OK") for h in fb.horas(2026, 1, 40)]),
    }
    leidos = [consumos.leer_archivo(fb.escribir(tmp_path, n, d)) for n, d in corruptos.items()]
    assert all(a.estado == "RECHAZADO" for a in leidos), [(a.nombre, a.estado) for a in leidos]

    despues = calidad.resolver(base + leidos)
    assert despues.ganadoras == antes.ganadoras
    assert calidad.consumo_mensual(despues.ganadoras) == calidad.consumo_mensual(antes.ganadoras)
    assert {n for n, _ in despues.archivos_rechazados} == set(corruptos)          # y quedan reportados


# ------------------------------------------------- datos REALES: cifras de referencia
@pytest.fixture(scope="module")
def real(datos_reales, fronteras_maestro):
    archivos = consumos.leer_directorio(datos_reales / "consumos")
    return archivos, calidad.resolver(archivos, fronteras_maestro)


def test_real_reporte_de_calidad(real):
    _, res = real
    d = dict(res.dq)
    huecos = d.pop("horas_sin_lectura_valida_por_frontera")
    assert d == {
        "filas_leidas": 115340,
        "duplicados_exactos": 180,
        "duplicados_conflictivos": 120,
        "registros_negativos": 90,
        "registros_nulos": 60,
        "registros_outlier": 45,
        "registros_mwh_convertidos": 400,
        "correcciones_tardias_aplicadas": 300,
        "horas_sin_lectura_valida_total": 655,
    }
    assert sum(huecos.values()) == 655 and len(huecos) == 40
    assert res.rechazadas == [] and res.archivos_rechazados == []


def test_real_huecos_por_mes(real, fronteras_maestro):
    _, res = real
    por_mes = {m: sum(calidad.calcular_huecos(res.ganadoras, sorted(fronteras_maestro), [m]).values())
               for m in res.meses}
    assert por_mes == {"2026-01": 204, "2026-02": 128, "2026-03": 183, "2026-04": 140}


def test_real_consumo_mensual(real):
    _, res = real
    cm = calidad.consumo_mensual(res.ganadoras)
    assert len(cm) == 160                                        # 40 fronteras x 4 meses
    assert ("CO1114174638", "2026-01", Decimal("269445.112"), 742) in cm


def test_real_el_orden_de_los_archivos_no_cambia_nada(real, fronteras_maestro):
    archivos, ref = real
    barajado = list(archivos)
    random.Random(7).shuffle(barajado)
    otro = calidad.resolver(barajado, fronteras_maestro)
    assert otro.ganadoras == ref.ganadoras and otro.dq == ref.dq


def test_real_agregar_archivos_corruptos_al_directorio_no_cambia_el_resultado(real, datos_reales, fronteras_maestro, tmp_path):
    """El escenario exacto del evaluador, sobre los datos reales."""
    _, ref = real
    copia = tmp_path / "consumos"
    shutil.copytree(datos_reales / "consumos", copia)
    ene = (copia / "consumos_2026-01.csv").read_bytes()
    (copia / "consumos_2026-05.csv").write_bytes(ene[: len(ene) // 3 - 11])         # truncado a mitad de fila
    (copia / "consumos_2026-06.csv").write_bytes(ene[:5000].replace(b"1", b"\x00", 3))
    res = calidad.resolver(consumos.leer_directorio(copia), fronteras_maestro)
    assert res.ganadoras == ref.ganadoras
    assert calidad.consumo_mensual(res.ganadoras) == calidad.consumo_mensual(ref.ganadoras)
    assert len(res.archivos_rechazados) == 2
