"""Archivos de salida: formato EXACTO (seccion 5 del enunciado) y escritura atomica."""
import json
import os
from decimal import Decimal

import pytest

from bia import salidas
from bia.salidas import DQ_CLAVES, construir_dq_report, escribir_consumo_mensual, escribir_json

DQ = {
    "filas_leidas": 10, "duplicados_exactos": 1, "duplicados_conflictivos": 2, "registros_negativos": 3,
    "registros_nulos": 4, "registros_outlier": 5, "registros_mwh_convertidos": 6,
    "correcciones_tardias_aplicadas": 7, "horas_sin_lectura_valida_total": 8,
    "horas_sin_lectura_valida_por_frontera": {"CO2": 5, "CO1": 3},
}


def test_dq_report_tiene_las_12_llaves_en_el_orden_del_enunciado():
    r = construir_dq_report(DQ, fronteras_huerfanas_facturacion=12, clientes_con_pii=25)
    assert tuple(r) == DQ_CLAVES and len(r) == 12
    assert r["fronteras_huerfanas_facturacion"] == 12 and r["clientes_con_pii_en_texto_libre"] == 25


def test_dq_report_no_agrega_llaves_extra():
    r = construir_dq_report({**DQ, "algo_interno": 1}, 0, 0)
    assert set(r) == set(DQ_CLAVES)


def test_dq_report_falla_si_falta_una_llave_en_vez_de_inventarla():
    incompleto = {k: v for k, v in DQ.items() if k != "registros_nulos"}
    with pytest.raises(ValueError, match="registros_nulos"):
        construir_dq_report(incompleto, 0, 0)


def test_dq_report_ordena_las_fronteras_y_los_valores_son_enteros():
    r = construir_dq_report(DQ, 0, 0)
    assert list(r["horas_sin_lectura_valida_por_frontera"]) == ["CO1", "CO2"]
    assert all(isinstance(v, int) for k, v in r.items() if k != "horas_sin_lectura_valida_por_frontera")


# --------------------------------------------------------------- consumo_mensual.csv
def test_consumo_mensual_formato_exacto(tmp_path):
    ruta = tmp_path / "out" / "consumo_mensual.csv"
    n = escribir_consumo_mensual(ruta, [("CO1114174638", "2026-01", Decimal("183421.553"), 744),
                                        ("CO1114174638", "2026-02", Decimal("5"), 12)])
    assert n == 2
    assert ruta.read_bytes() == (b"frontera_id,mes,consumo_kwh,horas_con_dato\n"
                                 b"CO1114174638,2026-01,183421.553,744\n"
                                 b"CO1114174638,2026-02,5.000,12\n")          # siempre 3 decimales


@pytest.mark.parametrize("valor,texto", [("0", "0.000"), ("0.5", "0.500"), ("12.3456", "12.346"),
                                         ("1000000", "1000000.000"), ("269445.112", "269445.112")])
def test_tres_decimales(tmp_path, valor, texto):
    ruta = tmp_path / "c.csv"
    escribir_consumo_mensual(ruta, [("CO1", "2026-01", Decimal(valor), 1)])
    assert ruta.read_text().splitlines()[1] == f"CO1,2026-01,{texto},1"


def test_sin_filas_deja_solo_el_encabezado(tmp_path):
    ruta = tmp_path / "c.csv"
    assert escribir_consumo_mensual(ruta, []) == 0
    assert ruta.read_text() == "frontera_id,mes,consumo_kwh,horas_con_dato\n"


def test_usa_salto_de_linea_unix_y_no_crlf(tmp_path):
    ruta = tmp_path / "c.csv"
    escribir_consumo_mensual(ruta, [("CO1", "2026-01", Decimal(1), 1)])
    assert b"\r" not in ruta.read_bytes()


# ------------------------------------------------------------------ escritura atomica
def test_escribir_json_es_valido_y_crea_directorios(tmp_path):
    ruta = tmp_path / "x" / "y" / "m.json"
    escribir_json(ruta, {"a": 1, "ñ": "acentos"})
    assert json.loads(ruta.read_text(encoding="utf-8")) == {"a": 1, "ñ": "acentos"}


def test_no_deja_temporales_atras(tmp_path):
    escribir_json(tmp_path / "m.json", {"a": 1})
    escribir_consumo_mensual(tmp_path / "c.csv", [])
    assert sorted(p.name for p in tmp_path.iterdir()) == ["c.csv", "m.json"]


def test_si_la_escritura_falla_el_archivo_anterior_queda_intacto(tmp_path):
    ruta = tmp_path / "m.json"
    escribir_json(ruta, {"version": "buena"})
    with pytest.raises(TypeError):
        escribir_json(ruta, {"roto": object()})                        # json no puede serializarlo
    assert json.loads(ruta.read_text()) == {"version": "buena"}        # intacto, no a medias
    assert [p.name for p in tmp_path.iterdir()] == ["m.json"]          # y sin temporales


def test_reemplaza_de_forma_atomica(tmp_path, monkeypatch):
    """Se escribe a un temporal y se renombra: nadie ve un archivo a medias."""
    ruta = tmp_path / "m.json"
    escribir_json(ruta, {"v": 1})
    llamadas = []
    real = os.replace
    monkeypatch.setattr(salidas.os, "replace", lambda a, b: (llamadas.append((a, b)), real(a, b))[1])
    escribir_json(ruta, {"v": 2})
    assert len(llamadas) == 1 and str(llamadas[0][1]) == str(ruta) and llamadas[0][0] != str(ruta)
