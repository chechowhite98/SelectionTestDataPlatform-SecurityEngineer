"""Orquestador de `make run`: pruebas de integracion contra una base TEMPORAL.

Cada prueba corre el pipeline de verdad (lee archivos, cifra, carga con commit real,
escribe out/ y logs/) sobre una copia de data/ y una base `bia_test_*` que se destruye
al terminar. La base del evaluador no se toca nunca.

Cubren los escenarios del contrato: dos corridas seguidas (idempotencia), un dato
tardio, un mes nuevo en cada formato conocido y archivos corruptos; y los caminos de
fallo: rollback, base inaccesible, maestro ilegible, sin filtrar datos personales.
"""
import json
import os
import re
import shutil
from decimal import Decimal

import pytest
from _pii_utils import fugas, pii_original
from conftest import conexion_superusuario

import _fabrica as fb
from bia import cripto, pii, pipeline, repositorio
from bia.config import cargar_config
from bia.salidas import DQ_CLAVES

ETAPAS = ["clasificacion", "maestros", "consumos_lectura", "calidad", "carga", "salidas"]
TABLAS = {
    "core.dim_cliente": "cliente_id",
    "core.dim_frontera": "frontera_id",
    "core.fact_consumo_horario": "frontera_id, ts_utc",
    "core.fact_factura": "factura_id",
    "core.fact_factura_componente": "factura_id, concepto",
    "quarantine.rechazo": "fuente, archivo, fila_origen, motivo",
    "ops.archivo_cargado": "nombre_archivo, sha256",
}
# Tablas sin cifrado aleatorio: comparables entre una carga incremental y una desde cero.
DETERMINISTAS = ["core.dim_frontera", "core.fact_consumo_horario", "core.fact_factura",
                 "core.fact_factura_componente"]
MOTIVOS_B4_Y_B6 = {"FRONTERA_HUERFANA": 12, "NEGATIVO": 90, "NULO": 60, "OUTLIER": 45}


class Entorno:
    """Una copia de data/, directorios out/ y logs/ propios, y llaves de cifrado fijas."""

    def __init__(self, tmp_path, bd, datos_reales):
        self.bd, self.datos_reales = bd, datos_reales
        self.data = tmp_path / "data"
        shutil.copytree(datos_reales, self.data)
        self.out, self.logs = tmp_path / "out", tmp_path / "logs"
        self.llaves = {"BIA_ENC_KEYS": f"1:{cripto.generar_llave()}", "BIA_INDEX_KEY": cripto.generar_llave()}

    def cfg(self, **extra):
        env = {"PG_HOST": os.environ.get("PG_HOST", "localhost"), "PG_PORT": os.environ.get("PG_PORT", "5432"),
               "PG_DB": self.bd, "INGESTA_PASSWORD": os.environ["INGESTA_PASSWORD"],
               "BIA_DATA_DIR": str(self.data), "BIA_OUT_DIR": str(self.out), "BIA_LOGS_DIR": str(self.logs),
               **self.llaves}
        env.update(extra)
        return cargar_config(env)

    def correr(self, **extra) -> int:
        return pipeline.ejecutar(self.cfg(**extra))

    # -- lo que dejo la corrida
    def json(self, nombre):
        return json.loads((self.out / nombre).read_text(encoding="utf-8"))

    def csv(self):
        return (self.out / "consumo_mensual.csv").read_text().splitlines()

    def eventos(self):
        return [json.loads(x) for x in (self.logs / "pipeline.log").read_text(encoding="utf-8").splitlines()]

    # -- la base, vista como superusuario
    def consulta(self, sql, params=None):
        conn = conexion_superusuario(self.bd)
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchall() if cur.description else None
        finally:
            conn.close()

    def estado(self, tablas=None, sin_tiempos=False):
        """md5 de TODOS los bytes de cada tabla. Con sin_tiempos se omiten las columnas con la hora
        de carga (DEFAULT now()): sirven para comparar dos cargas distintas del mismo dato."""
        fila = "(to_jsonb(x) - ARRAY['cargado_en','registrado_en','procesado_en','corrida_id'])::text" \
            if sin_tiempos else "x::text"
        out = {}
        for t in tablas or TABLAS:
            out[t] = self.consulta(
                f"SELECT md5(coalesce(string_agg({fila}, E'\\n' ORDER BY {TABLAS[t]}), '')), count(*) "
                f"FROM {t} x")[0]
        return out

    def vaciar(self):
        conn = conexion_superusuario(self.bd)
        conn.autocommit = True
        conn.cursor().execute("TRUNCATE core.dim_cliente CASCADE; TRUNCATE quarantine.rechazo, ops.archivo_cargado")
        conn.close()

    def auditoria(self, corrida_id):
        return self.consulta("""SELECT evento, etapa, resultado, ejecutado_por, filas_leidas, filas_cargadas,
                                       filas_rechazadas FROM audit.pipeline_runs
                                WHERE corrida_id = %s ORDER BY evento_id""", (corrida_id,))

    def fronteras(self, n=2):
        texto = (self.datos_reales / "maestros" / "fronteras.csv").read_bytes().decode("latin-1")
        return [ln.split(",")[0] for ln in texto.splitlines()[1:n + 1]]


@pytest.fixture
def entorno(tmp_path, bd_temporal, datos_reales):
    e = Entorno(tmp_path, bd_temporal, datos_reales)
    e.vaciar()
    yield e
    e.vaciar()


# =============================================================== el camino feliz
def test_primera_corrida_con_los_datos_reales(entorno):
    assert entorno.correr() == 0

    dq = entorno.json("dq_report.json")
    assert tuple(dq) == DQ_CLAVES
    por_frontera = dq.pop("horas_sin_lectura_valida_por_frontera")
    assert dq == {
        "filas_leidas": 115340, "duplicados_exactos": 180, "duplicados_conflictivos": 120,
        "registros_negativos": 90, "registros_nulos": 60, "registros_outlier": 45,
        "registros_mwh_convertidos": 400, "correcciones_tardias_aplicadas": 300,
        "horas_sin_lectura_valida_total": 655, "fronteras_huerfanas_facturacion": 12,
        "clientes_con_pii_en_texto_libre": 25}
    assert sum(por_frontera.values()) == 655 and len(por_frontera) == 40

    filas = entorno.csv()
    assert filas[0] == "frontera_id,mes,consumo_kwh,horas_con_dato" and len(filas) == 161   # 40 x 4 + encabezado
    assert "CO1114174638,2026-01,269445.112,742" in filas
    assert all(re.fullmatch(r"CO\d{10},\d{4}-\d\d,\d+\.\d{3},\d+", f) for f in filas[1:])


def test_las_metricas_tienen_lo_que_pide_el_enunciado(entorno):
    entorno.correr()
    m = entorno.json("metrics.json")
    assert m["resultado"] == "OK"
    assert (m["filas_leidas"], m["filas_cargadas"], m["filas_rechazadas"]) == (115632, 115940, 207)
    assert m["filas_rechazadas_por_motivo"] == MOTIVOS_B4_Y_B6
    assert list(m["duracion_por_etapa_s"]) == ETAPAS and all(v >= 0 for v in m["duracion_por_etapa_s"].values())
    assert re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ", m["timestamp_corrida"])
    assert m["detalle_por_fuente"]["consumos"]["cargadas"] == 114740
    assert m["archivos_rechazados"] == []
    assert m["formatos_detectados"]["consumos_2026-02.csv"]["delimitador"] == ";"


def test_la_bitacora_registra_quien_que_cuando_cuantas_y_con_que_resultado(entorno):
    entorno.correr()
    m = entorno.json("metrics.json")
    filas = entorno.auditoria(m["corrida_id"])
    assert [(f[0], f[1]) for f in filas] == [("INICIO", None)] + [("ETAPA", e) for e in ETAPAS] + [("FIN", None)]
    assert {f[3] for f in filas} == {"ingesta"}                       # quien: el rol, no el superusuario
    assert all(f[2] == "OK" for f in filas[1:])
    assert filas[-1][4:] == (m["filas_leidas"], m["filas_cargadas"], m["filas_rechazadas"])


def test_los_logs_son_json_una_linea_por_evento_de_la_misma_corrida(entorno):
    entorno.correr()
    eventos = entorno.eventos()
    assert len({e["corrida_id"] for e in eventos}) == 1
    nombres = [e["evento"] for e in eventos]
    assert nombres[0] == "corrida_inicio" and nombres[-1] == "corrida_fin"
    assert nombres.count("etapa_inicio") == nombres.count("etapa_fin") == len(ETAPAS)
    assert eventos[-1]["resultado"] == "OK" and all("pii_redactada" not in e for e in eventos)


# ============================================================ idempotencia (B / A)
def test_dos_corridas_seguidas_dejan_exactamente_el_mismo_estado(entorno):
    entorno.correr()
    estado1, csv1, dq1 = entorno.estado(), entorno.csv(), entorno.json("dq_report.json")

    assert entorno.correr() == 0
    assert entorno.estado() == estado1                                  # los BYTES de las 7 tablas
    assert (entorno.csv(), entorno.json("dq_report.json")) == (csv1, dq1)

    m = entorno.json("metrics.json")
    assert m["filas_cargadas"] == 0 and all(v["cargadas"] == 0 for v in m["detalle_por_fuente"].values())
    assert len(m["archivos_consumo_omitidos_ya_cargados"]) == 5          # no se recargo ningun archivo
    assert m["filas_leidas"] == 115632                                    # pero sigue leyendo todo


def test_el_libro_de_archivos_y_la_cuarentena_no_se_duplican(entorno):
    for _ in range(3):
        entorno.correr()
    assert entorno.consulta("SELECT count(*) FROM ops.archivo_cargado")[0][0] == 9     # 5 consumos + 4 facturacion
    assert entorno.consulta("SELECT count(*) FROM quarantine.rechazo")[0][0] == 207


def test_un_dato_tardio_entra_sin_recargar_nada_mas(entorno):
    correccion = entorno.data / "consumos" / "consumos_2026-04_correccion.csv"
    contenido = correccion.read_bytes()
    correccion.unlink()
    assert entorno.correr() == 0
    assert entorno.json("dq_report.json")["correcciones_tardias_aplicadas"] == 0

    correccion.write_bytes(contenido)                                   # llega la relectura de abril
    assert entorno.correr() == 0
    m = entorno.json("metrics.json")
    assert m["detalle_por_fuente"]["consumos"]["cargadas"] == 300        # solo las 300 filas corregidas
    assert sum(v["cargadas"] for k, v in m["detalle_por_fuente"].items() if k != "consumos") == 0
    assert len(m["archivos_consumo_omitidos_ya_cargados"]) == 4
    assert entorno.json("dq_report.json")["correcciones_tardias_aplicadas"] == 300

    # y el resultado final es identico a cargar todo desde cero
    incremental = (entorno.estado(DETERMINISTAS, sin_tiempos=True), entorno.csv(), entorno.json("dq_report.json"))
    entorno.vaciar()
    entorno.correr()
    assert (entorno.estado(DETERMINISTAS, sin_tiempos=True), entorno.csv(), entorno.json("dq_report.json")) == incremental


# ================================================= descubrimiento: un mes NUEVO
def _mayo(entorno, formato):
    a, b = entorno.fronteras(2)
    valores = [(f, h, round(base + i, 3)) for i, h in enumerate(fb.horas(2026, 5, 48))
               for f, base in ((a, 10.5), (b, 200.25))]
    construir = {"local": fb.formato_local, "utc": fb.formato_utc, "mwh": fb.formato_mwh}[formato]
    fb.escribir(entorno.data / "consumos", "consumos_2026-05.csv", construir(2026, 5, valores))
    suma = lambda base: sum(Decimal(str(round(base + i, 3))) for i in range(48))      # noqa: E731
    return {f"{a},2026-05,{suma(10.5):.3f},48", f"{b},2026-05,{suma(200.25):.3f},48"}


@pytest.mark.parametrize("formato", ["local", "utc", "mwh"])
def test_un_mes_nuevo_en_cada_formato_conocido_se_procesa_solo(entorno, formato):
    entorno.correr()
    antes, estado_antes = entorno.csv(), entorno.estado(["core.fact_consumo_horario"])
    esperado_mayo = _mayo(entorno, formato)

    assert entorno.correr() == 0
    despues = entorno.csv()
    assert {f for f in despues if ",2026-05," in f} == esperado_mayo
    assert [f for f in despues if ",2026-05," not in f] == antes                   # enero-abril, intactos
    assert entorno.json("metrics.json")["detalle_por_fuente"]["consumos"]["cargadas"] == 96
    assert entorno.estado(["core.fact_consumo_horario"])["core.fact_consumo_horario"][1] == \
        estado_antes["core.fact_consumo_horario"][1] + 96

    assert entorno.correr() == 0                                                   # y otra vez: nada cambia
    assert entorno.csv() == despues and entorno.json("metrics.json")["filas_cargadas"] == 0


# ================================================ robustez: archivos corruptos
def _corruptos(entorno):
    """Lo que deja caer el evaluador despues de un mes nuevo, mas el ataque fino."""
    junio = fb.formato_local(2026, 6, [(f, h, 7.5) for f in entorno.fronteras(2) for h in fb.horas(2026, 6, 48)])
    enero = fb.horas(2026, 1, 48)
    mirando_enero = fb.contenido(
        ["frontera_id", "timestamp", "consumo_kwh", "version_lectura", "calidad_lectura"],
        [(entorno.fronteras(1)[0], fb.ts_local(h), 123456, 2, "OK") for h in enero])
    d = entorno.data / "consumos"
    fb.escribir(d, "consumos_2026-06.csv", junio[: len(junio) - 9])                      # truncado a mitad de fila
    fb.escribir(d, "consumos_2026-07.csv", os.urandom(300) + b"\x00" * 50)               # basura binaria
    fb.escribir(d, "consumos_2026-08.csv", fb.contenido(["x", "y", "z"], [(1, 2, 3)] * 30))   # encabezado ajeno
    fb.escribir(d, "consumos_2026-09.csv", mirando_enero)                                # filas de enero, valores otros
    return {"consumos_2026-06.csv": "ARCHIVO_TRUNCADO", "consumos_2026-07.csv": "CONTENIDO_BINARIO",
            "consumos_2026-08.csv": "ENCABEZADO_NO_RECONOCIDO", "consumos_2026-09.csv": "SIN_FILAS_VALIDAS"}


def test_archivos_corruptos_no_corrompen_lo_ya_cargado(entorno):
    _mayo(entorno, "utc")
    entorno.correr()
    csv_antes = entorno.csv()
    consumo_antes = entorno.estado(["core.fact_consumo_horario"])

    esperado = _corruptos(entorno)
    assert entorno.correr() == 0                                                         # no falla...
    m = entorno.json("metrics.json")
    assert m["resultado"] == "PARCIAL"                                                  # ...pero lo dice
    assert {a["archivo"]: a["motivo"] for a in m["archivos_rechazados"]} == esperado

    assert entorno.csv() == csv_antes                                                    # ...y no corrompe
    assert entorno.estado(["core.fact_consumo_horario"]) == consumo_antes

    # quedan en cuarentena y en el libro, con su motivo
    en_cuarentena = dict(entorno.consulta(
        "SELECT archivo, motivo FROM quarantine.rechazo WHERE fuente = 'consumos' AND fila_origen = 0"))
    assert en_cuarentena == esperado
    libro = dict(entorno.consulta("SELECT nombre_archivo, estado FROM ops.archivo_cargado WHERE estado = 'RECHAZADO' "
                                  "AND fuente = 'consumos'"))
    assert set(libro) == set(esperado)
    assert any(e["evento"] == "archivo_rechazado" and e["nivel"] == "WARNING" for e in entorno.eventos())
    assert entorno.eventos()[-1]["resultado"] == "PARCIAL"

    # repetir no duplica nada
    estado = entorno.estado()
    assert entorno.correr() == 0
    assert entorno.estado() == estado


def test_en_modo_estricto_un_archivo_corrupto_termina_con_codigo_2(entorno):
    entorno.correr()
    _corruptos(entorno)
    assert entorno.correr(BIA_FALLAR_SI_PARCIAL="1") == 2


def test_un_archivo_de_facturacion_ilegible_no_afecta_a_los_demas(entorno):
    (entorno.data / "facturacion" / "facturacion_2026-05.json").write_text("{ esto no es json")
    assert entorno.correr() == 0
    m = entorno.json("metrics.json")
    assert m["resultado"] == "PARCIAL"
    assert m["archivos_rechazados"] == [{"archivo": "facturacion_2026-05.json", "fuente": "facturacion",
                                         "motivo": "ARCHIVO_INVALIDO"}]
    assert entorno.consulta("SELECT count(*) FROM core.fact_factura")[0][0] == 160


# ============================================================ autorreparacion
def test_si_alguien_vacia_la_tabla_de_consumos_el_pipeline_la_repara(entorno):
    entorno.correr()
    original = entorno.estado(["core.fact_consumo_horario"], sin_tiempos=True)
    conn = conexion_superusuario(entorno.bd)
    conn.autocommit = True
    conn.cursor().execute("TRUNCATE core.fact_consumo_horario")                          # el libro sigue diciendo 'cargado'
    conn.close()

    assert entorno.correr() == 0
    assert entorno.estado(["core.fact_consumo_horario"], sin_tiempos=True) == original
    assert entorno.json("metrics.json")["detalle_por_fuente"]["consumos"]["cargadas"] == 114740
    assert any(e["evento"] == "reparacion_automatica" for e in entorno.eventos())


# ======================================================== caminos de fallo
def test_un_error_de_carga_revierte_todo_y_queda_auditado_sin_filtrar_datos(entorno, monkeypatch):
    def explota(cur, filas):
        raise RuntimeError("fila con celular 3001234567 y correo secreto@privado.co")
    monkeypatch.setattr(repositorio, "upsert_consumos", explota)

    assert entorno.correr() == 1

    # TODO o NADA: ni las dimensiones, que se cargaron antes en la misma transaccion, quedaron
    for tabla in ("core.dim_cliente", "core.dim_frontera", "core.fact_factura", "quarantine.rechazo",
                  "ops.archivo_cargado", "core.fact_consumo_horario"):
        assert entorno.consulta(f"SELECT count(*) FROM {tabla}")[0][0] == 0, tabla
    assert not (entorno.out / "consumo_mensual.csv").exists() and not (entorno.out / "dq_report.json").exists()

    # pero la AUDITORIA si sobrevivio (conexion propia): INICIO, etapa en ERROR y FIN en ERROR
    m = entorno.json("metrics.json")
    assert m["resultado"] == "ERROR"
    filas = entorno.auditoria(m["corrida_id"])
    assert filas[0][0] == "INICIO" and ("ETAPA", "carga", "ERROR") in [(f[0], f[1], f[2]) for f in filas]
    assert (filas[-1][0], filas[-1][2]) == ("FIN", "ERROR")

    # y nada del mensaje (que traia PII) llego a los logs ni a las metricas
    texto = (entorno.logs / "pipeline.log").read_text() + (entorno.out / "metrics.json").read_text()
    assert "3001234567" not in texto and "secreto@privado.co" not in texto
    error = next(e for e in entorno.eventos() if e["evento"] == "corrida_error")
    assert error["error_tipo"] == "RuntimeError" and "error_mensaje" not in error


def test_con_la_base_inaccesible_falla_limpio_y_sin_filtrar_la_contrasena(entorno):
    assert entorno.correr(INGESTA_PASSWORD="contrasena-incorrecta-123") == 1
    assert entorno.json("metrics.json")["resultado"] == "ERROR"
    texto = (entorno.logs / "pipeline.log").read_text() + (entorno.out / "metrics.json").read_text()
    assert "contrasena-incorrecta-123" not in texto
    assert next(e for e in entorno.eventos() if e["evento"] == "corrida_error")["error_tipo"] == "OperationalError"


def test_un_maestro_ilegible_es_fatal_y_queda_auditado(entorno):
    (entorno.data / "maestros" / "clientes.csv").write_bytes(b"")
    assert entorno.correr() == 1
    error = next(e for e in entorno.eventos() if e["evento"] == "corrida_error")
    assert error["error_tipo"] == "MaestroInvalido" and error["error_mensaje"] == "clientes.csv: vacio o binario"
    m = entorno.json("metrics.json")
    assert m["resultado"] == "ERROR" and entorno.auditoria(m["corrida_id"])[-1][2] == "ERROR"
    assert not (entorno.out / "consumo_mensual.csv").exists()


@pytest.mark.parametrize("quitar", ["maestros/fronteras.csv", "maestros/limites_frontera.csv", "consumos"])
def test_una_entrada_obligatoria_ausente_es_fatal(entorno, quitar):
    ruta = entorno.data / quitar
    shutil.rmtree(ruta) if ruta.is_dir() else ruta.unlink()
    assert entorno.correr() == 1


def test_sin_directorio_de_facturacion_el_resto_se_procesa(entorno):
    shutil.rmtree(entorno.data / "facturacion")
    assert entorno.correr() == 0
    assert any(e["evento"] == "facturacion_ausente" for e in entorno.eventos())
    assert entorno.json("dq_report.json")["fronteras_huerfanas_facturacion"] == 0


# ============================================ eliminatoria 1: PII en logs y out/
def test_ni_los_logs_ni_out_contienen_pii_en_ninguna_corrida(entorno, datos_reales):
    entorno.correr()                                                                     # feliz
    entorno.correr()                                                                     # idempotente
    _corruptos(entorno)
    entorno.correr()                                                                     # con archivos corruptos
    entorno.correr(INGESTA_PASSWORD="contrasena-incorrecta-123")                         # con error
    (entorno.data / "maestros" / "clientes.csv").write_bytes(b"")
    entorno.correr()                                                                     # con maestro ilegible

    secretos = pii_original(datos_reales)
    assert len(secretos) > 100
    revisados = 0
    for carpeta in (entorno.logs, entorno.out):
        for archivo in carpeta.iterdir():
            texto = archivo.read_text(encoding="utf-8")
            assert fugas(texto, secretos) == [], archivo.name
            assert not pii.EMAIL.search(texto), archivo.name                              # ningun correo, cualquiera
            revisados += 1
    assert revisados == 4                                                                # pipeline.log + 3 de out/
    assert all("pii_redactada" not in e for e in entorno.eventos())                      # y nada intento colarse
