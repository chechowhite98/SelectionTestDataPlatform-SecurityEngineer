"""Cifrado AES-GCM, indice ciego y configuracion de llaves (C3, C6)."""
import base64
import os

import pytest

from bia import cripto
from bia.cripto import Cifrador, ConfiguracionInvalida, ErrorCripto, cargar_llaves, generar_llave


def _env(**extra):
    base = {"BIA_ENC_KEYS": f"1:{generar_llave()}", "BIA_INDEX_KEY": generar_llave()}
    base.update(extra)
    return base


@pytest.fixture
def cif():
    return Cifrador(cargar_llaves(_env()))


# ------------------------------------------------------------------ cifrado
def test_ida_y_vuelta(cif):
    blob = cif.cifrar("900123456-7", "core.dim_cliente.nit_cifrado|CLI0001")
    assert cif.descifrar_texto(blob, "core.dim_cliente.nit_cifrado|CLI0001") == "900123456-7"


def test_unicode_y_bytes(cif):
    for dato in ("Cra 7 # 71-21, Bogotá — Piso 3 ñ", b"\x00\x01\xff"):
        blob = cif.cifrar(dato, "ctx")
        esperado = dato if isinstance(dato, bytes) else dato.encode()
        assert cif.descifrar(blob, "ctx") == esperado


def test_el_formato_cumple_el_contrato_con_la_base(cif):
    """version(1) || nonce(12) || texto || tag(16): minimo 29 bytes, como core.pii_cifrado."""
    blob = cif.cifrar("", "ctx")                       # incluso vacio
    assert len(blob) == cripto.LARGO_MINIMO == 29 and blob[0] == cif.version_actual
    assert len(cif.cifrar("abc", "ctx")) == 29 + 3


def test_el_cifrado_no_es_determinista(cif):
    """Mismo dato, dos cifrados distintos: no filtra igualdad entre valores."""
    assert cif.cifrar("x", "ctx") != cif.cifrar("x", "ctx")


def test_el_texto_en_claro_no_aparece_en_el_cifrado(cif):
    dato = "contacto@empresa-cliente.com.co"
    assert dato.encode() not in cif.cifrar(dato, "ctx")


def test_un_valor_atado_a_su_fila_no_sirve_en_otra(cif):
    """Copiar el NIT cifrado de CLI0001 a la fila de CLI0002 debe FALLAR, no entregar un dato ajeno."""
    blob = cif.cifrar("900123456-7", "core.dim_cliente.nit_cifrado|CLI0001")
    with pytest.raises(ErrorCripto):
        cif.descifrar(blob, "core.dim_cliente.nit_cifrado|CLI0002")
    with pytest.raises(ErrorCripto):                    # ni en otra columna
        cif.descifrar(blob, "core.dim_cliente.email_contacto_cifrado|CLI0001")


@pytest.mark.parametrize("posicion", [0, 5, 13, -1])
def test_cualquier_alteracion_se_detecta(cif, posicion):
    blob = bytearray(cif.cifrar("dato", "ctx"))
    blob[posicion] ^= 0x01
    with pytest.raises(ErrorCripto):
        cif.descifrar(bytes(blob), "ctx")


def test_valores_truncados_o_basura_no_revientan_con_excepciones_raras(cif):
    for malo in (b"", b"\x01", os.urandom(28), os.urandom(60)):
        with pytest.raises(ErrorCripto):
            cif.descifrar(malo, "ctx")


def test_el_mensaje_de_error_no_revela_datos_ni_llaves(cif):
    blob = cif.cifrar("secreto-123", "ctx")
    with pytest.raises(ErrorCripto) as e:
        cif.descifrar(blob, "otro")
    assert "secreto-123" not in str(e.value)


# --------------------------------------------------------------- rotacion de llaves
def test_rotacion_se_cifra_con_la_nueva_y_se_descifra_con_cualquiera():
    k1, k2, idx = generar_llave(), generar_llave(), generar_llave()
    viejo = Cifrador(cargar_llaves({"BIA_ENC_KEYS": f"1:{k1}", "BIA_INDEX_KEY": idx}))
    blob_v1 = viejo.cifrar("dato", "ctx")
    nuevo = Cifrador(cargar_llaves({"BIA_ENC_KEYS": f"1:{k1},2:{k2}", "BIA_INDEX_KEY": idx}))
    assert nuevo.version_actual == 2
    assert nuevo.descifrar_texto(blob_v1, "ctx") == "dato"           # lo viejo sigue legible
    assert nuevo.cifrar("x", "ctx")[0] == 2                          # lo nuevo usa la version 2
    assert nuevo.necesita_rotacion(blob_v1) and not nuevo.necesita_rotacion(nuevo.cifrar("x", "c"))


def test_sin_la_llave_de_esa_version_no_se_descifra():
    k1, idx = generar_llave(), generar_llave()
    blob = Cifrador(cargar_llaves({"BIA_ENC_KEYS": f"1:{k1}", "BIA_INDEX_KEY": idx})).cifrar("d", "c")
    solo_v2 = Cifrador(cargar_llaves({"BIA_ENC_KEYS": f"2:{generar_llave()}", "BIA_INDEX_KEY": idx}))
    with pytest.raises(ErrorCripto, match="version de llave desconocida"):
        solo_v2.descifrar(blob, "c")


# ---------------------------------------------------------------- indice ciego
def test_indice_ciego_es_determinista_y_distingue(cif):
    assert cif.indice_ciego("9001234567") == cif.indice_ciego("9001234567")
    assert cif.indice_ciego("9001234567") != cif.indice_ciego("9001234568")
    assert len(cif.indice_ciego("9001234567")) == 32                 # lo que exige ck_nit_hash_len


def test_indice_ciego_depende_de_la_llave():
    a = Cifrador(cargar_llaves(_env()))
    b = Cifrador(cargar_llaves(_env()))
    assert a.indice_ciego("9001234567") != b.indice_ciego("9001234567")


def test_huella_e_indice_ciego_estan_en_dominios_separados(cif):
    """Una huella nunca puede confundirse con el indice ciego de un valor."""
    assert cif.huella(["9001234567"]) != cif.indice_ciego("9001234567")
    assert cif.huella(["a", None]) != cif.huella(["a", ""])          # None y vacio no colisionan


@pytest.mark.parametrize("crudo", ["900123456-7", "900.123.456-7", "NIT 900123456-7", "9001234567",
                                   " 900 123 456 - 7 ", "nit: 900.123.456-7"])
def test_los_formatos_de_nit_dan_el_mismo_indice(cif, crudo):
    assert cripto.normalizar_nit(crudo) == "9001234567"
    assert cif.indice_ciego(cripto.normalizar_nit(crudo)) == cif.indice_ciego("9001234567")


@pytest.mark.parametrize("malo", ["", None, "abc", "12345", "123456789012", "NIT"])
def test_nit_invalido(malo):
    assert cripto.normalizar_nit(malo) is None


# ------------------------------------------------------------ configuracion (C6)
def test_sin_llaves_el_pipeline_no_arranca():
    with pytest.raises(ConfiguracionInvalida, match="BIA_ENC_KEYS"):
        cargar_llaves({})
    with pytest.raises(ConfiguracionInvalida, match="BIA_INDEX_KEY"):
        cargar_llaves({"BIA_ENC_KEYS": f"1:{generar_llave()}"})


@pytest.mark.parametrize("llave,fragmento", [
    ("no-es-base64!!", "base64"),
    (base64.b64encode(b"corta").decode(), "32 bytes"),
    (base64.b64encode(bytes(32)).decode(), "entropia"),              # 32 ceros
    (base64.b64encode(b"A" * 32).decode(), "entropia"),
    # la "llave maestra" del scaffolding heredado: 22 bytes que ademas dicen 'not_a_real_key'
    ("Y2xhdmVfY29ydGFfZGVfcHJ1ZWJh", "32 bytes"),
])
def test_llaves_inseguras_se_rechazan(llave, fragmento):
    with pytest.raises(ConfiguracionInvalida, match=fragmento):
        cargar_llaves({"BIA_ENC_KEYS": f"1:{llave}", "BIA_INDEX_KEY": generar_llave()})


def test_la_llave_de_indice_no_puede_ser_la_de_cifrado():
    k = generar_llave()
    with pytest.raises(ConfiguracionInvalida, match="distinta"):
        cargar_llaves({"BIA_ENC_KEYS": f"1:{k}", "BIA_INDEX_KEY": k})


@pytest.mark.parametrize("valor", ["sin-version", "0:" + "A" * 43 + "=", "256:x", "1:x,1:y"])
def test_formato_de_bia_enc_keys(valor):
    with pytest.raises(ConfiguracionInvalida):
        cargar_llaves({"BIA_ENC_KEYS": valor, "BIA_INDEX_KEY": generar_llave()})


def test_version_actual_inexistente():
    with pytest.raises(ConfiguracionInvalida, match="BIA_ENC_KEY_VERSION"):
        cargar_llaves(_env(BIA_ENC_KEY_VERSION="9"))


def test_repr_no_filtra_material_de_llave():
    env = _env()
    texto = repr(cargar_llaves(env)) + str(cargar_llaves(env))
    for valor in (env["BIA_ENC_KEYS"].split(":")[1], env["BIA_INDEX_KEY"]):
        assert valor not in texto and base64.b64decode(valor).hex() not in texto


def test_los_errores_de_configuracion_no_incluyen_la_llave():
    mala = base64.b64encode(b"corta-pero-secreta").decode()
    with pytest.raises(ConfiguracionInvalida) as e:
        cargar_llaves({"BIA_ENC_KEYS": f"1:{mala}", "BIA_INDEX_KEY": generar_llave()})
    assert mala not in str(e.value) and "corta-pero-secreta" not in str(e.value)


def test_las_llaves_generadas_son_validas_y_distintas():
    a, b = generar_llave(), generar_llave()
    assert a != b and len(base64.b64decode(a)) == 32
