"""Fabrica de archivos de consumo sinteticos para pruebas.

Permite construir un mes "nuevo" en cualquiera de los formatos que existen en
data/consumos, o uno roto de una forma concreta, sin depender de los datos reales.
"""
from datetime import datetime, timedelta
from decimal import Decimal

F1, F2 = "CO0000000001", "CO0000000002"


def horas(anio, mes, n):
    """Las primeras n horas del mes, en hora local (naive)."""
    inicio = datetime(anio, mes, 1)
    return [inicio + timedelta(hours=i) for i in range(n)]


def ts_local(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def ts_utc(dt):
    return (dt + timedelta(hours=5)).strftime("%Y-%m-%dT%H:%M:%SZ")


def contenido(encabezado, filas, delim=",", eol="\r\n", final=True, bom=False, encoding="utf-8"):
    lineas = [delim.join(encabezado)] + [delim.join(str(x) for x in f) for f in filas]
    texto = eol.join(lineas) + (eol if final else "")
    datos = texto.encode(encoding)
    return (b"\xef\xbb\xbf" + datos) if bom else datos


def escribir(directorio, nombre, datos):
    ruta = directorio / nombre
    ruta.write_bytes(datos)
    return ruta


# --- los tres formatos que ya existen en el paquete -----------------------------------
def formato_local(anio, mes, valores, **kw):
    """Como enero/abril: coma, hora local, punto decimal."""
    filas = [(f, ts_local(h), v, 1, "OK") for (f, h, v) in valores]
    return contenido(["frontera_id", "timestamp", "consumo_kwh", "version_lectura", "calidad_lectura"],
                     filas, **kw)


def formato_utc(anio, mes, valores, **kw):
    """Como febrero: punto y coma, UTC con Z, coma decimal."""
    filas = [(f, ts_utc(h), str(v).replace(".", ","), 1, "OK") for (f, h, v) in valores]
    return contenido(["frontera_id", "timestamp_utc", "consumo_kwh", "version_lectura", "calidad_lectura"],
                     filas, delim=";", **kw)


def formato_mwh(anio, mes, valores, **kw):
    """Como marzo: columna 'kwh' + columna 'unidad'; los valores vienen en MWh."""
    filas = [(f, ts_local(h), Decimal(str(v)) / 1000, "MWh", 1, "OK") for (f, h, v) in valores]
    return contenido(["frontera_id", "timestamp", "kwh", "unidad", "version_lectura", "calidad_lectura"],
                     filas, **kw)


def valores_basicos(anio, mes, n=6):
    """n horas para dos fronteras, con valores distintos y con decimales."""
    out = []
    for i, h in enumerate(horas(anio, mes, n)):
        out.append((F1, h, round(10.5 + i, 3)))
        out.append((F2, h, round(200.25 + i, 3)))
    return out
