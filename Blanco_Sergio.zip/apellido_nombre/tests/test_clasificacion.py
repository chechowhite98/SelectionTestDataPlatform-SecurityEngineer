"""C1: la clasificacion es un artefacto vivo; estas pruebas la atan al modelo real."""
import copy
import os

import psycopg2
import pytest

from bia import clasificacion as C
from conftest import conexion_superusuario


def _tablas():
    return copy.deepcopy(C.cargar())


def test_el_yaml_es_valido_y_cumple_la_politica():
    t = _tablas()
    assert C.problemas_de_politica(t) == []
    assert {"core.dim_cliente", "analytics.v_consumo_mensual", "audit.pipeline_runs"} <= set(t)


def test_toda_columna_pii_conocida_esta_marcada_restringido():
    pii = C.columnas_pii(_tablas())
    assert {"core.dim_cliente.nit_cifrado", "core.dim_cliente.email_contacto_cifrado",
            "core.dim_cliente.celular_contacto_cifrado", "core.dim_cliente.direccion_cifrada",
            "core.dim_cliente.representante_legal_cifrado", "quarantine.rechazo.payload_cifrado"} <= pii


def test_restringido_pii_sin_proteccion_se_rechaza():
    t = _tablas()
    t["core.dim_cliente"]["nit_cifrado"]["proteccion"] = "ninguna"
    assert any("sin proteccion" in p for p in C.problemas_de_politica(t))


def test_pii_en_analytics_se_rechaza():
    t = _tablas()
    t["analytics.v_consumo_mensual"]["cliente_id"] = {"clasificacion": "Restringido-PII", "proteccion": "cifrado_aes256gcm"}
    assert any("analytics" in p for p in C.problemas_de_politica(t))


def test_niveles_y_protecciones_desconocidos_se_rechazan():
    t = _tablas()
    t["core.dim_frontera"]["estado"] = {"clasificacion": "Secreto", "proteccion": "magia"}
    assert len([p for p in C.problemas_de_politica(t) if "invalida" in p]) == 2


def test_yaml_ausente_o_roto_falla_cerrado(tmp_path):
    with pytest.raises(C.ClasificacionInvalida):
        C.cargar(tmp_path / "no_existe.yaml")
    roto = tmp_path / "x.yaml"
    roto.write_text("tablas: [unclosed")
    with pytest.raises(C.ClasificacionInvalida):
        C.cargar(roto)


# --------------------------------------------------------------- contra el esquema real
def test_el_yaml_coincide_exactamente_con_las_columnas_de_la_base(bd_temporal):
    conn = conexion_superusuario(bd_temporal)
    try:
        C.verificar(_tablas(), C.columnas_reales(conn.cursor()))
    finally:
        conn.close()


def test_el_rol_ingesta_ve_el_mismo_catalogo_que_el_superusuario(bd_temporal):
    """El pipeline verifica como `ingesta`: pg_catalog no depende de los privilegios del rol."""
    su = conexion_superusuario(bd_temporal)
    ing = psycopg2.connect(host=os.environ.get("PG_HOST", "localhost"), port=int(os.environ.get("PG_PORT", "5432")),
                           dbname=bd_temporal, user="ingesta", password=os.environ["INGESTA_PASSWORD"])
    try:
        assert C.columnas_reales(ing.cursor()) == C.columnas_reales(su.cursor())
    finally:
        su.close(); ing.close()


def test_una_columna_nueva_sin_clasificar_hace_fallar_la_verificacion(bd_temporal):
    conn = conexion_superusuario(bd_temporal)
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute("ALTER TABLE core.dim_cliente ADD COLUMN telefono_fijo text")
    try:
        with pytest.raises(C.ClasificacionInvalida, match="telefono_fijo"):
            C.verificar(_tablas(), C.columnas_reales(cur))
    finally:
        cur.execute("ALTER TABLE core.dim_cliente DROP COLUMN telefono_fijo")
        conn.close()


def test_una_columna_clasificada_que_ya_no_existe_se_detecta(bd_temporal):
    conn = conexion_superusuario(bd_temporal)
    try:
        t = _tablas()
        t["core.dim_cliente"]["fantasma"] = {"clasificacion": "Interno", "proteccion": "ninguna"}
        with pytest.raises(C.ClasificacionInvalida, match="inexistentes"):
            C.verificar(t, C.columnas_reales(conn.cursor()))
    finally:
        conn.close()
