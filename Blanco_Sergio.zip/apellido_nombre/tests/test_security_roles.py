"""
C4 / C5 · Pruebas de menor privilegio contra la base REAL.

Se conecta como cada rol e intenta hacer lo que NO debe poder hacer (igual que
el evaluador). Todo corre dentro de una transaccion que se revierte: la suite
no deja rastro, asi no rompe la idempotencia de `make run`.

Variables de entorno (las mismas que usa docker-compose / .env):
  PG_HOST (localhost) PG_PORT (5432) PG_DB (bia_datos)
  PG_SUPERUSER  PG_SUPERUSER_PASSWORD
  INGESTA_PASSWORD  ANALISTA_PASSWORD  AUDITOR_PASSWORD
"""
import os
import uuid
from contextlib import contextmanager

import psycopg2
import pytest
from psycopg2 import errors

DENEGADO = (errors.InsufficientPrivilege, errors.ReadOnlySqlTransaction)

PASSWORDS = {
    "ingesta": "INGESTA_PASSWORD",
    "analista": "ANALISTA_PASSWORD",
    "auditor": "AUDITOR_PASSWORD",
}

if not os.environ.get("PG_SUPERUSER_PASSWORD"):
    pytest.skip("Base de datos no configurada (falta PG_SUPERUSER_PASSWORD)",
                allow_module_level=True)


def _variable(nombre):
    """Falla con un mensaje claro (no un KeyError) si el Makefile no exporto el .env."""
    valor = os.environ.get(nombre)
    if not valor:
        pytest.fail(f"Falta la variable de entorno {nombre}: `make test` debe cargar el .env", pytrace=False)
    return valor


def _conectar(rol):
    if rol == "superuser":
        user, pwd = _variable("PG_SUPERUSER"), _variable("PG_SUPERUSER_PASSWORD")
    else:
        user, pwd = rol, _variable(PASSWORDS[rol])
    return psycopg2.connect(
        host=os.environ.get("PG_HOST", "localhost"),
        port=int(os.environ.get("PG_PORT", "5432")),
        dbname=os.environ.get("PG_DB", "bia_datos"),
        user=user, password=pwd, connect_timeout=10,
    )


@contextmanager
def sesion(rol):
    """Cursor dentro de una transaccion que SIEMPRE se revierte."""
    conn = _conectar(rol)
    try:
        with conn.cursor() as cur:
            yield cur
    finally:
        conn.rollback()
        conn.close()


def debe_fallar(rol, sql, params=None, esperado=DENEGADO):
    with sesion(rol) as cur:
        with pytest.raises(esperado):
            cur.execute(sql, params)


def debe_funcionar(rol, sql, params=None):
    with sesion(rol) as cur:
        cur.execute(sql, params)
        return cur.fetchall() if cur.description else None


# --- Atributos de los roles ------------------------------------------------------
@pytest.mark.parametrize("rol", ["ingesta", "analista", "auditor"])
def test_roles_sin_privilegios_de_administracion(rol):
    fila = debe_funcionar(
        "superuser",
        "SELECT rolsuper, rolcreatedb, rolcreaterole, rolreplication, rolbypassrls "
        "FROM pg_roles WHERE rolname = %s", (rol,))[0]
    assert fila == (False, False, False, False, False)


def test_el_dueno_no_puede_iniciar_sesion():
    assert debe_funcionar(
        "superuser", "SELECT rolcanlogin FROM pg_roles WHERE rolname='bia_owner'")[0][0] is False


def test_public_no_tiene_privilegios_sobre_los_esquemas_del_modelo():
    n = debe_funcionar("superuser", """
        SELECT count(*) FROM information_schema.role_table_grants
        WHERE grantee = 'PUBLIC'
          AND table_schema IN ('core','analytics','quarantine','ops','audit')""")[0][0]
    assert n == 0


# --- analista: solo la vista analitica --------------------------------------------
def test_analista_consulta_la_vista_analitica():
    debe_funcionar("analista", "SELECT * FROM analytics.v_consumo_mensual LIMIT 1")
    debe_funcionar("analista", "SELECT * FROM analytics.v_cobertura_mensual LIMIT 1")


@pytest.mark.parametrize("tabla", [
    "core.fact_consumo_horario", "core.dim_cliente", "core.dim_frontera",
    "core.fact_factura", "quarantine.rechazo", "ops.archivo_cargado",
    "audit.pipeline_runs"])
def test_analista_no_lee_tablas_base(tabla):
    debe_fallar("analista", f"SELECT * FROM {tabla}")


@pytest.mark.parametrize("sql", [
    "INSERT INTO core.fact_consumo_horario (frontera_id) VALUES ('x')",
    "UPDATE core.dim_cliente SET razon_social = 'x'",
    "DELETE FROM core.fact_consumo_horario",
    "TRUNCATE core.fact_consumo_horario",
    "CREATE TABLE analytics.robo (i int)",
    "CREATE TABLE public.robo (i int)",
    "CREATE TEMP TABLE robo (i int)",
    "DROP VIEW analytics.v_consumo_mensual",
])
def test_analista_no_puede_escribir_ni_crear(sql):
    debe_fallar("analista", sql)


def test_analista_ni_siquiera_escribe_si_fuerza_una_sesion_de_escritura():
    with sesion("analista") as cur:
        cur.execute("SET default_transaction_read_only = off")   # lo intenta
        with pytest.raises(DENEGADO):
            cur.execute("UPDATE core.dim_cliente SET razon_social = 'x'")


def test_la_vista_analitica_no_expone_columnas_pii():
    cols = [c for (c,) in debe_funcionar("superuser", """
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = 'analytics'""")]
    prohibidas = ("nit", "email", "celular", "direccion", "representante",
                  "razon_social", "observaciones", "cifrad")
    assert not [c for c in cols if any(p in c for p in prohibidas)], cols


# --- auditor: solo la bitacora ------------------------------------------------------
def test_auditor_lee_la_bitacora():
    debe_funcionar("auditor", "SELECT * FROM audit.pipeline_runs LIMIT 1")


@pytest.mark.parametrize("tabla", [
    "core.dim_cliente", "core.fact_consumo_horario", "core.fact_factura",
    "quarantine.rechazo", "ops.archivo_cargado", "analytics.v_consumo_mensual"])
def test_auditor_no_lee_nada_mas(tabla):
    debe_fallar("auditor", f"SELECT * FROM {tabla}")


@pytest.mark.parametrize("sql", [
    "INSERT INTO audit.pipeline_runs (corrida_id, evento) VALUES (gen_random_uuid(), 'INICIO')",
    "UPDATE audit.pipeline_runs SET detalle = '{}'",
    "DELETE FROM audit.pipeline_runs",
    "TRUNCATE audit.pipeline_runs",
])
def test_auditor_solo_lee(sql):
    debe_fallar("auditor", sql)


# --- ingesta: escribe el modelo, nada mas ---------------------------------------------
def _cifrado_falso():
    return psycopg2.Binary(os.urandom(40))      # >= 29 B: pasa el dominio


def _sembrar_cliente_y_frontera(cur):
    cur.execute(
        """INSERT INTO core.dim_cliente
             (cliente_id, razon_social, nit_hash, nit_cifrado, clave_version, huella_contenido)
           VALUES ('CLI_T', 'x', %s, %s, 1, %s)""",
        (psycopg2.Binary(os.urandom(32)), _cifrado_falso(), psycopg2.Binary(os.urandom(32))))
    cur.execute("""INSERT INTO core.dim_frontera (frontera_id, codigo_sic, cliente_id)
                   VALUES ('CO0000000001', 'frt00001', 'CLI_T')""")


def test_ingesta_escribe_el_modelo():
    with sesion("ingesta") as cur:
        _sembrar_cliente_y_frontera(cur)
        cur.execute(
            """INSERT INTO core.fact_consumo_horario
                 (frontera_id, ts_utc, consumo_kwh, estado, version_lectura,
                  archivo_origen, fila_origen)
               VALUES ('CO0000000001', '2026-01-01T05:00:00Z', 10, 'VALIDA', 1, 'a.csv', 1)""")


def test_ingesta_no_puede_guardar_pii_en_claro():
    with sesion("ingesta") as cur:
        with pytest.raises(errors.CheckViolation):
            cur.execute(
                """INSERT INTO core.dim_cliente
                     (cliente_id, razon_social, nit_hash, nit_cifrado, clave_version, huella_contenido)
                   VALUES ('CLI_T', 'x', %s, %s, 1, %s)""",
                (psycopg2.Binary(os.urandom(32)), psycopg2.Binary(b"900123456-7"),
                 psycopg2.Binary(os.urandom(32))))


@pytest.mark.parametrize("sql", [
    "DELETE FROM core.fact_consumo_horario",
    "TRUNCATE core.fact_consumo_horario",
    "DROP TABLE core.dim_cliente",
    "ALTER TABLE core.dim_cliente ADD COLUMN x int",
    "CREATE TABLE core.robo (i int)",
    "CREATE TABLE public.robo (i int)",
    "SELECT * FROM audit.pipeline_runs",
    "SELECT * FROM analytics.v_consumo_mensual",
    "ALTER TABLE audit.pipeline_runs DISABLE TRIGGER ALL",
])
def test_ingesta_no_puede_mas_de_lo_que_dice(sql):
    debe_fallar("ingesta", sql)


def test_ingesta_puede_registrar_en_la_bitacora():
    with sesion("ingesta") as cur:
        cur.execute(
            "INSERT INTO audit.pipeline_runs (corrida_id, evento) VALUES (%s, 'INICIO')",
            (str(uuid.uuid4()),))


# --- C5 · la bitacora es append-only de verdad -----------------------------------------
@pytest.mark.parametrize("rol", ["ingesta", "auditor", "analista"])
@pytest.mark.parametrize("sql", [
    "UPDATE audit.pipeline_runs SET detalle = '{}'",
    "DELETE FROM audit.pipeline_runs",
    "TRUNCATE audit.pipeline_runs",
])
def test_bitacora_inmutable_por_privilegios(rol, sql):
    debe_fallar(rol, sql)


@pytest.mark.parametrize("sentencia", [
    "UPDATE audit.pipeline_runs SET resultado = 'OK'",
    "DELETE FROM audit.pipeline_runs",
    "TRUNCATE audit.pipeline_runs",
])
def test_bitacora_inmutable_incluso_para_el_superusuario(sentencia):
    """Segunda capa: el trigger frena hasta a quien tiene todos los permisos."""
    with sesion("superuser") as cur:
        cur.execute("INSERT INTO audit.pipeline_runs (corrida_id, evento) "
                    "VALUES (gen_random_uuid(), 'INICIO')")
        with pytest.raises(errors.InsufficientPrivilege, match="append-only"):
            cur.execute(sentencia)


def test_la_bitacora_registra_quien_con_session_user():
    with sesion("ingesta") as cur:
        cur.execute("INSERT INTO audit.pipeline_runs (corrida_id, evento) "
                    "VALUES (%s, 'INICIO')", (str(uuid.uuid4()),))
    # (lo anterior se revirtio) lo comprobamos como superusuario en una sola transaccion:
    with sesion("superuser") as cur:
        cur.execute("SET ROLE ingesta")
        cur.execute("INSERT INTO audit.pipeline_runs (corrida_id, evento) "
                    "VALUES (gen_random_uuid(), 'INICIO')")
        cur.execute("RESET ROLE")
        cur.execute("SELECT ejecutado_por FROM audit.pipeline_runs "
                    "ORDER BY evento_id DESC LIMIT 1")
        # session_user sigue siendo el superusuario real, no 'ingesta': no se falsea con SET ROLE
        assert cur.fetchone()[0] == os.environ["PG_SUPERUSER"]
