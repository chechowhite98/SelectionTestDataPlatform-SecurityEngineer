import csv
import os
from pathlib import Path

import pytest


@pytest.fixture(scope="session")
def datos_reales():
    """Directorio data/ del paquete. Las pruebas que lo usan se saltan si no esta
    (p.ej. en CI sin los datos); el evaluador si los tiene. BIA_DATA_DIR lo cambia."""
    d = Path(os.environ.get("BIA_DATA_DIR", "data"))
    if not (d / "consumos").is_dir() or not (d / "maestros" / "fronteras.csv").exists():
        pytest.skip(f"No hay datos reales en {d} (defina BIA_DATA_DIR)")
    return d


@pytest.fixture(scope="session")
def fronteras_maestro(datos_reales):
    ruta = datos_reales / "maestros" / "fronteras.csv"
    with open(ruta, newline="", encoding="latin-1") as fh:
        return {r["frontera_id"] for r in csv.DictReader(fh)}


@pytest.fixture(scope="session")
def cifrador():
    """Cifrador con llaves aleatorias de prueba (nunca las de .env)."""
    from bia import cripto
    llaves = cripto.cargar_llaves({"BIA_ENC_KEYS": f"1:{cripto.generar_llave()}",
                                   "BIA_INDEX_KEY": cripto.generar_llave()})
    return cripto.Cifrador(llaves)


# ----------------------------------------------------------------------------------
# Base de datos TEMPORAL para las pruebas de integracion del pipeline.
#
# El pipeline hace commit real. Si estas pruebas usaran la base del evaluador, al
# limpiar entre pruebas la dejarian vacia justo cuando el la verifica (la tabla de
# consumos "vacia" es una eliminatoria). Por eso cada modulo crea su propia base
# `bia_test_<id>`, le aplica sql/ y la destruye al terminar. La base principal no se toca.
# ----------------------------------------------------------------------------------
import os as _os
import re as _re
import shutil as _shutil
import subprocess as _subprocess
import uuid as _uuid

_VARS_BD = ("PG_SUPERUSER", "PG_SUPERUSER_PASSWORD", "INGESTA_PASSWORD", "ANALISTA_PASSWORD", "AUDITOR_PASSWORD")
_RAIZ = Path(__file__).resolve().parent.parent


def conexion_superusuario(dbname: str):
    import psycopg2
    return psycopg2.connect(host=_os.environ.get("PG_HOST", "localhost"),
                            port=int(_os.environ.get("PG_PORT", "5432")), dbname=dbname,
                            user=_os.environ["PG_SUPERUSER"], password=_os.environ["PG_SUPERUSER_PASSWORD"],
                            connect_timeout=10)


@pytest.fixture(scope="module")
def bd_temporal():
    faltan = [v for v in _VARS_BD if not _os.environ.get(v)]
    if faltan:
        pytest.skip(f"Base de datos no configurada (faltan {', '.join(faltan)})")
    psql = _shutil.which("psql")
    if psql is None:
        pytest.skip("psql no esta instalado: no se puede preparar la base temporal")
    version = _subprocess.run([psql, "--version"], capture_output=True, text=True).stdout
    # "psql (PostgreSQL) 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)": la primera version, no la ultima
    mayor = _re.search(r"\)\s*(\d+)(?:\.\d+)*", version)
    if not mayor or int(mayor.group(1)) < 15:           # sql/00_roles.sql usa \getenv (psql >= 15)
        pytest.skip(f"psql >= 15 requerido para sql/00_roles.sql ({version.strip()})")

    nombre = f"bia_test_{_uuid.uuid4().hex[:10]}"
    admin = conexion_superusuario("postgres")
    admin.autocommit = True
    admin.cursor().execute(f'CREATE DATABASE "{nombre}"')
    env = dict(_os.environ, PGPASSWORD=_os.environ["PG_SUPERUSER_PASSWORD"])
    try:
        for f in sorted((_RAIZ / "sql").glob("0*.sql")):
            r = _subprocess.run(
                [psql, "-X", "-q", "-v", "ON_ERROR_STOP=1", "-h", _os.environ.get("PG_HOST", "localhost"),
                 "-p", _os.environ.get("PG_PORT", "5432"), "-U", _os.environ["PG_SUPERUSER"],
                 "-d", nombre, "-f", str(f)], env=env, capture_output=True, text=True, timeout=120)
            if r.returncode != 0:
                pytest.fail(f"no se pudo preparar la base temporal ({f.name}): {r.stderr[-400:]}", pytrace=False)
        yield nombre
    finally:
        admin.cursor().execute(f'DROP DATABASE IF EXISTS "{nombre}" WITH (FORCE)')
        admin.close()
