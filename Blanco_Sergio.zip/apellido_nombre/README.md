# Bia Energy — Data Platform & Security (prueba técnica)

## Cómo correrlo
```bash
make setup     # .venv + dependencias + genera .env (llaves aleatorias) si no existe
make up        # Postgres 16 + Redpanda (healthchecks), SQL aplicado, roles y grants
make run       # pipeline batch  -> out/consumo_mensual.csv, dq_report.json, metrics.json, logs/pipeline.log
make run       # idempotente: 0 filas nuevas, salidas idénticas
make stream    # Redpanda -> out/alertas.json (termina solo)
make test      # 340+ pruebas (integración sobre una base temporal propia)
make down
make verificar # comprueba entrega.yaml contra lo levantado
```
Requisitos: Python ≥ 3.10, Docker Compose v2, `psql` ≥ 15 en el host para las pruebas de integración (se saltan con aviso si falta).
Los datos van en `data/{consumos,maestros,facturacion,eventos}/` (inmutables; no se incluyen en el zip).

## Qué hace (mapa)
| Parte | Dónde |
|---|---|
| A ingesta/modelo/idempotencia | `src/bia/{consumos,maestros,facturacion,repositorio,pipeline}.py`, `sql/` |
| B calidad B1–B7 | `src/bia/{calidad,reglas}.py` |
| C seguridad | `src/bia/{cripto,pii,clasificacion,auditoria}.py`, `sql/00,05`, `data_classification.yaml`, `THREAT_MODEL.md`, `SECURITY.md` |
| D streaming | `src/bia/streaming.py` |
| E observabilidad | `src/bia/{logs,metricas}.py`, `RUNBOOK.md` |
| F IaC | `infra/` |
Decisiones y su razón: `DECISIONS.md`. Uso de IA: `AI_USAGE.md`.

## Resultados verificados
- 114 740 filas de consumo en base; 207 rechazos (`NEGATIVO` 90, `NULO` 60, `OUTLIER` 45, `FRONTERA_HUERFANA` 12).
- Stream: 22 `CONSUMO_FUERA_DE_BANDA`, 6 `FRONTERA_SIN_REPORTE`, 5 `LECTURA_RETROACTIVA`.
- Dato tardío (`consumos_2026-04_correccion.csv`): entra con 300 filas y el resultado es idéntico a cargar todo desde cero.
- PII: ningún valor del maestro aparece en `logs/`, `out/` ni en la tabla cruda (prueba con `pg_dump` y control de fuga plantada).

## Lo que NO está / límites (sin adornos)
- **`make up` no pude ejecutarlo en mi entorno** (sin daemon Docker): el SQL, el pipeline y las pruebas se ejecutaron contra Postgres 16 real instalado localmente; el compose se validó solo sintácticamente. La imagen `redpandadata/redpanda:v24.2.7` no se pudo comprobar; si el pull falla, cambia el tag en `docker-compose.yml`.
- **La capa Kafka de `streaming.py` se probó con un broker falso**, no con Redpanda real; la lógica de alertas sí está probada con los datos reales (22/6/5).
- **`terraform validate` no se corrió** (sin acceso a HashiCorp); sintaxis verificada con un parser HCL2.
- Las pruebas de integración necesitan `psql` ≥ 15 en el host.
- **Perder `.env` (llaves) deja irrecuperable la PII cifrada.**
- `entrega.yaml` lleva credenciales locales y efímeras, las mismas que crea `make up`.

## Dudas que enviaría al equipo
1. ¿`duplicados_conflictivos` incluye las 300 correcciones tardías de abril (120 vs 420)?
2. ¿B5 (huecos) se mide contra el mes calendario completo (lo que hice) o contra el rango observado?
